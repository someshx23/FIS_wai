"""Finds the page on which each heading of the report starts (after a first render) and writes toc_pages.json.
The title page and contents are unnumbered; numbering starts at 1 on the Executive Summary and runs on."""
import json, subprocess, sys
from pathlib import Path
here = Path(__file__).parent
pdf = sys.argv[1] if len(sys.argv) > 1 else str(here / "WAI_Report_C2D.pdf")
heads = json.loads((here / "toc_headings.json").read_text())
n = int([l for l in subprocess.run(["pdfinfo", pdf], capture_output=True, text=True).stdout.splitlines() if l.startswith("Pages")][0].split()[1])
pages = [subprocess.run(["pdftotext", "-f", str(i), "-l", str(i), "-layout", pdf, "-"], capture_output=True, text=True).stdout for i in range(1, n + 1)]
norm = lambda s: " ".join(s.split())
def find(text, start):
    for i in range(start, n):
        if any(norm(line) == norm(text) for line in pages[i].splitlines()):
            return i
    raise SystemExit(f"heading not found: {text}")
body0 = find(heads[0], 2)                      # first heading of the main text (skip title page and contents)
annex0 = find(next(h for h in heads if h.startswith("Annexure")), body0)
out, at = {}, body0
for h in heads:
    at = find(h, at)
    out[h] = str(at - body0 + 1)
(here / "toc_pages.json").write_text(json.dumps(out, indent=1))
print(f"pages: {n} total | front {body0} | main text and references {annex0 - body0} | annexures {n - annex0}")
print("conclusion on page", out["9. Conclusion"], "| references start on page", out["References"], "| annexures start on page", annex0 - body0 + 1)
