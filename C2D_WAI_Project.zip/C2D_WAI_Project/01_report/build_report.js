/*
 * Builds the WAI project report (DOCX) from report_data.json, the rendered diagrams and the text below.
 *   node build_report.js            -> WAI_Report_C2D.docx
 * The contents page is a Word TOC field with cached entries. toc_pages.json (written by find_toc_pages.py
 * after a first render) supplies the cached page numbers, so build_all.sh runs the build twice.
 * In Word the field can be refreshed at any time: right-click the contents, Update Field.
 */
const fs = require("fs"), path = require("path");
const { Paragraph, TextRun, HeadingLevel, AlignmentType, Table, TableRow, TableCell, WidthType, BorderStyle, ImageRun, LineRuleType, VerticalAlign } = require("docx");

const HERE = __dirname, ROOT = path.join(HERE, "..");
const D = JSON.parse(fs.readFileSync(path.join(HERE, "report_data.json"), "utf8"));
const TOC = fs.existsSync(path.join(HERE, "toc_pages.json")) ? JSON.parse(fs.readFileSync(path.join(HERE, "toc_pages.json"), "utf8")) : {};
const FONT = "Times New Roman", PW = 9026, LW = 13958;          // text width in DXA: A4 portrait and landscape with 1-inch margins
const S = D.summary, C = D.counts, F = D.fpa, FX = D.facts;
const headings = [];
const WORDS = ["zero", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten"];
const mn = v => String(v).replace(/^-/, "−");               // true minus sign in running text

// ---------------------------------------------------------------- helpers
function runs(text, o = {}) {                       // **bold**, *italic*, [[placeholder]] (highlighted for the student to fill in)
  return String(text).split(/(\*\*[^*]+\*\*|\*[^*]+\*|\[\[[^\]]+\]\])/).filter(Boolean).map(t => {
    if (t.startsWith("**")) return new TextRun({ text: t.slice(2, -2), bold: true, font: FONT, size: o.size });
    if (t.startsWith("[[")) return new TextRun({ text: "[" + t.slice(2, -2) + "]", highlight: "yellow", font: FONT, size: o.size, bold: o.bold });
    if (t.startsWith("*")) return new TextRun({ text: t.slice(1, -1), italics: true, font: FONT, size: o.size, bold: o.bold });
    return new TextRun({ text: t, font: FONT, size: o.size, bold: o.bold, italics: o.italics });
  });
}
const P = (text, o = {}) => new Paragraph({ alignment: o.align || AlignmentType.JUSTIFIED, keepNext: o.keepNext,
  spacing: { line: o.line || 360, lineRule: LineRuleType.AUTO, before: o.before || 0, after: o.after === undefined ? 80 : o.after },
  indent: o.indent, children: runs(text, o) });
function H1(text, o = {}) {
  headings.push({ text, level: 1 });
  return new Paragraph({ heading: HeadingLevel.HEADING_1, pageBreakBefore: !!o.newPage, children: [new TextRun({ text, font: FONT, size: 26, bold: true })] });
}
const H2 = text => new Paragraph({ heading: HeadingLevel.HEADING_2, children: [new TextRun({ text, font: FONT, size: 24, bold: true })] });
const small = (text, o = {}) => P(text, { size: 20, line: 264, align: AlignmentType.LEFT, after: 60, ...o });
function pngSize(file) { const b = fs.readFileSync(file); return [b.readUInt32BE(16), b.readUInt32BE(20)]; }
function figure(file, caption, maxW = 602, maxH = 9999) {
  const [w, h] = pngSize(file), k = Math.min(maxW / w, maxH / h);
  return [new Paragraph({ alignment: AlignmentType.CENTER, keepNext: true, spacing: { before: 80, after: 40 },
            children: [new ImageRun({ type: "png", data: fs.readFileSync(file), transformation: { width: Math.round(w * k), height: Math.round(h * k) } })] }),
          P(caption, { size: 21, line: 264, align: AlignmentType.CENTER, after: 140 })];
}
const none = { style: BorderStyle.NONE, size: 0, color: "FFFFFF" }, rule = { style: BorderStyle.SINGLE, size: 6, color: "000000" }, hair = { style: BorderStyle.SINGLE, size: 2, color: "999999" };
function table(caption, widths, head, rows, o = {}) {
  const total = o.total || PW, sum = widths.reduce((a, b) => a + b, 0), cw = widths.map(w => Math.round(w * total / sum));
  cw[cw.length - 1] += total - cw.reduce((a, b) => a + b, 0);
  const size = o.size || 19;
  const cell = (t, i, isHead, last) => new TableCell({ width: { size: cw[i], type: WidthType.DXA }, verticalAlign: VerticalAlign.TOP,
    margins: { top: o.pad === undefined ? 35 : o.pad, bottom: o.pad === undefined ? 35 : o.pad, left: 70, right: 70 },
    borders: { top: isHead ? rule : none, bottom: isHead || last ? rule : hair, left: none, right: none },
    children: String(t === null || t === undefined ? "" : t).split("\n").map(line => new Paragraph({ alignment: AlignmentType.LEFT,
      spacing: { line: 240, lineRule: LineRuleType.AUTO, after: 0 }, children: runs(line, { size, bold: isHead }) })) });
  const tr = (r, isHead, last) => new TableRow({ tableHeader: isHead, cantSplit: true, children: r.map((t, i) => cell(t, i, isHead, last)) });
  const out = [];
  if (caption) out.push(P(caption, { size: 21, line: 264, align: AlignmentType.LEFT, keepNext: true, before: 80, after: 60 }));
  out.push(new Table({ width: { size: total, type: WidthType.DXA }, columnWidths: cw,
    borders: { top: none, bottom: none, left: none, right: none, insideHorizontal: none, insideVertical: none },
    rows: [tr(head, true, false), ...rows.map((r, i) => tr(r, false, i === rows.length - 1))] }));
  out.push(new Paragraph({ spacing: { after: o.after === undefined ? 120 : o.after, line: 200 }, children: [] }));
  return out;
}
const fig = n => path.join(ROOT, "02_ea_model", "diagrams", n + ".png");
const ref = parts => new Paragraph({ alignment: AlignmentType.LEFT, spacing: { line: 360, lineRule: LineRuleType.AUTO, after: 0 }, indent: { left: 720, hanging: 720 },
  children: parts.map(p => typeof p === "string" ? new TextRun({ text: p, font: FONT }) : new TextRun({ text: p.i, italics: true, font: FONT })) });
const q = id => D.queries[id];

// ---------------------------------------------------------------- front matter
const TITLE = "Collection to Dock: An Edge-Enabled Information System for Milk Collection Integrity, Chilling Exceptions and Dock Reconciliation in Village Dairy Cooperatives";
const centre = (text, size, o = {}) => new Paragraph({ alignment: AlignmentType.CENTER, spacing: { before: o.before || 0, after: o.after || 0, line: 288, lineRule: LineRuleType.AUTO }, children: runs(text, { size, bold: o.bold }) });
const front = [
  centre("INDIAN INSTITUTE OF MANAGEMENT RANCHI", 28, { bold: true, before: 1300, after: 120 }),
  centre("Integrated Programme in Management, Term V, Academic Year 2026-27", 24, { after: 1700 }),
  centre("Working with AI (WAI) Project Report", 26, { after: 300 }),
  centre(TITLE, 34, { bold: true, after: 300 }),
  centre("Requirements, UML model in Sparx Enterprise Architect and SQLite prototype", 24, { after: 1900 }),
  centre("Course: Fundamentals of Information Systems (FIS)", 24, { after: 80 }),
  centre("Faculty: Prof. Nitin Singh", 24, { after: 1500 }),
  centre("Submitted by", 24, { after: 80 }),
  centre("[[Student name]]", 24, { bold: true, after: 60 }),
  centre("Roll number: [[roll number]]    Section: [[section]]", 24, { after: 1100 }),
  centre("Date of submission: [[date]]", 24),
  new Paragraph({ pageBreakBefore: true, alignment: AlignmentType.LEFT, spacing: { after: 200 }, children: [new TextRun({ text: "Table of Contents", font: FONT, size: 28, bold: true })] }),
  "__TOC__",
];

// ---------------------------------------------------------------- main text, as named blocks so that figures can be placed
const X = {};
X.summary = [H1("Executive Summary (Abstract)"),
  P("India produced 247.87 million tonnes of milk in 2024-25 (Department of Animal Husbandry and Dairying [DAHD], 2025). Milk that enters the cooperative system is bought twice a day from smallholders at village collection points. At that first mile three things decide whether a member is paid fairly and whether the milk survives: the reading taken at collection, the temperature of the cooler before the tanker arrives, and the agreement between what the society dispatched and what the plant received. This project specifies an information system, C2D (Collection to Dock), for an illustrative district milk union. It seals each shift's collection ledger with a hash chain, evaluates chilling rules on an edge unit at the society, opens a tracked exception case when a rule is breached and reconciles every pickup with its dock receipt."),
  P(`The work was done with a generative AI assistant under one discipline: a single machine-readable model definition generates the Enterprise Architect repository, the diagram figures and the consistency checks. The deliverables are a UML model of ${S.elements} elements on ${S.diagrams.length} diagrams, ${S.fr + S.nfr} requirements traced to use cases and tests, and a SQLite prototype on which ${D.tests.length} acceptance tests pass with disclosed synthetic data. The design has not been deployed, and its thresholds are design values that a pilot must confirm.`)];

X.intro = [H1("1. Introduction: Problem Background"),
  P("**1.1 Context.** Dairy cooperatives in India buy milk twice a day from members who each pour a few litres. Payment depends on quantity and on fat and solids-not-fat (SNF), so the collection point is both a weighing station and a testing laboratory. Automatic milk collection units, which link a weigh scale and a milk analyser to a computer, are an established answer. Bowonder et al. (2005) documented an Amul system that made it easy for farmers to be paid in cash as soon as their milk was delivered, and the National Dairy Development Board now offers software that also covers cooler monitoring, periodic billing and rule-based audit (National Dairy Development Board [NDDB], n.d.). The function is therefore not new. What a union still has to decide is exactly what its system must do when something goes wrong, and that is a specification problem."),
  P("**1.2 The core problem and the evidence for it.** Three failure points lie between the pour and the plant. First, a reading can be typed or altered by hand in a way members cannot check. An account from Amul lists dip-stick measurement, manual sampling and tampering as reasons why members doubt the system (Vyas, 2021). Second, milk has to be cooled quickly: FAO guidance is 10 °C within two hours of milking and 4 °C within three to four hours (Moffat et al., 2016). Without monitoring, a cooler that fails at night is discovered when the tanker arrives. Third, the society's figures and the dock's figures differ, and without a record of where the difference arose the loss becomes a matter of argument. A sample project report of the National Cooperative Development Corporation (NCDC, n.d.) gives souring, adulteration and lack of transparency in payments as reasons to invest in the milk cold chain, and in the national survey of 6,432 milk samples about 41% fell short on a quality parameter such as fat or SNF although they were safe (Food Safety and Standards Authority of India [FSSAI], 2019)."),
  P("**1.3 Stakeholders and scope.** The users are the society operator, the route supervisor, the dock officer, the accounts officer and the system administrator. Members and the tanker driver are affected and take part through messages and a confirmation code. The scope runs from the pour to the reconciled dock receipt and the member's statement for a ten-day payment cycle. Plant processing, sales, tanker routing and the bank transfer are outside it. The setting is an illustrative union of 120 societies on eight routes, of which the prototype simulates 12 societies on three routes. No real organisation was studied; the as-is process is assembled from the published sources cited here."),
  P("**1.4 Why AI is relevant.** A specification is a large body of interlocking text and diagrams, and most of the effort goes into keeping its parts consistent. A generative model drafts such material quickly, but studies of language models on UML tasks report semantic errors, inconsistent answers and missed elements (Cámara et al., 2023; Chen et al., 2023). The project therefore uses AI to draft and generate, and relies on programmed checks to decide whether the result is consistent."),
  P("**1.5 Managerial significance.** For a union, late discovery of a warm lot means sour milk, an unexplained variance means a dispute, and an unverifiable reading means a member who trusts the society less. **Problem statement.** A district milk union cannot see or prove what happens to milk and to measurements between the member's pour and the plant dock, so chilling failures surface late, quantity and quality differences turn into disputes, and members cannot verify what they are paid for. This project specifies and prototypes, with AI assistance, an information system that makes collection records tamper-evident, turns chilling and reconciliation breaches into tracked exception cases, and traces every requirement to a UML model and a test.")];

X.lit = [H1("2. Literature Review"),
  P("**Digitised procurement.** Bowonder et al. (2005) use Amul's experience to argue that the rural poor can benefit from ICT platforms when these are carefully designed and implemented. Practitioner sources add operational detail: collection twice a day, a printed slip for each pour and payment every ten days (NCDC, n.d.), and the newer practice of metering each cooler's milk into the tanker, recording its temperature and raising an alert if a tanker door is opened in transit (Vyas, 2021)."),
  P("**Cold-chain monitoring and edge computing.** Tsang et al. (2018) propose an IoT-based risk monitoring system that combines a wireless sensor network, a cloud database and fuzzy logic, and report a before-and-after comparison at a service provider. Shi et al. (2016) describe edge computing as processing data at the edge of the network and argue that it can address concerns about response time, bandwidth cost, and data safety and privacy. Singh et al. (2025) map the literature on cyber-physical systems, and Singh et al. (2026) discuss their promise and challenges in logistics."),
  P("**Security and integrity.** Role-based access control assigns permissions to roles and users to roles (Sandhu et al., 1996). Schneier and Kelsey (1999) show how a log kept on an untrusted machine can be made tamper-evident by chaining its entries cryptographically, which is the idea behind the sealed shift ledger here. Gupta et al. (2020) discuss security and privacy challenges in smart farming."),
  P("**AI in modelling.** Cámara et al. (2023) found the UML models produced by ChatGPT limited by syntactic and semantic defects, inconsistent answers and poor scalability. Chen et al. (2023) measured GPT-4 on domain modelling and report F1 scores of 0.76 for classes, 0.61 for attributes and 0.34 for relationships, with high precision and low recall."),
  P("**Gap.** The dairy sources describe functions, the monitoring papers describe sensing and risk scoring, and the AI papers assess generated models in isolation. None gives a checked specification of the exception workflow that links a sensor reading to an accountable decision, or shows how AI-generated models can be held consistent across diagrams, repository and database. This report attempts both for one bounded case.")];

X.method1 = [H1("3. Methodology and AI Tools"),
  P("**3.1 Approach.** The work follows the planning, analysis and design phases of the systems development life cycle and stops before implementation (Tegarden et al., 2025). Requirements were derived from the published process descriptions in Section 1, because field interviews were not possible, and each was written with an acceptance criterion so that it can be tested. The to-be system is modelled in UML 2.5.1 (Object Management Group, 2017)."),
  P("**3.2 AI tools and prompt strategy.** One generative AI tool did the drafting: Claude (Anthropic, model Claude Fable 5.2), used in an agentic session with web search, a code workspace and file tools. ChatGPT was used once, to draft the master prompt. The prompt was a single detailed brief that set roles, an order of precedence between documents and explicit prohibitions (no invented sources, limits or results), with the course outline, the WAI policy and my classroom Enterprise Architect file attached. The prompt and the log of outputs are in Annexure J.")];
X.fig1 = figure(path.join(HERE, "figures", "fig_method.png"), "**Figure 1.** Methodology: AI-drafted steps, generated artefacts, programmed checks and my review.", 570);
X.method2 = [
  P("**3.3 Model as code.** The central technical decision was to keep the UML model in one Python definition file (Figure 1). Three programs read it: one writes the Enterprise Architect repository, one draws the diagram figures, and one checks consistency and exports the tables. A .qea project file is a SQLite database (Sparx Systems, n.d.), so the repository is written directly as rows that follow the conventions of my classroom file. A change to a class or a transition therefore changes the repository, the figures and the database trigger together."),
  P(`**3.4 Verification.** Nothing was accepted on the AI's word. Four layers of checks were programmed: ${D.qea_checks.length} structural checks on the repository, ${S.checks.length} consistency checks across artefacts, ${D.tests.length} acceptance tests on the prototype with simulated data, and verification of every reference against Crossref, OpenAlex or the publisher's page. The consistency checks were themselves tested by planting seven defects in the model, all of which were caught.`),
  P("**3.5 Limits.** The AI workspace cannot run Enterprise Architect, so the figures in this report are drawn by the rendering program from the same definition as the repository. [[Complete after you have done it: I opened C2D_Model.qea in Enterprise Architect (version and build ...) on (date). The Project Integrity Check reported (result). I changed (list any edits) and re-exported (which diagrams).]]")];

X.data = [H1("4. Data"),
  P(`*Context data* are published figures and process descriptions, cited where they are used. *Design data* are the requirements, rules and model elements. The four-hour limit for reaching 4 °C follows FAO guidance (Moffat et al., 2016); tolerances such as 0.5% on quantity are design values to be confirmed with the Union. *Test data* are synthetic and are disclosed as such. A simulation generates 30 days of operation for ${C.society} societies and ${C.member} members: ${C.collection_entry.toLocaleString("en-US")} collection entries in ${C.collection_shift} shifts, ${C.temperature_reading.toLocaleString("en-US")} cooler readings at five-minute intervals, ${C.tank_lot} tank lots, ${C.pickup_record} pickups and dock receipts, and ${C.exception_case} exception cases. Seven societies carry planted problems (a faulty compressor, long power cuts, a silent sensor, a quantity bias at pickup, frequent manual entries, overstated fat and a slow operator) so that every exception path is exercised. The generator uses a fixed random seed and writes through the database constraints, so no cleaning was needed. Missing readings are deliberate: they are what rule R3 detects. These data show that the design behaves as specified. They say nothing about how any real union performs.`)];

X.r1 = [H1("5. Results: Requirements, UML Design and Verification"),
  P(`**5.1 Requirements.** The baseline has ${S.fr} functional and ${S.nfr} non-functional requirements (Annexure B), each with its actor, priority and acceptance criterion. Table 1 groups the functional requirements by the failure points of Section 1.`),
  ...table("**Table 1.** Functional requirements by group, with the tests that verify them", [18, 17, 43, 22],
    ["Group", "Requirements", "What the system must do", "Verified by"],
    [["Collection integrity", "FR-01 to FR-06", "Device capture, rate-chart pricing, controlled manual entry, member message, sealed shift ledger, offline capture", "T-02 to T-06; FR-01 needs devices"],
     ["Chilling exceptions", "FR-07 to FR-11", "Readings every five minutes, rules R1 to R3 at the edge, tracked case, acknowledgement and escalation, supervisor disposition", "T-08 to T-11; FR-07 needs sensors"],
     ["Dispatch and reconciliation", "FR-12 to FR-15", "Driver-confirmed pickup, dock receipt, variance calculation and case, recorded responsibility", "T-12 to T-15"],
     ["Payment, control and reporting", "FR-16 to FR-20", "Statements from sealed shifts, rate charts, users and devices, audit trail and verification, dashboard", "T-16 to T-18; queries Q1 to Q10"]])];
X.r2 = [P(`**5.2 Use cases.** Figure 2 shows ${S.use_cases} use cases and ${S.actors} actors, of which two are devices and two are external systems. Notification is modelled once and included by the three use cases that send messages. Two extensions carry the exceptional behaviour: a manual entry extends collection only when a device reading is unavailable, and raising an exception case extends both chilling monitoring and dock receipt.`)];
X.fig2 = figure(fig("UC-01"), "**Figure 2.** Use case diagram of the C2D system (UC-01).", 545);
X.r3 = [P(`**5.3 Structure and behaviour.** The domain model has ${S.entity_classes} entity classes and ${S.control_classes} control classes with ${S.attributes} attributes and ${S.operations} operations (Annexure D). A collection entry is part of exactly one shift, because a sealed shift is the unit of evidence. A tank lot pools one or two shifts and is the subject of every exception case, which keeps chilling and variance cases on one object. ExceptionCase is abstract, with ChillingException and VarianceException as subclasses that share a lifecycle but carry different evidence. The lifecycle of a tank lot has ten states and 19 transitions: a rule breach moves a lot to AtRisk, a supervisor decision releases it, holds it, rejects it or orders an early pickup, and reconciliation ends it as Reconciled or sends it to UnderReview. An activity diagram and two sequence diagrams complete the behaviour.`)];
X.r4 = [P("**5.4 Architecture.** Figure 3 places the collection service, the chilling monitor and a local ledger store on an edge unit at the society, so that collection and rule evaluation continue when the mobile link is down. Exception, reconciliation and notification services run on the Union server. This follows the classroom pattern of sensor, inference engine, supervisory system and command centre, with the rule engine in the place of the inference engine.")];
X.fig3 = figure(fig("DEP-01"), "**Figure 3.** Deployment of the C2D system across field, Union and external zones (DEP-01).", 580);
X.r5 = [P(`**5.5 Prototype and verification.** The SQLite schema has ${C.tables} tables. The three exception classes share one table with a discriminator. ${WORDS[C.triggers][0].toUpperCase() + WORDS[C.triggers].slice(1)} triggers enforce what column constraints cannot, including the lot state machine, whose transition list is loaded from the UML model. All ${S.checks.length} consistency checks pass, and the repository holds exactly the ${S.elements} elements, ${S.connectors + 24} connectors and ${S.diagrams.length} diagrams of the definition. On the prototype ${D.tests.filter(x => x.result === "PASS").length} of ${D.tests.length} acceptance tests pass (Annexure G). Recomputing the hash chain verified all ${C.collection_shift} shifts, and in a tamper test on a copy of the database each of 200 changes to a single field was detected at the altered entry. Two requirements cannot be tested without hardware (FR-01 and FR-07).`)];
const q3 = q("Q3").rows[0], q5 = q("Q5").rows[0], q7 = q("Q7").rows[0];
X.r6 = [P(`**5.6 What the reports show.** Figure 4 shows four of the seven dashboard views. On the synthetic data the reporting layer isolates each planted problem. Society ${q7[0]} breaks the four-hour chilling rule in ${q7[4] + q7[5]} of its ${q7[1]} shifts. ${q3[0]} is outside the quantity tolerance on all ${q3[5]} of its lots, at an average of ${mn(q3[3])}%. ${q5[0]} combines ${q5[3]}% manual entries with an average fat variance of ${mn(q5[4])}. At S02, ${WORDS[FX.s02_escalated]} of the ${WORDS[FX.s02_chilling_cases]} chilling cases were escalated because nobody acknowledged them within 15 minutes. These are properties of the simulation, reported to show that the design can answer the questions a supervisor would ask.`)];
X.fig4 = figure(path.join(ROOT, "05_dashboard", "charts", "dashboard_report_panel.png"), "**Figure 4.** Four dashboard views on synthetic data. Blue dots are outside the limit shown; grey dots are within it.", 530);

const BE = (() => { const kg = FX.total_kg / C.society / 30, rate = FX.total_amount / FX.total_kg;                 // break-even illustration
  return { kg: Math.round(kg), rate: rate.toFixed(2), value: (Math.round(Math.round(kg) * 365 * Number(rate.toFixed(2)) * 0.001 / 100) * 100).toLocaleString("en-US") }; })();
X.disc = [H1("6. Discussion: Managerial Interpretation and Recommendations"),
  P("**Interpretation.** For the Union's managers the design changes three things. First, a sealed ledger and a pickup confirmed by the driver give society, transporter and plant the same record, so a discussion starts from shared evidence. Second, a chilling failure becomes a case at the breaching reading and reaches a named supervisor if the operator does not respond in 15 minutes, while the milk can still be saved. Third, every variance beyond tolerance ends with a recorded responsibility, so a society that is always 1% short at the dock, or high on fat whenever entries are manual, appears in a report and can be visited."),
  P("**Recommendations.** In the short term (three months) the Union should adopt the requirements baseline as the specification against which any collection software, including an existing product, is evaluated; confirm the thresholds and tolerances with procurement staff; and review the model with two societies. In the medium term it should pilot on one route with the acceptance criteria as the test plan. In the long term the case and variance history should inform supervision and transporter contracts."),
  P(`**Costs and benefits.** The costs are an edge unit and sensor at each society, connectivity, software, training and support. The benefits are fewer losses from sour milk, fewer disputed lots and member confidence. I have not put rupee values on either, because loss rates and equipment prices were not measured. The break-even condition can still be stated. At a society of the simulated size (about ${BE.kg} kg a day at about Rs ${BE.rate} per kg, both simulation assumptions), each 0.1 percentage point of milk that is no longer lost is worth about Rs ${BE.value} a year (${BE.kg} x 365 x ${BE.rate} x 0.001). The annual cost of the system per society divided by this value gives the loss reduction needed to recover it, and the pilot should measure both.`),
  P("**Trade-offs and change management.** Running rules at the edge costs more per site than a design that runs only in the cloud, but it keeps detection independent of the link. A hash chain detects alteration but does not prevent a false reading at the source, which is why manual entries stay possible but are restricted and reported. Operators need to trust that an alert is a request for help and will not be used as a charge sheet, so responsibility decisions sit with the supervisor and are visible to the society.")];

const e = F.effort, fs_ = F.summary, cnt = k => fs_[k].reduce((a, b) => a + b);
X.road1a = [H1("7. Implementation Roadmap"),
  P(`**Size and effort.** Function point analysis (Albrecht & Gaffney, 1983) gives ${F.ufp} unadjusted function points from ${cnt("ILF")} internal logical files, ${cnt("EI")} external inputs, ${cnt("EO")} external outputs and ${cnt("EQ")} external inquiries. The 14 general system characteristics sum to ${F.tdi}, so the adjusted size is ${F.afp} function points (Annexure H). Converting size to effort needs assumptions, so the result is a range: at 40 to 60 source lines per function point and the Basic COCOMO coefficients for organic and semi-detached projects (Boehm, 1981), effort lies between ${Math.round(e["organic@40"].person_months)} and ${Math.round(e["semi-detached@60"].person_months)} person-months and the schedule between ${Math.round(e["organic@40"].months)} and ${Math.round(e["semi-detached@60"].months)} months. These figures are for planning only.`)];
X.road1b = [P("**Roadmap, resources and risks.** Figure 5 phases the work over 15 months: requirements validation in the field, design and device procurement, three build increments in priority order, testing, a pilot on one route and a rollout decision. The team is a product owner from procurement, a project manager, four to six developers and testers, a field engineer for devices, and trainers during the pilot. Operators, supervisors and dock staff are trained on their own screens. The main risks and their mitigations are device integration (test with existing collection units in month 3), connectivity (the offline design, tested for 72 hours), sensor reliability (rule R3 and a spares stock), user resistance (demonstrations at society meetings) and scope growth (the baseline and its priorities).")];
X.fig5 = figure(path.join(HERE, "figures", "fig_gantt.png"), "**Figure 5.** Indicative roadmap over 15 months (M1 to M15).", 570);

X.ethics = [H1("8. Ethical, Legal and Bias Considerations"),
  P("**Responsible use of AI.** Three risks were managed. The first is hallucination: language models can invent sources and facts, so every reference was checked against Crossref, OpenAlex or the publisher's page, and a source read only at the level of its bibliographic record is cited only for what its title establishes. The second is over-trust. Generated models look complete when they are not, so acceptance rests on programmed checks and on my review in Enterprise Architect. The third concerns authorship. The AI drafted most of the text, the model and the code in this submission. The prompt and the log are disclosed in full, and I remain responsible for every statement."),
  P("**Data and privacy.** No personal or confidential data were used; the test data are synthetic and say so wherever they appear. The designed system would process members' mobile numbers and bank references, which are personal data under the Digital Personal Data Protection Act, 2023. The design limits them to two purposes, shows them only to the roles that need them (NFR-08) and requires notice at enrolment."),
  P("**Fairness, bias and security.** An exception system can become a surveillance system. Three safeguards are designed in: thresholds are published and configurable, a case records evidence only, and responsibility is decided by a person whose decision is logged and can be contested. The synthetic data carry my own assumptions about which societies have problems, so no conclusion about real societies, operators or regions should be drawn from them. A rule that depends on devices also disadvantages a society with poor equipment or power, so repeated chilling cases should trigger maintenance before any penalty. Each added device is also an attack surface (Gupta et al., 2020), which is why device registration, signed readings and least-privilege roles are in the requirements baseline.")];

X.concl = [H1("9. Conclusion"),
  P(`The project turns a familiar problem, what happens to milk and to measurements in the first mile, into a specification that can be checked: ${S.fr + S.nfr} requirements, a UML model in Enterprise Architect, a relational schema that enforces the model's state machine, and tests that pass on disclosed synthetic data. Working with AI made it feasible for one student to produce a model of this size and keep it consistent. The same experience shows where AI needs a counterweight: generated artefacts were accepted only when a program or a source confirmed them. What remains needs the field: validating the requirements with societies, integrating real devices, confirming the thresholds and measuring losses in a pilot.`)];

// Order of the main text. Figures sit after the paragraph that introduces them, or a little later where that avoids a page-bottom gap.
const ORDER = (process.env.C2D_ORDER || "summary,intro,lit,method1,fig1,method2,data,r1,r2,r3,fig2,r4,r5,fig3,fig4,r6,disc,road1a,fig5,road1b,ethics,concl").split(",");
const B = ORDER.flatMap(k => X[k]);

// ---------------------------------------------------------------- references
const R = [];
R.push(H1("References"));
[
 ["Albrecht, A. J., & Gaffney, J. E. (1983). Software function, source lines of code, and development effort prediction: A software science validation. ", { i: "IEEE Transactions on Software Engineering, SE-9" }, "(6), 639-648. https://doi.org/10.1109/TSE.1983.235271"],
 ["Boehm, B. W. (1981). ", { i: "Software engineering economics" }, ". Prentice-Hall."],
 ["Bowonder, B., Raghu Prasad, B. R., & Kotla, A. (2005). ICT application in a dairy industry: The e-experience of Amul. ", { i: "International Journal of Services Technology and Management, 6" }, "(3-5), 241-265. https://doi.org/10.1504/IJSTM.2005.007410"],
 ["Cámara, J., Troya, J., Burgueño, L., & Vallecillo, A. (2023). On the assessment of generative AI in modeling tasks: An experience report with ChatGPT and UML. ", { i: "Software and Systems Modeling, 22" }, "(3), 781-793. https://doi.org/10.1007/s10270-023-01105-5"],
 ["Chen, K., Yang, Y., Chen, B., Hernández López, J. A., Mussbacher, G., & Varró, D. (2023). Automated domain modeling with large language models: A comparative study. In ", { i: "2023 ACM/IEEE 26th International Conference on Model Driven Engineering Languages and Systems (MODELS)" }, " (pp. 162-172). IEEE. https://doi.org/10.1109/MODELS58315.2023.00037"],
 ["Department of Animal Husbandry and Dairying. (2025). ", { i: "Basic animal husbandry statistics 2025" }, ". Ministry of Fisheries, Animal Husbandry and Dairying, Government of India. https://dahd.gov.in/sites/default/files/2025-11/BAHS2025Brochure.pdf"],
 ["Digital Personal Data Protection Act, 2023, No. 22, Acts of Parliament, 2023 (India)."],
 ["Food Safety and Standards Authority of India. (2019). ", { i: "National milk safety and quality survey 2018" }, ". https://mail.fssai.gov.in/upload/uploadfiles/files/Report_Milk_Survey_NMQS_18_10_2019.pdf"],
 ["Gupta, M., Abdelsalam, M., Khorsandroo, S., & Mittal, S. (2020). Security and privacy in smart farming: Challenges and opportunities. ", { i: "IEEE Access, 8" }, ", 34564-34584. https://doi.org/10.1109/ACCESS.2020.2975142"],
 ["Moffat, F., Khanal, S., Bennett, A., Thapa, T. B., & Malakaran George, S. (2016). ", { i: "Technical and investment guidelines for milk cooling centres" }, ". Food and Agriculture Organization of the United Nations. https://openknowledge.fao.org/items/0da9b153-844b-42a0-9ee0-f2d307c0ad53"],
 ["National Cooperative Development Corporation. (n.d.). ", { i: "Detailed project report on cold chain development in milk procurement" }, " [Sample project report]. https://www.ncdc.in/documents/downloads/131804052011.Sample-DPR_Cold-Chain-in-Milk-Procurement.pdf"],
 ["National Dairy Development Board. (n.d.). ", { i: "AMCS: Improving process efficiency at DCS level" }, ". https://www.dairyknowledge.in/sites/default/files/amcs-dic-article.pdf"],
 ["Object Management Group. (2017). ", { i: "OMG Unified Modeling Language (OMG UML), version 2.5.1" }, " (formal/2017-12-05). https://www.omg.org/spec/UML/2.5.1"],
 ["Sandhu, R. S., Coyne, E. J., Feinstein, H. L., & Youman, C. E. (1996). Role-based access control models. ", { i: "Computer, 29" }, "(2), 38-47. https://doi.org/10.1109/2.485845"],
 ["Schneier, B., & Kelsey, J. (1999). Secure audit logs to support computer forensics. ", { i: "ACM Transactions on Information and System Security, 2" }, "(2), 159-176. https://doi.org/10.1145/317087.317089"],
 ["Shi, W., Cao, J., Zhang, Q., Li, Y., & Xu, L. (2016). Edge computing: Vision and challenges. ", { i: "IEEE Internet of Things Journal, 3" }, "(5), 637-646. https://doi.org/10.1109/JIOT.2016.2579198"],
 ["Singh, N., Lai, K.-H., & Huang, G. Q. (2026). Cyberintelligence for logistics: The promise and challenges of cyber-physical systems. ", { i: "Business Horizons, 69" }, "(1), 77-87. https://doi.org/10.1016/j.bushor.2025.01.001"],
 ["Singh, N., Panigrahi, P. K., Zhang, Z., & Jasimuddin, S. M. (2025). Cyber-physical systems: A bibliometric analysis of literature. ", { i: "Journal of Intelligent Manufacturing, 36" }, "(4), 2335-2371. https://doi.org/10.1007/s10845-024-02380-9"],
 ["Sparx Systems. (n.d.). File based projects. In ", { i: "Enterprise Architect user guide" }, " (Version 17.2). https://sparxsystems.com/enterprise_architect_user_guide/17.2/createamodeloverview.html"],
 ["Tegarden, D. P., Samuel, B., Lukyanenko, R., Dennis, A., & Wixom, B. H. (2025). ", { i: "Systems analysis and design: An object-oriented approach with UML" }, " (7th ed.). Wiley."],
 ["Tsang, Y. P., Choy, K. L., Wu, C. H., Ho, G. T. S., Lam, C. H. Y., & Koo, P. S. (2018). An Internet of Things (IoT)-based risk monitoring system for managing cold supply chain risks. ", { i: "Industrial Management & Data Systems, 118" }, "(7), 1432-1462. https://doi.org/10.1108/IMDS-09-2017-0384"],
 ["Vyas, A. (2021, June-July). Automatic milk sampling system: A step towards more transparency. ", { i: "Dairy Times, 5" }, "(3), 30-33. https://www.amuldairy.com/assets/img/pdf/AMCS_June_2021.pdf"],
].forEach(r => R.push(ref(r)));

module.exports = { D, S, C, F, P, H1, H2, small, figure, table, fig, runs, front, B, R, headings, TOC, FONT, PW, LW, HERE, ROOT, q, TITLE };
if (require.main === module) require("./build_report_annex.js");
