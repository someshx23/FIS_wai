"""Draws the two non-UML figures of the report: the methodology flowchart and the roadmap (Gantt) chart."""
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "03_model_source"))
from render_diagrams import Svg, wrap, arrow, FILL, PAPER, INK

OUT = Path(__file__).parent / "figures"
OUT.mkdir(exist_ok=True)


def box(svg, x, y, w, h, title, note="", strong=False):
    svg.rect(x, y, w, h, rx=6, fill=FILL if not strong else PAPER, sw=2.0 if strong else 1.1)
    lines = wrap(title, w - 14, bold=True)
    notes = wrap(note, w - 14) if note else []
    y0 = y + h / 2 - (len(lines) + len(notes) - 1) * 7.2 + 4
    for i, s in enumerate(lines):
        svg.text(x + w / 2, y0 + i * 14.4, s, bold=True)
    for i, s in enumerate(notes):
        svg.text(x + w / 2, y0 + (len(lines) + i) * 14.4, s, italic=True, fs=11.5)


def flow(svg, p, q):
    svg.line(*p, *q); arrow(svg, p, q, "filled")


def flowchart():
    s = Svg(770, 318)
    top = [(10, "Inputs", "brief, WAI policy, course outline, classroom EA file"),
           (200, "Topic and sources", "three topics compared; every source verified"),
           (390, "Requirements baseline", "20 FR, 10 NFR, use cases, acceptance criteria"),
           (580, "Model definition", "one Python file: elements, connectors, layouts")]
    for x, t, n in top:
        box(s, x, 14, 180, 70, t, n)
    for x in (190, 380, 570):
        flow(s, (x, 49), (x + 10, 49))
    s.text(385, 104, "AI drafts each step from the brief; I review. Programs then generate and check the artefacts below.", italic=True, fs=11.8)
    mid = [(10, "SQLite prototype", "schema, triggers, simulated data"), (162, "Tests and reports", "34 tests, 10 queries, dashboard"),
           (314, "EA repository", "C2D_Model.qea, 17 structural checks"), (466, "Diagram figures", "12 diagrams, layout lint"),
           (618, "Consistency checks", "12 checks, traceability matrix")]
    s.line(85, 122, 690, 122)
    s.line(670, 84, 670, 122)
    for x, t, n in mid:
        box(s, x, 140, 142, 74, t, n)
        if x != 162:
            flow(s, (x + 71, 122), (x + 71, 140))
    flow(s, (152, 177), (162, 177))
    s.line(81, 214, 81, 236); s.line(233, 214, 233, 236); s.line(385, 214, 385, 236); s.line(537, 214, 537, 236); s.line(689, 214, 689, 236)
    s.line(81, 236, 689, 236); flow(s, (385, 236), (385, 252))
    box(s, 10, 252, 750, 54, "Review in Enterprise Architect and of the report",
        "my work: open the repository, run the integrity check, read and correct the drafts", strong=True)
    s.save(OUT / "fig_method.svg")


def gantt():
    rows = [("Requirements validation at three societies", 1, 2), ("Design freeze and device procurement", 2, 4),
            ("Build 1: collection, sealing, offline sync", 3, 7), ("Build 2: chilling monitoring and exception cases", 6, 9),
            ("Build 3: dispatch, reconciliation, statements, dashboard", 8, 11), ("System and acceptance testing", 10, 12),
            ("Pilot on one route (12 societies)", 12, 14), ("Evaluation and rollout decision", 15, 15)]
    x0, w, rh, top = 318, 29, 23, 30
    s = Svg(770, top + rh * len(rows) + 14)
    for m in range(1, 16):
        s.text(x0 + w * (m - .5), 19, f"M{m}", fs=11.5)
        s.line(x0 + w * m, 25, x0 + w * m, top + rh * len(rows), sw=0.5)
    s.line(x0, 25, x0, top + rh * len(rows), sw=0.5)
    s.line(10, top - 5, x0 + 15 * w, top - 5)
    for i, (name, a, b) in enumerate(rows):
        y = top + rh * i
        s.text(10, y + 15, name, anchor="start")
        s.rect(x0 + w * (a - 1) + 1, y + 4, w * (b - a + 1) - 2, rh - 9, rx=3, fill="#9a9890", sw=0)
    s.line(10, top + rh * len(rows), x0 + 15 * w, top + rh * len(rows))
    s.save(OUT / "fig_gantt.svg")


if __name__ == "__main__":
    flowchart(); gantt()
    for n in ("fig_method", "fig_gantt"):
        subprocess.run(["rsvg-convert", "-z", "3.2", "-o", str(OUT / f"{n}.png"), str(OUT / f"{n}.svg")], check=True)
    print("figures written to", OUT)
