#!/bin/bash
# Rebuilds the report: data export, figures, DOCX (two passes for the contents page), PDF.
set -e
cd "$(dirname "$0")"
SOFFICE="${SOFFICE:-soffice}"
python3 export_report_data.py > /dev/null
python3 make_figures.py > /dev/null
rm -f toc_pages.json
for pass in 1 2; do
  node build_report.js
  zip -d WAI_Report_C2D.docx '*/' > /dev/null 2>&1 || true    # drop folder entries from the package
  $SOFFICE --headless --convert-to pdf WAI_Report_C2D.docx > /dev/null 2>&1
  python3 find_toc_pages.py
done
