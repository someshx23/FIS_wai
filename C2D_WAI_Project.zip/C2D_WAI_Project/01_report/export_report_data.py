"""Collects everything the report builder needs from the other folders into report_data.json."""
import csv
import json
import sqlite3
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "03_model_source"))
sys.path.insert(0, str(ROOT / "07_estimation"))
import c2d_model as M
import c2d_requirements as R
import fpa


def rows(name):
    with open(ROOT / "docs" / "exports" / name, encoding="utf-8") as f:
        return list(csv.reader(f))


def qea_checks():
    """Re-run the structural checks of build_qea.verify() on the delivered file and return (name, result)."""
    import build_qea, io, contextlib
    con = sqlite3.connect(f"file:{ROOT / '02_ea_model' / 'C2D_Model.qea'}?mode=ro", uri=True)
    buf = io.StringIO()
    with contextlib.redirect_stdout(buf):
        build_qea.verify(con.cursor())
    con.close()
    out = [l.strip() for l in buf.getvalue().splitlines() if l.strip().startswith("[")]
    return [[l[7:].strip().capitalize(), l[1:5]] for l in out]


db = sqlite3.connect(f"file:{ROOT / '04_database' / 'c2d_prototype.sqlite'}?mode=ro", uri=True)
counts = {t: db.execute(f"SELECT count(*) FROM {t}").fetchone()[0] for t in
          ["society", "member", "collection_shift", "collection_entry", "temperature_reading", "tank_lot", "pickup_record",
           "dock_receipt", "exception_case", "case_action", "notification", "payment_statement", "audit_event"]}
counts["chilling_cases"] = db.execute("SELECT count(*) FROM exception_case WHERE case_type='Chilling'").fetchone()[0]
counts["variance_cases"] = db.execute("SELECT count(*) FROM exception_case WHERE case_type='Variance'").fetchone()[0]
counts["tables"] = db.execute("SELECT count(*) FROM sqlite_master WHERE type='table'").fetchone()[0]
counts["triggers"] = db.execute("SELECT count(*) FROM sqlite_master WHERE type='trigger'").fetchone()[0]
counts["views"] = db.execute("SELECT count(*) FROM sqlite_master WHERE type='view'").fetchone()[0]
triggers = [r[0] for r in db.execute("SELECT name FROM sqlite_master WHERE type='trigger' ORDER BY rowid")]
# figures quoted in the text that no single reporting query returns
facts = dict(zip(("s02_chilling_cases", "s02_escalated"), db.execute("""
    SELECT count(DISTINCT c.case_id), count(DISTINCT CASE WHEN a.action_type = 'Escalate' THEN c.case_id END)
    FROM exception_case c JOIN tank_lot l ON l.lot_id = c.lot_id JOIN bulk_milk_cooler b ON b.bmc_code = l.bmc_code
    LEFT JOIN case_action a ON a.case_id = c.case_id
    WHERE c.case_type = 'Chilling' AND b.society_code = 'S02'""").fetchone()))
facts["total_kg"], facts["total_amount"] = db.execute("SELECT round(sum(quantity_kg), 1), round(sum(amount), 2) FROM collection_entry").fetchone()
facts["lots_with_chilling_case"] = db.execute("SELECT count(DISTINCT lot_id) FROM exception_case WHERE case_type='Chilling'").fetchone()[0]
db.close()

fp_rows, fp = fpa.count()
data = dict(
    fr=R.FR, nfr=R.NFR, roles=R.ROLES, access=R.ACCESS, uc_specs=R.UC_SPECS,
    usecases=[[u, n, note] for _, u, n, note in M.USECASES],
    actors=[[n, s or "person", note] for _, n, s, note in M.ACTORS],
    enums=[[k, ", ".join(v)] for k, v in M.ENUMS.items()],
    lot_trans=rows("lot_transitions.csv")[1:], rtm=rows("traceability_matrix.csv")[1:],
    mapping=rows("class_table_mapping.csv")[1:],
    classes=[[k, d["n"], len(d.get("a", ())), len(d.get("o", ()))] for k, d in {**M.CLASSES, **M.SERVICES}.items()],
    diagrams=[[d.key, d.name.split(" ", 1)[1], d.dtype, len(d.objs), d.notes, list(d.size)] for d in M.D],
    packages=M.PACKAGES,
    summary=json.loads((ROOT / "docs" / "exports" / "model_summary.json").read_text()),
    qea_checks=qea_checks(),
    tests=json.loads((ROOT / "04_database" / "outputs" / "test_results.json").read_text()),
    queries=json.loads((ROOT / "04_database" / "outputs" / "query_results.json").read_text()),
    counts=counts, facts=facts, triggers=triggers, fpa=fp, fpa_items=fp_rows, gsc=fpa.GSC,
    dashboard=json.loads((ROOT / "05_dashboard" / "dashboard.data.json").read_text())["kpi"],
)
(Path(__file__).parent / "report_data.json").write_text(json.dumps(data, indent=1), encoding="utf-8")
print("report_data.json written:", {k: (len(v) if hasattr(v, "__len__") else v) for k, v in data.items() if k not in ("summary", "queries", "fpa", "counts", "facts")})
print("counts:", counts)
