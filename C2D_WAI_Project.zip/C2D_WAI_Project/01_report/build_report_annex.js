/* Annexures and final assembly of the report. Loaded by build_report.js. */
const fs = require("fs"), path = require("path");
const { Document, Packer, Paragraph, TextRun, AlignmentType, Footer, PageNumber, NumberFormat, PageOrientation, SectionType, LineRuleType,
  TableOfContents } = require("docx");
const { D, S, C, F, P, H1, H2, small, figure, table, fig, runs, front, B, R, headings, TOC, FONT, PW, LW, HERE, ROOT, q, TITLE } = require("./build_report.js");

const note = t => P(t, { size: 21, line: 276, after: 100 });
const code = lines => lines.map(l => new Paragraph({ spacing: { line: 220, lineRule: LineRuleType.AUTO, after: 0 }, alignment: AlignmentType.LEFT,
  children: [new TextRun({ text: l.replace(/ /g, " "), font: "Courier New", size: 14 })] })).concat([new Paragraph({ spacing: { after: 120 }, children: [] })]);
const A = (text, first) => H1(text, { newPage: !first });
const cut = (s, n) => s.length > n ? s.slice(0, n - 1).trimEnd() + "…" : s;

// ---------------------------------------------------------------- A  topic selection
const AA = [A("Annexure A. Topic Selection and Scope", true),
  note("The brief suggested one direction and asked for an independent choice. Three options were compared on the criteria the brief set. The ratings are my judgement and the reason is given with each."),
  ...table("**Table A1.** Comparison of three candidate topics", [20, 26, 30, 24],
    ["Criterion", "A. Medicine replenishment and cold-chain exceptions for rural health facilities (direction suggested in the brief)", "B. Milk collection, chilling exceptions and dock reconciliation for village dairy cooperatives (selected)", "C. Operation and maintenance exceptions for rural piped-water schemes"],
    [["Fit with the classroom model (sensor, inference engine, SCADA, command centre)", "Medium: temperature loggers, little logic at the edge", "High: cooler sensor, rule engine at the society, Union server", "High, but very close to the classroom pipeline example"],
     ["Fit with the syllabus (use cases, UML, IoT and edge, RDBMS and SQL, function points)", "High", "High: twice-daily transactions give real SQL reporting", "Medium: strong on SCADA, thin on transactions"],
     ["Link to the faculty's stated research interests (supply chain, analytics, cybersecurity)", "Medium to high", "High: procurement logistics from smallholders, audit analytics, a cyber-physical system", "Medium: cyber-physical and security, little supply chain"],
     ["Requirements obtainable from published sources", "Medium: procedures differ between states", "High: NCDC, NDDB, FAO and Amul documents describe the process step by step", "Medium"],
     ["Number and clarity of actors", "Five or six", "Five roles, two devices, two external systems, two affected parties", "Four or five"],
     ["Trustworthy literature", "High", "High", "High"],
     ["Exception handling and object lifecycle", "High", "High: two exception types on one object, the tank lot", "High"],
     ["Database and reporting depth", "Medium to high", "High: pricing, sealing, reconciliation, statements", "Medium"],
     ["Originality", "Medium: it is the brief's own suggestion", "High", "Medium"]], { size: 18 }),
  ...table("**Table A2.** Selected topic", [22, 78], ["Item", "Decision"],
    [["Title", TITLE],
     ["Business problem", "A district milk union cannot see or prove what happens to milk and to measurements between the member's pour and the plant dock."],
     ["Why it matters", "Late discovery of a warm lot means sour milk, an unexplained variance means a dispute, and an unverifiable reading weakens a member's trust in the society."],
     ["Organisational setting", "An illustrative district milk union of 120 village societies on eight tanker routes. It is not a real organisation and no internal process of any organisation was studied."],
     ["Scope", "From the pour at the society to the reconciled dock receipt and the member's statement for a ten-day cycle."],
     ["Exclusions", "Plant processing, sales and distribution, animal health and breeding services, tanker routing, the bank transfer, a member mobile application."],
     ["Key users", "Society operator, route supervisor, dock officer, accounts officer, system administrator."],
     ["What is distinctive", "Measurement integrity, chilling and reconciliation are tied to one object, the tank lot, and every exception ends in a logged decision by a named role. Detection runs at the society and does not need the network."],
     ["Why UML", "The problem has several actors, an object with a real lifecycle and interactions that cross the edge unit and the server. Use case, class, state machine, sequence, activity and deployment views each answer a different question and can be checked against one another."],
     ["Why it fits the course", "It uses client requirements and specifications (Sessions 1 and 2), the as-is process (Sessions 3 and 4), the SDLC (5), use cases and UML (6 and 7), IoT and edge computing (8 to 12), project estimation with function points (13 and 14) and RDBMS and SQL (15 to 19), as an integrated proposal of the kind asked for in Session 20."]], { size: 19 })];

// ---------------------------------------------------------------- B  requirements (landscape)
const AB = [A("Annexure B. Requirements Baseline", true),
  ...table("**Table B1.** Functional requirements", [13, 27, 17, 8, 6, 22, 7],
    ["ID and name", "Requirement", "Rationale", "Actor", "Priority", "Acceptance criterion", "Use cases"],
    D.fr.map(f => [`**${f[0]}** ${f[1]}`, f[2], f[3], f[4], f[5], f[6], f[7].join(", ")]), { total: LW, size: 17 }),
  ...table("**Table B2.** Non-functional requirements. Figures are design targets, not measured results.", [8, 16, 40, 36],
    ["ID", "Quality attribute", "Requirement and design target", "Verification"], D.nfr.map(n => [`**${n[0]}**`, n[1], n[2], n[3]]), { total: LW, size: 18 }),
  ...table("**Table B3.** Access matrix (NFR-01): roles allowed to start each use case", [30, 12, 12, 12, 12, 12, 10],
    ["Use case", ...D.roles, "Other"], D.usecases.map(u => [`${u[0]} ${u[1]}`, ...D.roles.map(r => D.access[u[0]].includes(r) ? "Yes" : ""), D.access[u[0]].length ? "" : "Device or system"]),
    { total: LW, size: 18 })];

// ---------------------------------------------------------------- C  use-case specifications
const AC = [A("Annexure C. Use-Case Specifications", true),
  note("Four use cases carry most of the design and are specified in full. The other eleven are described in Table D2.")];
for (const [uid, s] of Object.entries(D.uc_specs)) {
  const name = D.usecases.find(u => u[0] === uid)[1];
  AC.push(...table(`**${uid} ${name}**`, [22, 78], ["Field", "Content"],
    [["Goal", s.goal], ["Primary actor", s.primary], ["Secondary actors", s.secondary], ["Trigger", s.trigger], ["Preconditions", s.pre.join("\n")],
     ["Basic flow", s.basic.map((x, i) => `${i + 1}. ${x}`).join("\n")], ["Alternate and exception flows", s.alt.join("\n")],
     ["Postconditions", s.post.join("\n")], ["Requirements", s.frs.join(", ")]], { size: 19 }));
}

// ---------------------------------------------------------------- D  UML model
const pk = Object.fromEntries(D.packages.map(p => [p[0], p[1]]));
const dpk = { "UC-01": "UCM", "REQ-01": "REQ", "DEP-01": "ARC" };
const AD = [A("Annexure D. UML Model", false),
  note(`The model is held in the Enterprise Architect project C2D_Model.qea. Its root package, C2D System, has five packages: ${D.packages.slice(1).map(p => p[1]).join("; ")}. The figures below are drawn from the model definition by render_diagrams.py and use the same element positions as the repository.`),
  ...table("**Table D1.** Diagrams in the model", [11, 27, 12, 11, 39], ["Diagram", "Name", "Type", "Elements", "Purpose"],
    D.diagrams.map(d => [d[0], d[1], d[2] === "Logical" ? "Class" : d[2] === "Statechart" ? "State machine" : d[2] === "Custom" ? "Requirements" : d[2], d[3], d[4]]), { size: 18 }),
  ...table("**Table D2.** Use cases", [9, 26, 45, 20], ["ID", "Use case", "Description", "Started by"],
    D.usecases.map(u => [u[0], u[1], u[2], D.access[u[0]].join(", ") || "Device or system"]), { size: 18 }),
  ...table("**Table D3.** Actors", [24, 14, 62], ["Actor", "Kind", "Description"], D.actors, { size: 18 }),
  new Paragraph({ pageBreakBefore: true, children: [] }),
  ...figure(fig("ACT-01"), "**Figure D1.** Activity diagram ACT-01: one tank lot from collection to dock, with the chilling and variance exception paths.", 602, 800),
  ...figure(fig("SEQ-01"), "**Figure D2.** Sequence diagram SEQ-01: detecting and handling a chilling excursion (UC-04 to UC-07).", 602, 470),
  ...figure(fig("STM-02"), "**Figure D3.** State machine STM-02: lifecycle of an exception case.", 560, 200),
  ...figure(fig("SEQ-02"), "**Figure D4.** Sequence diagram SEQ-02: recording a collection entry and sealing the shift (UC-01 to UC-03).", 602, 500),
  ...figure(fig("CLS-04"), "**Figure D5.** Class diagram CLS-04: control classes and their dependencies.", 602, 240),
  ...figure(fig("STM-01"), "**Figure D6.** State machine STM-01: lifecycle of a tank lot. Transitions are listed in Table D4.", 602, 400),
  ...figure(fig("CLS-01"), "**Figure D7.** Class diagram CLS-01: domain classes, names and multiplicities only.", 602, 330),
  ...table("**Table D4.** Transitions of the tank lot state machine (STM-01)", [7, 12, 12, 11, 13, 9, 36], ["ID", "From", "To", "Trigger", "Guard", "Effect", "Meaning"], D.lot_trans, { size: 17 }),
  ...table("**Table D5.** Classes", [20, 7, 7, 66], ["Class", "Attr.", "Oper.", "Description"], D.classes.map(c => [c[0], c[2], c[3], c[1]]), { size: 17 }),
  ...table("**Table D6.** Enumerations used as attribute types. They are type names in the repository, not separate elements, and are enforced as value lists in the database.", [22, 78], ["Enumeration", "Literals"], D.enums, { size: 17 })];
const ADL = [...figure(fig("CLS-02"), "**Figure D8.** Class diagram CLS-02: collection, pricing, chilling and security classes.", 925, 545),
  new Paragraph({ pageBreakBefore: true, children: [] }),
  ...figure(fig("CLS-03"), "**Figure D9.** Class diagram CLS-03: exception, dispatch, reconciliation and payment classes.", 925, 545)];

// ---------------------------------------------------------------- E  traceability (landscape)
const AE = [A("Annexure E. Requirements Traceability Matrix", false),
  note("Each requirement is traced to use cases, model elements, diagrams and its verification. Acceptance criteria are in Table B1; test evidence is in Table G3."),
  ...table("", [17, 6, 10, 33, 13, 21], ["Requirement", "Priority", "Use cases", "Model elements", "Diagrams", "Verified by"],
    D.rtm.map(r => [`**${r[0]}** ${r[1]}`, r[2], r[3], r[4], r[5], r[7]]), { total: LW, size: 16, pad: 22 })];

// ---------------------------------------------------------------- F  database
const trg = { trg_entry_only_in_open_shift: "No entry can be added to a sealed shift (FR-05).", trg_sealed_entry_no_update: "A sealed entry cannot be changed; only its synchronisation time may still be set (FR-05, FR-06).",
  trg_sealed_entry_no_delete: "A sealed entry cannot be deleted (FR-05).", trg_lot_transition: "A lot status change must be a transition of STM-01 (FR-11).",
  trg_case_action_no_update: "A logged action cannot be edited (FR-10).", trg_case_action_no_delete: "A logged action cannot be deleted (FR-10).",
  trg_chart_line_frozen_update: "Lines of an approved rate chart cannot be edited (FR-17).", trg_chart_line_frozen_insert: "Lines cannot be added to an approved rate chart (FR-17).",
  trg_cycle_needs_sealed_shifts: "A payment cycle with an unsealed shift cannot be approved (FR-16).", trg_reading_from_active_sensor: "A reading is accepted only from a registered, active sensor (FR-18)." };
const qt = (id, widths, size) => table(`**Table F${id.slice(1)}.** Query ${id}: ${q(id).title} (synthetic data)`, widths || q(id).columns.map(() => 1), q(id).columns.map(c => c.replace(/_/g, " ")), q(id).rows, { size: size || 16 });
const AF = [A("Annexure F. Database Design and SQL", false),
  note(`The prototype is a SQLite database (c2d_prototype.sqlite) built by schema.sql and filled by generate_data.py. It has ${C.tables} tables, ${C.triggers} triggers and ${C.views} views. All figures in this annexure come from the synthetic data set.`),
  H2("F.1 From classes to tables"),
  note("A UML class is not a table. Operations have no column, an association becomes a foreign key on the side with multiplicity one, a composition becomes a foreign key that cannot be null, and inheritance needs an explicit mapping. ExceptionCase and its two subclasses are stored in one table with a discriminator column (case_type); CHECK constraints keep each subtype's columns consistent. Two tables have no class: lot_transition holds the transitions of STM-01 as data, and config holds thresholds."),
  ...table("**Table F0.** Class-to-table mapping", [28, 26, 46], ["Class", "Table", "Note"], D.mapping, { size: 17 }),
  H2("F.2 Normalisation"),
  note("Every table has a single-attribute or declared composite primary key and no repeating groups (first normal form). Non-key attributes depend on the whole key; rate_chart_line, the only table with a composite key, has no attribute that depends on part of it (second normal form). Transitive dependencies were removed in two places: a tanker trip stores no route, since the route follows from the societies collected from, and a temperature reading stores its cooler but not its lot, which is derived from the cooler and the time (third normal form). Three redundancies are deliberate: collection_entry keeps rate_per_kg and amount because the sealed record must show what was charged even after a chart is superseded, and a CHECK constraint ties amount to quantity times rate; tank_lot.quantity_kg is stored at sealing; payment_statement totals are a snapshot of the ledger at approval."),
  H2("F.3 Triggers"),
  ...table("", [38, 62], ["Trigger", "Rule enforced"], D.triggers.map(n => [n, trg[n]]), { size: 17 }),
  H2("F.4 Representative queries and their results"),
  ...code(q("Q3").sql.split("\n")),
  ...qt("Q3", [7, 6, 9, 13, 11, 14, 10, 13, 12]),
  ...qt("Q2", [8, 7, 6, 12, 11, 10, 10, 10]),
  ...qt("Q5", [10, 10, 12, 10, 14, 18]),
  ...qt("Q7", [10, 8, 14, 14, 12, 14]),
  ...qt("Q4", [10, 7, 9, 9, 16, 16, 12]),
  ...qt("Q1", [6, 6, 10, 10, 10, 10, 9, 9, 9, 9, 8]),
  ...qt("Q10", [10, 22, 10, 16])];

// ---------------------------------------------------------------- G  verification
const AG = [A("Annexure G. Verification Record", false),
  note("Everything in this annexure was executed in the AI workspace by the programs named. None of it replaces opening the model in Enterprise Architect, which is recorded in Annexure K."),
  ...table("**Table G1.** Cross-artefact consistency checks (check_model.py)", [7, 83, 10], ["ID", "Check", "Result"], S.checks.map(c => [c.id, c.check, c.result]), { size: 17 }),
  ...table("**Table G2.** Structural checks on the Enterprise Architect repository (build_qea.py). Each row reads: the repository has ...", [86, 14], ["Check", "Result"], D.qea_checks, { size: 17 }),
  ...table("**Table G3.** Acceptance tests executed on the SQLite prototype (run_checks.py)", [8, 12, 34, 7, 39], ["Test", "Requirement", "What is tested", "Result", "Evidence"],
    D.tests.map(t => [t.id, t.requirement, t.test, t.result, cut(t.evidence, 120)]), { size: 16 }),
  ...table("**Table G4.** Test of the checks themselves: defects planted in the model and the check that caught each", [62, 38], ["Defect planted", "Checks that failed"],
    [["An extra literal added to the LotStatus enumeration", "C05, C10"], ["A sequence message renamed to an operation the class does not have", "C04"],
     ["The guard removed from one branch of a decision", "C07"], ["One transition removed from the model's transition list", "C11"],
     ["An attribute added to DockReceipt with no column in the schema", "C09"], ["The requirement link of UC-15 removed", "C01, C12"],
     ["The association between System Administrator and UC-12 removed", "C02, C12"]], { size: 17 })];

// ---------------------------------------------------------------- H  function points
const eff = Object.entries(F.effort).map(([k, v]) => [k.split("@")[0], k.split("@")[1], v.kloc, v.person_months, v.months]);
const AH = [A("Annexure H. Function Point Count", false),
  note("Counted with the IFPUG component types and complexity matrices. RET is the number of record element types of a logical file, FTR the number of files an elementary process references, and DET the number of data element types."),
  ...table("**Table H1.** Summary of the count", [40, 12, 12, 12, 14], ["Component (weights low / average / high)", "Low", "Average", "High", "Points"],
    [["Internal logical files (7 / 10 / 15)", ...F.summary.ILF, F.by_type.ILF], ["External interface files (5 / 7 / 10)", ...F.summary.EIF, F.by_type.EIF],
     ["External inputs (3 / 4 / 6)", ...F.summary.EI, F.by_type.EI], ["External outputs (4 / 5 / 7)", ...F.summary.EO, F.by_type.EO],
     ["External inquiries (3 / 4 / 6)", ...F.summary.EQ, F.by_type.EQ], ["**Unadjusted function points**", "", "", "", `**${F.ufp}**`],
     [`**Adjusted function points** (value adjustment factor 0.65 + 0.01 x ${F.tdi} = ${F.vaf})`, "", "", "", `**${F.afp}**`]], { size: 18 }),
  ...table("**Table H2.** Functions counted", [7, 31, 30, 9, 7, 9, 7], ["Type", "Function", "Source in the design", "RET or FTR", "DET", "Complexity", "Points"], D.fpa_items, { size: 15, pad: 14 }),
  ...table("**Table H3.** General system characteristics (0 = no influence, 5 = strong influence)", [30, 10, 60], ["Characteristic", "Rating", "Reason"], D.gsc, { size: 17 }),
  ...table(`**Table H4.** Indicative effort from ${F.afp} adjusted function points with Basic COCOMO (Boehm, 1981). The lines-per-function-point values are assumptions.`, [22, 20, 18, 20, 20],
    ["COCOMO mode", "Lines per function point", "KLOC", "Effort (person-months)", "Schedule (months)"], eff, { size: 17 })];

// ---------------------------------------------------------------- I  dashboard
const AI = [A("Annexure I. Dashboard", false),
  note("The dashboard is one self-contained HTML file (05_dashboard/dashboard.html) that draws seven views from the prototype database, with a route filter, hover read-outs and a table view under each chart. Figure 4 in the report shows four views; Figure I1 shows the other three. All values are synthetic."),
  ...table("**Table I1.** Headline figures on the dashboard (synthetic data)", [36, 22, 42], ["Measure", "Value", "Note"], D.dashboard, { size: 18 }),
  ...figure(path.join(ROOT, "05_dashboard", "charts", "dashboard_annex_panel.png"), "**Figure I1.** Daily collection by route, exception cases by society, and one warm-holding case from alert to decision.", 602, 560)];

// ---------------------------------------------------------------- J  prompt logbook (landscape)
const LOG = [
 ["1", "[[Paste the prompt you gave ChatGPT to produce the master prompt.]]", "ChatGPT", "A master prompt of about 3,300 words in 13 numbered sections, setting roles, an order of precedence between documents, a research standard and prohibitions on invented sources and results.", "Used as the brief for the Claude session (row 2). Full text: 06_logbook/master_prompt.txt.", "[[Your reflection.]]"],
 ["2", "The master prompt, with the course outline, the WAI policy and my classroom file Session_3.qea attached, and this instruction added by me: \"this is a self genrated prompt by chatgpt choos etopic on your own dont rely on topic given in this prompt\".", "Claude (Fable 5.2), agentic session", "Read all attachments. Reported that the WAI policy asks for a 10 to 12 page report in a fixed structure plus logbook, code, dashboard, slides and video, which the prompt had not assumed (the deck and video were later confirmed as not required); that the prompt file was cut off mid-sentence; and that the classroom model uses deployment, class, sequence and activity diagrams.", "Decided the structure of the report and the list of deliverables.", "The first useful output was a correction to my own brief. Reading the source documents before generating anything avoided building the wrong deliverable."],
 ["3", "Same session. Prompt section 4, Select an original, specific and feasible project topic: \"Compare it briefly against two genuinely differentiated alternatives.\"", "Claude", "Three topics compared on nine criteria; the dairy first-mile topic selected over the suggested health topic and a rural water topic.", "Annexure A; Section 1.", "The choice rested on where requirements could be taken from published process descriptions, not on which topic sounded most advanced."],
 ["4", "Same session. Prompt section 5: \"Never fabricate journal articles, DOIs, references, quotations, organisational statistics or empirical findings.\"", "Claude with web search", "Sources verified against Crossref, OpenAlex or publisher pages; 22 are cited. Bibliographic details of several entries differed from secondary listings and were taken from the index records. One paper whose abstract could not be read was dropped.", "Sections 1 and 2; References.", "Verification changed details I would have copied without checking. A source read only at the level of its record is cited only for what its title establishes."],
 ["5", "Same session. Prompt section 6: requirements with rationale, actor, priority, acceptance criterion and traceability.", "Claude", `${S.fr} functional and ${S.nfr} non-functional requirements, four use-case specifications and an access matrix, written as data in one file.`, "Section 5.1; Annexures B, C and E.", "Writing an acceptance criterion for each requirement exposed vague ones early. Thresholds are marked as design values because nothing in the project measured them."],
 ["6", "Same session. Prompt sections 7 and 8: UML model and an editable Enterprise Architect project; \"Only say that a model was imported, opened or tested when this actually occurred.\"", "Claude with code execution", `One model definition (${S.elements} elements, ${S.diagrams.length} diagrams); a .qea repository written in the format of my classroom file; ${D.qea_checks.length} structural checks; diagram figures; ${S.checks.length} consistency checks, tested by planting seven defects. The AI stated that it could not open the file in Enterprise Architect.`, "Section 5; Annexure D; the EA project file.", "The AI was explicit about what it had not verified. Opening the model and running the integrity check remained my task (Annexure K)."],
 ["7", "Same session. Prompt section 9: database design, SQLite prototype, executed SQL.", "Claude with code execution", `Schema with ${C.tables} tables and ${C.triggers} triggers, a simulation of 30 days for 12 societies, 10 reporting queries and ${D.tests.length} acceptance tests. Two problems were found and fixed during the run: a rounding rule that rejected valid amounts, and a test that passed for the wrong reason because a different rule refused the insert.`, "Sections 4 and 5.6 to 5.8; Annexures F and G.", "A passing test still has to be read. The manual-entry test was rewritten to run in an open shift, with a control case that must be accepted."],
 ["8", "Same session. Prompt section 10: function point analysis; \"Do not generate arbitrary development-cost estimates or pseudo-precise timelines.\"", "Claude with code execution", `Count of ${F.ufp} unadjusted and ${F.afp} adjusted function points computed from itemised functions; effort shown as a range under stated assumptions.`, "Section 7; Annexure H.", "The count is reproducible from the item list. The effort range is wide because the assumptions are."],
 ["9", "Same session. WAI policy 4.4: dashboard with 5 to 7 visual insights.", "Claude with code execution", "A self-contained HTML dashboard with seven views drawn from the prototype database, labelled as synthetic.", "Section 5.8; Annexure I; 05_dashboard.", "The views show that the design can answer supervisory questions. They are not findings about any real union."],
 ["10", "Same session. Prompt sections 11 to 13 and WAI policy 4.1: report of 10 to 12 pages.", "Claude", "This report, with the main text held to the page limit and detail moved to annexures.", "The whole document.", "[[Your reflection on what you changed after reading the draft.]]"],
 ["11", "Second message in the same session: \"make it real quick as the deck and video are not required.\"", "Claude", "The slide deck and the video script were dropped. The report was finished with the main text and the references held to 12 pages and the detail moved to annexures.", "Scope of the submission.", "[[Your reflection.]]"],
 ["12", "[[Any later prompt you give, for example to change wording or a diagram.]]", "", "", "", ""],
];
const AJ = [A("Annexure J. Prompt Logbook", false),
  note("The Claude work was one long agentic session started by a single prompt. Rows 3 to 10 are stages of that session, each tied to the part of the prompt that asked for it; they are not separate prompts. Row 11 is my only other message. The reflections in rows 2 to 9 were drafted with the AI from what happened in the session. [[Confirm or rewrite each reflection in your own words, and check the model name shown in your Claude app.]]"),
  ...table("", [4, 26, 10, 26, 14, 20], ["No.", "Prompt text", "Tool", "Output summary", "Use in the project", "Reflection"], LOG, { total: LW, size: 17 })];

// ---------------------------------------------------------------- K  Enterprise Architect guide
const AK = [A("Annexure K. Enterprise Architect: Opening, Checking and Editing the Model", false),
  note("C2D_Model.qea is a native Enterprise Architect project in the .qea format (SQLite), which is the default file format from version 16. It was written by a program, not saved by Enterprise Architect, so the first step is to check it."),
  ...table("**Table K1.** Steps", [6, 94], ["Step", "Action"],
    [["1", "Copy C2D_Model.qea to a local folder and open it in Enterprise Architect 16 or later (File, Open Project). Keep an untouched copy."],
     ["2", "In the Browser, expand Model, then C2D System. Five packages should appear: 01 Requirements to 05 Architecture."],
     ["3", "Run the integrity check: Settings ribbon, Model, Integrity, Project Integrity. Choose Report Only first and read the result. If anything is listed, run it again with Recover/Clean on a copy and note what was changed."],
     ["4", "Open each of the 12 diagrams by double-click. Check that elements and connectors appear as in Annexure D. Labels may sit in slightly different places; drag them if needed and save."],
     ["5", "Open the properties of one class (for example CollectionEntry), one use case (UC-01, Scenarios tab), one transition on STM-01 (guard and effect) and one message on SEQ-01."],
     ["6", "Traceability: Design ribbon, Impact, Matrix. Source package 02 Use Case Model, target package 01 Requirements, link type Realisation, direction Source to Target."],
     ["7", "Export each diagram (Publish ribbon, Diagram Image, Save to File, PNG) and replace the figures in this report with the exports if they differ."],
     ["8", "If the file does not open, use the fallback: create an empty project, open the Scripting window (Specialize ribbon, Tools, Scripting), create a JavaScript script, paste 02_ea_model/C2D_build_script.js and run it. It builds the same model through the Automation Interface."]], { size: 18 }),
  ...table("**Table K2.** Validation record, to be completed by me before submission", [34, 66], ["Item", "Result"],
    [["Enterprise Architect version, build and edition", "[[fill in]]"], ["Date opened", "[[fill in]]"], ["File opened without error", "[[yes or no, with any message]]"],
     ["Project Integrity Check result", "[[fill in]]"], ["Diagrams opened and compared with Annexure D", "[[12 of 12, or list differences]]"],
     ["Changes I made in Enterprise Architect", "[[list, or none]]"], ["Figures replaced by Enterprise Architect exports", "[[list, or none]]"]], { size: 18 })];

// ---------------------------------------------------------------- L  repository and policy checklist
const AL = [A("Annexure L. Repository and Policy Checklist", false),
  note("Repository link: [[paste your GitHub or Drive link]]. README.md in the top folder gives the commands that rebuild every artefact from the model definition."),
  ...table("**Table L1.** Repository structure", [22, 78], ["Folder", "Contents"],
    [["01_report", "This report (DOCX and PDF) and the programs that build it from the data and the figures"],
     ["02_ea_model", "C2D_Model.qea, the fallback build script for Enterprise Architect, and the 12 diagrams as PNG and SVG"],
     ["03_model_source", "c2d_requirements.py and c2d_model.py (the single definition), build_qea.py, render_diagrams.py, check_model.py"],
     ["04_database", "schema.sql, chilling_rules.py, generate_data.py, queries.sql, run_checks.py, c2d_prototype.sqlite and the outputs of the queries and tests"],
     ["05_dashboard", "dashboard.html, build_dashboard.py and chart images"],
     ["06_logbook", "Prompt logbook and the full master prompt"],
     ["07_estimation", "fpa.py and the function point results"],
     ["data", "The synthetic data set as CSV files, with a data dictionary"],
     ["docs", "Enterprise Architect guide, source verification log, requirement-to-deliverable matrix, model exports as CSV"]], { size: 18 }),
  ...table("**Table L2.** WAI policy requirements and where each is met", [34, 46, 20], ["Policy item", "Where", "Status"],
    [["3.1 Problem identification (eight parts)", "Section 1", "Done"], ["3.2 Literature review, 8 to 10 sources minimum", "Section 2 (12 sources); References (22)", "Done"],
     ["3.3 Methodology with flowchart; 3.4 AI tools", "Section 3, Figure 1", "Done"], ["3.5 Data collection and preparation; synthetic data disclosed", "Section 4", "Done"],
     ["3.6 Analysis and insights: visualisations, code output, dashboard", "Section 5, Figures 2 to 4; Annexures D, F, G, I", "Done"],
     ["3.7 Managerial recommendations", "Section 6", "Done; break-even condition stated, costs not quantified"], ["3.8 Implementation roadmap: timeline, resources, training, risks", "Section 7, Figure 5; Annexure H", "Done"],
     ["3.9 Ethical, legal and bias considerations", "Section 8", "Done"], ["4.1 Report of 10 to 12 pages", "Pages 1 to 12: main text and references", "Done; annexures follow from page 13"],
     ["4.2 Prompt logbook", "Annexure J; 06_logbook", "Rows 1, 10 to 12 and the reflections need my input"], ["4.3 Code submission with comments", "03_model_source, 04_database, 05_dashboard, 07_estimation", "Done"],
     ["4.4 Dashboard with 5 to 7 visual insights", "05_dashboard/dashboard.html (seven views)", "Done"], ["4.5 Slide deck; 4.6 Video presentation", "Not part of this submission", "Not required for this submission"], ["4.7 Data files and repository link", "This annexure", "I must upload and paste the link"],
     ["5 Formatting: Times New Roman 12, 1.5 spacing, 1-inch margins, APA, justified", "Whole report; tables and captions are set smaller", "Done"],
     ["Course outline: title page, contents, abstract, introduction, methodology, results, discussion, conclusion, references; hard copy and PDF", "Section titles carry both vocabularies", "Print the hard copy"]], { size: 18 })];

// ---------------------------------------------------------------- assembly
const toc = new TableOfContents("Contents", { headingStyleRange: "1-1", hyperlink: true, beginDirty: false,
  cachedEntries: headings.map(h => ({ title: h.text, level: 1, page: TOC[h.text] === undefined ? "0" : String(TOC[h.text]) })) });
const frontChildren = front.flatMap(x => x === "__TOC__" ? [toc] : [x]);
const footer = () => new Footer({ children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ children: [PageNumber.CURRENT], font: FONT, size: 20 })] })] });
const margin = { top: 1440, right: 1440, bottom: 1440, left: 1440 };
// Title page and contents carry no page number. Numbering starts at 1 on the Executive Summary and runs on through the annexures.
const portrait = (children, o = {}) => ({ properties: { type: SectionType.NEXT_PAGE, page: { margin, ...(o.start ? { pageNumbers: { start: 1, formatType: NumberFormat.DECIMAL } } : {}) } },
  footers: o.footer === null ? {} : { default: footer() }, children });
const landscape = children => ({ properties: { type: SectionType.NEXT_PAGE, page: { margin, size: { width: 11906, height: 16838, orientation: PageOrientation.LANDSCAPE } } },
  footers: { default: footer() }, children });

const doc = new Document({
  creator: "", title: "WAI Project Report: C2D system", description: "Fundamentals of Information Systems, IIM Ranchi",
  styles: { default: { document: { run: { font: FONT, size: 24 } },
    heading1: { run: { font: FONT, size: 26, bold: true, color: "000000" }, paragraph: { spacing: { before: 200, after: 100, line: 300 }, keepNext: true } },
    heading2: { run: { font: FONT, size: 24, bold: true, color: "000000" }, paragraph: { spacing: { before: 140, after: 80, line: 300 }, keepNext: true } } },
    paragraphStyles: [{ id: "TOC1", name: "toc 1", basedOn: "Normal", next: "Normal", quickFormat: true, run: { font: FONT, size: 23 }, paragraph: { spacing: { line: 300, after: 40 } } }] },
  sections: [
    portrait(frontChildren, { footer: null }),
    portrait([...B, ...R], { start: true }),
    portrait(AA), landscape(AB), portrait([...AC, ...AD]), landscape([...ADL, ...AE]), portrait([...AF, ...AG, ...AH, ...AI]), landscape(AJ), portrait([...AK, ...AL]),
  ],
});
const mdCell = t => String(t).replace(/\[\[([^\]]+)\]\]/g, "**[$1]**").replace(/\|/g, "/").replace(/\n/g, " ");
fs.writeFileSync(path.join(ROOT, "06_logbook", "prompt_logbook.md"), ["# Prompt logbook", "",
  "WAI project, Fundamentals of Information Systems. Fields follow the WAI evaluation policy: prompt text, tool, output summary, usage, reflection.", "",
  "The Claude work was one long agentic session started by a single prompt (`master_prompt.txt` in this folder, with three attachments). Rows 3 to 10 are stages of that session, each tied to the part of the prompt that asked for it; they are not separate prompts. Row 11 is the only other message sent. Items in bold square brackets are for the student to complete. The reflections in rows 2 to 9 were drafted with the AI from what happened in the session and should be confirmed or rewritten in the student's own words.", "",
  "| No. | Prompt text | Tool | Output summary | Use in the project | Reflection |", "|---|---|---|---|---|---|",
  ...LOG.map(r => "| " + r.map(mdCell).join(" | ") + " |"), ""].join("\n"));
Packer.toBuffer(doc).then(buf => { const out = path.join(HERE, "WAI_Report_C2D.docx"); fs.writeFileSync(out, buf);
  fs.writeFileSync(path.join(HERE, "toc_headings.json"), JSON.stringify(headings.map(h => h.text)));
  console.log("written", out, Math.round(buf.length / 1024) + " KB,", headings.length, "headings"); });
