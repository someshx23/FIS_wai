# Source verification log

Every reference in the report was checked before it was cited. Sources with a DOI were looked up in Crossref (`api.crossref.org/works/<DOI>`), and authors, year, volume, issue and pages in the reference list are taken from those records. Abstracts were read on the publisher's page or through OpenAlex. Documents without a DOI were opened at the address given. The column "Basis" says how much of each source was actually read, and the report claims no more than that.

| # | Source | Basis | What the report takes from it |
|---|---|---|---|
| 1 | Albrecht & Gaffney (1983), IEEE TSE | Bibliographic record | Origin of function point analysis; the counting rules used are the standard component weights |
| 2 | Boehm (1981), Software engineering economics | Standard text, not re-read | Basic COCOMO coefficients for organic and semi-detached projects |
| 3 | Bowonder, Raghu Prasad & Kotla (2005), IJSTM | Abstract (OpenAlex) | The Amul system made prompt cash payment easy for farmers; well-designed ICT platforms can benefit the rural poor |
| 4 | Cámara, Troya, Burgueño & Vallecillo (2023), SoSyM | Abstract | Limits of ChatGPT on UML modelling: syntactic and semantic defects, inconsistent answers, scalability |
| 5 | Chen et al. (2023), MODELS | Abstract (OpenAlex) | F1 of 0.76, 0.61 and 0.34 for classes, attributes and relationships; high precision, low recall |
| 6 | DAHD (2025), Basic animal husbandry statistics | Document | Milk production of 247.87 million tonnes in 2024-25 |
| 7 | Digital Personal Data Protection Act, 2023 | Statute, cited by title | Mobile numbers and bank references are personal data |
| 8 | FSSAI (2019), National milk safety and quality survey 2018 | Document | 6,432 samples; about 41% short on a quality parameter although safe |
| 9 | Gupta et al. (2020), IEEE Access | Bibliographic record, title | Security and privacy are recognised challenges in smart farming |
| 10 | Moffat et al. (2016), FAO | First part of the document only | Cooling targets (10 °C within two hours, 4 °C within three to four hours); standby power where supply is unreliable |
| 11 | NCDC (n.d.), sample project report | Document | Twice-daily collection, slip for each pour, payment every ten days; souring, adulteration and lack of transparency as reasons to invest |
| 12 | NDDB (n.d.), AMCS article | Document | The software integrates scale and analyser and covers cooler monitoring, periodic billing and rule-based centralised audit |
| 13 | Object Management Group (2017), UML 2.5.1 | Specification page | Version of the notation used |
| 14 | Sandhu et al. (1996), Computer | Bibliographic record; standard result | Definition of role-based access control |
| 15 | Schneier & Kelsey (1999), ACM TISSEC | Bibliographic record; standard result | Tamper-evident logs through cryptographic chaining |
| 16 | Shi et al. (2016), IEEE IoT Journal | Abstract (OpenAlex) | Edge computing processes data at the network edge; concerns of response time, bandwidth cost, data safety and privacy |
| 17 | Singh, Lai & Huang (2026), Business Horizons | Bibliographic record, title | Cited for its topic only |
| 18 | Singh, Panigrahi, Zhang & Jasimuddin (2025), J. Intelligent Manufacturing | Bibliographic record, title | Cited for its topic only |
| 19 | Sparx Systems (n.d.), EA user guide 17.2 | Web page | A `.qea` file is a SQLite database and the default format from version 16 |
| 20 | Tegarden et al. (2025), Wiley | Publisher's record | Prescribed text; phases of the systems development life cycle |
| 21 | Tsang et al. (2018), IMDS | Abstract (OpenAlex) | Three components (wireless sensor network, cloud database, fuzzy logic); before-and-after comparison at a service provider |
| 22 | Vyas (2021), Dairy Times | Document | Dip-stick measurement, manual sampling and tampering make members sceptical; flow meter, temperature record and door alerts on tankers |

## Notes for the student

- **Vyas (2021).** The article page carries no byline. The author is taken from the profile panel printed with the article, which names Mr Amit Vyas, Managing Director, Amul Dairy.
- **Tegarden et al. (2025).** The course outline cites this text as Dennis, Wixom and Tegarden (2024), 7th edition. The publisher's record for the 7th edition lists Tegarden, Samuel, Lukyanenko, Dennis and Wixom, published by Wiley in 2025 (ISBN 978-1-394-33176-5). The report follows the publisher's record. Check the copy you were issued and change the reference if your edition differs.
- **Singh et al. (2025, 2026).** These are papers by the course faculty. Details on the faculty web page differ slightly from the index records (the full title, volume and year of the 2026 paper; a fourth author and the print year of the 2025 paper). The report follows Crossref. They are cited for what their titles establish, and no endorsement of this project is implied.
- **Set aside.** Three candidate sources were set aside during verification, one of them because its DOI could not be found in Crossref. Six verified sources were dropped when the report was shortened to fit the page limit; one of them (Kumar et al., 2019, Food Policy) could be read only at the level of its title.
- **Sources the report relies on for design values.** The four-hour limit for reaching 4 °C follows Moffat et al. (2016). The other thresholds and tolerances (30 minutes above 7 °C, 20 minutes of sensor silence, 15 minutes to acknowledge, 0.5% on quantity, 0.10 on fat, 0.20 on SNF) are design values chosen for the prototype and are labelled as such in the report.
