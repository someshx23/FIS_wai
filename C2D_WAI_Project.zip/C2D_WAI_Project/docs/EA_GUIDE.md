# Enterprise Architect guide for the C2D model

`02_ea_model/C2D_Model.qea` is a native Enterprise Architect project in the `.qea` format. A `.qea` file is a SQLite database, and it is the default project format from Enterprise Architect 16. Any edition of version 16 or 17, including the trial, can open it.

**How the file was made.** A program (`03_model_source/build_qea.py`) took the classroom project file, removed every model row, and wrote the C2D model as rows that follow the conventions Enterprise Architect itself used in that file. The file was then checked with 17 structural tests and reconciled, count by count, with the model definition. **It has not yet been opened in Enterprise Architect**, because the AI workspace cannot run the program. The first thing to do is therefore to open it and check it. This takes about ten minutes.

Ribbon names below are those of versions 15 to 17. If your build shows a different layout, type the command name in the search box at the top right of the ribbon.

## 1. Open and check (do this before anything else)

1. Copy `C2D_Model.qea` to a local folder (not a zipped or cloud-synced folder) and keep an untouched second copy.
2. Start Enterprise Architect and open the file: **Open Project** (Ctrl+O), then browse to the file.
3. In the **Browser** window expand `Model`, then `C2D System`. You should see five packages, `01 Requirements` to `05 Architecture`.
4. Run the integrity check: **Settings > Model > Integrity > Project Integrity**. Leave all boxes ticked, choose **Report Only** and click **Go**. Read the list.
   - If it reports nothing, note that in the validation record (report, Annexure K).
   - If it lists items, run it again on your working copy with **Recover/Clean**, and note what it changed. Small repairs such as missing cross-references are normal for a file written from outside and do not change the model.
5. Open each of the 12 diagrams by double-clicking it and compare it with the figure of the same name in the report or in `02_ea_model/diagrams/`. Elements should be in the same places. Enterprise Architect may route a connector or place a label a little differently. Drag where needed and save (Ctrl+S).
6. Fill in the validation record in Annexure K of the report, and complete the sentence in Section 3.5.

If the file does not open, or a diagram is empty, go to section 6.

## 2. What is in the model

| Package | Contents | Diagrams |
|---|---|---|
| 01 Requirements | 20 functional and 10 non-functional requirements, each with priority and acceptance criterion as tagged values | REQ-01 Requirements catalogue |
| 02 Use Case Model | 11 actors, 15 use cases, system boundary; include and extend relationships; realisation links from each use case to the requirements it satisfies; scenarios for UC-01, UC-04, UC-07, UC-09 | UC-01 Use cases of the C2D system |
| 03 Domain Model | 23 entity classes and 5 control classes with 121 attributes and 30 operations; associations with multiplicities, 4 compositions, 2 generalisations | CLS-01 overview, CLS-02 and CLS-03 detail, CLS-04 control classes |
| 04 Behaviour | Activity with five partitions; two state machines; two interactions | ACT-01, STM-01, STM-02, SEQ-01, SEQ-02 |
| 05 Architecture | Devices, nodes and components; communication paths | DEP-01 Edge and Union deployment |

Totals: 161 elements, 141 connectors, 24 sequence messages, 12 diagrams. `docs/exports/` has the same content as CSV files (actors, use cases, classes, relationships, transitions, traceability).

Enumerations such as `LotStatus` and `CaseStatus` are used as attribute type names. They are listed in the report (Annexure D, Table D6) and in `docs/exports/enumerations.csv`, and they are enforced in the database as CHECK constraints. They are not separate elements in the repository. To add one, right-click `03 Domain Model`, choose **Add Element**, type **Enumeration**, and enter the literals as attributes.

## 3. Things worth showing in a demonstration

- **A class:** open `CLS-02`, double-click `CollectionEntry`. The **Attributes** and **Operations** pages list `entryHash`, `prevHash` and `computeHash()`, which implement the sealed ledger (FR-05).
- **A use case with scenarios:** double-click `UC-01 Record Milk Collection` on `UC-01`, then open the **Scenarios** page (in the docked Properties or the **Responsibilities** window, depending on version) for the basic path and the alternate flows.
- **A transition:** on `STM-01`, double-click the arrow from `Chilling` to `AtRisk`. The trigger is `breach`, the guard `R1 or R3`, and the effect `openCase`.
- **A message:** on `SEQ-01`, double-click message 4, `raiseChillingException`. It is an operation of the receiving class `ExceptionService`. Every call on the two sequence diagrams names an operation of its receiver, which is one of the programmed checks (C04).
- **Deployment:** on `DEP-01`, the rule engine sits on the Society Edge Unit, which is why chilling detection keeps working when the mobile link is down.

## 4. Traceability

Each use case has a **Realisation** connector to every requirement it satisfies.

- **Relationship Matrix:** **Design > Impact > Matrix** (in some builds **Design > Package > Matrix**). Source: `02 Use Case Model`. Target: `01 Requirements`. Type: use case and requirement. Link type: **Realization**. Direction: **Source -> Target**. Every requirement row should have at least one mark.
- **Traceability window:** select a requirement in the Browser and open **Design > Impact > Trace**.
- The full matrix from business problem to test is in the report (Annexure E) and in `docs/exports/traceability_matrix.csv`.

## 5. Exporting diagram images

Open a diagram, then **Publish > Diagram Image > Save > Save to File** (Ctrl+T) and choose PNG. The figures in the report were drawn by `render_diagrams.py` from the same definition, at the same element positions. If your exports look different in any way that matters, replace the figures in the report with your exports and say so in Section 3.5.

## 6. Fallback: build the model inside Enterprise Architect

Use this only if the `.qea` file fails.

1. Create a new project: **New Project**, choose a file name, skip the model wizard.
2. Select the model root in the Browser.
3. Open the Scripting window: **Specialize > Tools > Scripting**. Create a group of type **Normal** if none exists, add a new **JavaScript** script, open it, replace its content with the whole of `02_ea_model/C2D_build_script.js`, save and run it.
4. Watch the **System Output** window, **Script** tab. The script reports what it created and lists anything that failed. The expected totals are printed next to the actual ones.
5. Open each diagram. Elements are placed at the same coordinates as in the `.qea` file; connectors are routed by Enterprise Architect. On `CLS-01`, hide attributes and operations in the diagram properties (**Elements** page) to get the overview.

Status of the script: it is generated from the same definition, and it runs to completion against a mock of the Automation Interface with the expected counts (`node 03_model_source/test_ea_script.js`). It has not been run inside Enterprise Architect either, so treat the first run as a test and read the output.

## 7. Editing safely

- Work on a copy. After changing an element that also exists in the definition (`c2d_model.py`), note the change in Annexure K. The checks in `check_model.py` compare the definition with the file as generated, so a file edited by hand will no longer match count for count; that is expected.
- If you would rather keep everything in step, change `c2d_model.py`, then run the rebuild commands in `README.md`. The repository, the figures, the database rules and the traceability matrix are regenerated together.

## 8. Known limits of the generated file

- Stereotypes («control», «device», «external system») are stored as plain stereotype names on the elements. They display normally but are not bound to a UML profile.
- Connectors are stored as straight lines between element borders. Enterprise Architect may redraw some on first open.
- Sequence diagrams store the vertical position of each message. If messages appear bunched after opening, drag them apart; their order is fixed by the message numbers.
- The Author field of every element is set to `AI-assisted build`, so that authorship is visible inside the model.
