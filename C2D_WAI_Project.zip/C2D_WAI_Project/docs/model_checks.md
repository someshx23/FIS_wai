# Model consistency checks

| ID | Check | Result | Detail |
|---|---|---|---|
| C01 | Every functional requirement is realised by at least one use case, and every use case realises at least one requirement | PASS |  |
| C02 | Every actor takes part in a use case, and every base use case has an actor | PASS |  |
| C03 | Every use case has an entry in the access matrix and every role there is a UserRole literal | PASS |  |
| C04 | Every lifeline is an actor or an instance of a model class, and every call (24 messages) names an operation of the receiving class | PASS |  |
| C05 | State machine states equal the LotStatus enumeration; every state is reachable, can reach the final state, and has no two transitions with the same trigger and guard | PASS |  |
| C06 | State machine states equal the CaseStatus enumeration; every state is reachable, can reach the final state, and has no two transitions with the same trigger and guard | PASS |  |
| C07 | Activity diagram: every node is reachable and can reach an end node; decisions have guarded, distinct branches; the fork has two branches; each node is drawn inside its partition | PASS |  |
| C08 | Every control class is deployed as a component on DEP-01 | PASS |  |
| C09 | Every entity class maps to a table and every attribute (121) to a column; every table maps to a class or is a documented extra | PASS |  |
| C10 | The value lists enforced by the database equal the model enumerations (16 columns) | PASS |  |
| C11 | The transitions enforced by the database trigger equal the transitions of STM-01 | PASS |  |
| C12 | The Enterprise Architect repository holds exactly the model: 161 elements, 6 packages, 165 connectors, 12 diagrams, 190 diagram objects, 121 attributes, 30 operations | PASS |  |
