# Requirement-to-deliverable matrix

What each governing document asks for, where it is met, and what is still open. Where documents disagree, the order of precedence set in the master prompt is used: the professor's instructions and rubric, the WAI evaluation policy, the course outline, the classroom model, the literature, and style preferences last.

## 1. WAI evaluation policy

| Policy item | Deliverable | Status |
|---|---|---|
| 3.1 Problem identification: background, core problem, evidence, relevance of AI, stakeholders, scope, managerial significance, problem statement of two to three lines | Report, Section 1 | Done |
| 3.2 Literature review, 8 to 10 sources minimum | Report, Section 2 (12 sources); 22 references in all; `docs/SOURCES.md` | Done |
| 3.3 Methodology: AI tools, prompt design strategy, coding workflow, analytical approach, methodology flowchart | Report, Section 3 and Figure 1 | Done |
| 3.5 Data collection and preparation; synthetic data disclosed | Report, Section 4; `data/DATA_DICTIONARY.md` | Done |
| 3.6 Analysis and insights | Report, Section 5; Annexures D, F, G, I | Done |
| 3.7 Managerial recommendations: strategic insights, cost and benefit, short and long term, change management | Report, Section 6 | Done. Costs are not quantified; the break-even condition is stated with its assumptions |
| 3.8 Implementation roadmap: timeline, resources, training, risks | Report, Section 7, Figure 5; Annexure H | Done |
| 3.9 Ethical, legal and bias considerations | Report, Section 8 | Done |
| Annexures: prompts, code, screenshots | Annexures A to L; this repository | Done |
| 4.1 Report of 10 to 12 pages | Main text and references are pages 1 to 12; annexures follow from page 13 | Done |
| 4.2 Prompt logbook: prompt text, tool, output summary, usage, reflection | Annexure J; `06_logbook/` | Rows 1, 10 to 12 and the reflections need the student's input |
| 4.3 Code with comments | `03_model_source`, `04_database`, `05_dashboard`, `07_estimation`, `01_report` | Done |
| 4.4 Dashboard with 5 to 7 visual insights | `05_dashboard/dashboard.html` (seven views) | Done |
| 4.5 Slide deck; 4.6 Video | Not part of this submission | Not required for this submission, as stated by the student |
| 4.7 Data files and repository link | `data/`; link placeholder in Annexure L | The student uploads the repository and pastes the link |
| 5 Formatting: Times New Roman 12, 1.5 line spacing, 1-inch margins, APA, justified | Report body. Tables, captions and code are set smaller and single-spaced | Done. Export the PDF from Word to embed Times New Roman |
| 6 Rubric, 25 marks: problem definition, literature review, methodology, AI tool usage, coding execution, analysis quality, recommendations, ethical considerations, presentation | Sections 1, 2, 3, 3 and Annexure J, repository, 5, 6, 8 | See rows above |

## 2. Course outline

| Requirement | Deliverable | Status |
|---|---|---|
| Report with title page, table of contents, abstract, introduction, methodology, results, discussion, conclusion, references | Section titles carry both vocabularies, for example "Executive Summary (Abstract)" and "5. Results: ..." | Done |
| Hard copy and PDF | PDF supplied | The student prints the hard copy |
| Syllabus coverage: requirements and specifications, SSAD, SDLC, use cases, UML, IoT and edge computing, SCADA, project estimation with function points, RDBMS, normalisation, SQL, integrated case | Annexure A, Table A2, last row, lists the sessions each part draws on | Done |

## 3. Master prompt

| Section | Asked for | Deliverable | Status |
|---|---|---|---|
| 1 | Read every attachment; resolve conflicts by precedence; invent no limits or criteria | This matrix | Done. The policy's 10 to 12 page limit and deliverable list were followed where they differ from the prompt |
| 2 | Understand the faculty's interests without implying endorsement | Annexure A, Table A1; `docs/SOURCES.md` notes | Done |
| 4 | Original topic, compared with two alternatives; own choice of topic | Annexure A | Done |
| 5 | Verified sources only | `docs/SOURCES.md` | Done |
| 6 | As-is, to-be, functional and non-functional requirements, traceability | Report Sections 1 and 5; Annexures B, C, E | Done |
| 7 | UML model: use case, activity with exception path, sequence, class, state machine, deployment | `02_ea_model/`; Annexure D | Done |
| 8 | Editable Enterprise Architect model; honest statement of what was tested | `C2D_Model.qea`, `C2D_build_script.js`, `docs/EA_GUIDE.md` | File written and structurally checked. **Not opened in Enterprise Architect**; the student runs the check in the guide |
| 9 | Database design and executed SQL | `04_database/`; Annexure F | Done; 34 tests executed |
| 10 | Feasibility, SDLC, function points; no arbitrary cost figures | Report Section 7; Annexure H | Done |
| 11 to 13 | Report structure, natural academic style, restrained design, DOCX and PDF | `01_report/` | Done. The prompt file ends mid-sentence in section 13; nothing after "Validate the exported PDF for clipped tables, layout problems" was received |

## 4. Open items for the student

1. Open the model in Enterprise Architect, run the integrity check, complete Annexure K and the sentence in Section 3.5.
2. Fill in the title page, logbook rows 1 and 10 to 12, and confirm or rewrite the reflections.
3. Export the PDF from Word, check the contents page, print the hard copy.
4. Upload the repository and paste the link in Annexure L.
