"""
Draws every diagram of c2d_model.py as SVG and PNG.

The drawings use the same element rectangles that build_qea.py writes into
the Enterprise Architect repository, and connectors are drawn the way EA
draws an un-routed connector: a straight line between the two element
centres, clipped at the element borders. The figures in the report are
therefore a rendering of the model definition, NOT images exported by EA.

Usage:  python3 render_diagrams.py <output folder>
Also prints a layout lint: connectors that pass through an unrelated element.
"""
import math
import subprocess
import sys
from pathlib import Path
from xml.sax.saxutils import escape

from PIL import ImageFont

import c2d_model as M

FONT_DIR = "/usr/share/fonts/truetype/crosextra/"
FS = 12.5                                   # font size in px (see report note on legibility)
_f = {b: ImageFont.truetype(FONT_DIR + ("Carlito-Bold.ttf" if b else "Carlito-Regular.ttf"), 100) for b in (0, 1)}
INK, PAPER, FILL = "#1a1a1a", "#ffffff", "#f4f4f1"


def tw(s, bold=False, fs=FS):
    return _f[1 if bold else 0].getlength(s) * fs / 100.0


def wrap(s, width, bold=False, fs=FS):
    out, cur = [], ""
    for word in s.split():
        t = (cur + " " + word).strip()
        if tw(t, bold, fs) <= width or not cur:
            cur = t
        else:
            out.append(cur); cur = word
    if cur:
        out.append(cur)
    return out or [""]


class Svg:
    def __init__(self, w, h):
        self.w, self.h, self.b = w, h, []

    def add(self, s):
        self.b.append(s)

    def rect(self, x, y, w, h, rx=0, fill=PAPER, sw=1.1, dash=""):
        d = f' stroke-dasharray="{dash}"' if dash else ""
        self.add(f'<rect x="{x:.1f}" y="{y:.1f}" width="{w:.1f}" height="{h:.1f}" rx="{rx}" fill="{fill}" stroke="{INK}" stroke-width="{sw}"{d}/>')

    def line(self, x1, y1, x2, y2, dash="", sw=1.1):
        d = f' stroke-dasharray="{dash}"' if dash else ""
        self.add(f'<line x1="{x1:.1f}" y1="{y1:.1f}" x2="{x2:.1f}" y2="{y2:.1f}" stroke="{INK}" stroke-width="{sw}"{d}/>')

    def poly(self, pts, fill=PAPER, sw=1.1, close=True):
        p = " ".join(f"{x:.1f},{y:.1f}" for x, y in pts)
        tag = "polygon" if close else "polyline"
        self.add(f'<{tag} points="{p}" fill="{fill}" stroke="{INK}" stroke-width="{sw}"/>')

    def text(self, x, y, s, anchor="middle", bold=False, italic=False, fs=FS, halo=False):
        st = f'font-size="{fs}" text-anchor="{anchor}"'
        if bold: st += ' font-weight="bold"'
        if italic: st += ' font-style="italic"'
        if halo:  # white backing so labels stay readable over lines
            wdt = tw(s, bold, fs) + 6
            x0 = x - wdt / 2 if anchor == "middle" else (x - 3 if anchor == "start" else x - wdt + 3)
            self.add(f'<rect x="{x0:.1f}" y="{y - fs + 1.5:.1f}" width="{wdt:.1f}" height="{fs + 2:.1f}" fill="{PAPER}" fill-opacity="0.9"/>')
        self.add(f'<text x="{x:.1f}" y="{y:.1f}" {st}>{escape(s)}</text>')

    def lines(self, cx, cy, ls, bold=False, italic=False, lh=14.5, halo=False):
        y = cy - (len(ls) - 1) * lh / 2 + FS * 0.34
        for s in ls:
            self.text(cx, y, s, bold=bold, italic=italic, halo=halo); y += lh

    def save(self, path):
        head = (f'<svg xmlns="http://www.w3.org/2000/svg" width="{self.w}" height="{self.h}" viewBox="0 0 {self.w} {self.h}" '
                f'font-family="Carlito, Calibri, Arial, sans-serif" fill="{INK}">'
                f'<rect width="100%" height="100%" fill="{PAPER}"/>')
        Path(path).write_text(head + "\n".join(self.b) + "</svg>", encoding="utf-8")


# ---------------------------------------------------------------- geometry
def shape_of(e):
    return {"UseCase": "ellipse", "Decision": "diamond", "MergeNode": "diamond", "StateNode": "circle"}.get(e.etype, "rect")


def clip(shape, r, p_in, p_out):
    """Point where the segment from the shape centre p_in towards p_out leaves the shape."""
    x, y, w, h = r
    cx, cy = p_in
    dx, dy = p_out[0] - cx, p_out[1] - cy
    if dx == 0 and dy == 0:
        return p_in
    if shape == "ellipse":
        t = 1 / math.sqrt((dx / (w / 2)) ** 2 + (dy / (h / 2)) ** 2)
    elif shape == "diamond":
        t = 1 / (abs(dx) / (w / 2) + abs(dy) / (h / 2))
    elif shape == "circle":
        t = (w / 2) / math.hypot(dx, dy)
    else:
        # distance to each rectangle edge along the ray, measured from the (possibly shifted) start point
        ts = []
        if dx: ts.append(((x + w if dx > 0 else x) - cx) / dx)
        if dy: ts.append(((y + h if dy > 0 else y) - cy) / dy)
        t = min(t for t in ts if t > 0) if any(t > 0 for t in ts) else 0
    return (cx + dx * min(t, 1), cy + dy * min(t, 1))


def seg_hits_rect(p1, p2, r, pad=3):
    x, y, w, h = r[0] + pad, r[1] + pad, r[2] - 2 * pad, r[3] - 2 * pad
    if w <= 0 or h <= 0:
        return False
    t0, t1 = 0.0, 1.0                           # Liang-Barsky
    dx, dy = p2[0] - p1[0], p2[1] - p1[1]
    for p, q in ((-dx, p1[0] - x), (dx, x + w - p1[0]), (-dy, p1[1] - y), (dy, y + h - p1[1])):
        if p == 0:
            if q < 0: return False
        else:
            t = q / p
            if p < 0: t0 = max(t0, t)
            else: t1 = min(t1, t)
    return t0 < t1


def arrow(svg, p_from, p_to, kind):
    ang = math.atan2(p_to[1] - p_from[1], p_to[0] - p_from[0])
    def pt(d, a): return (p_to[0] - d * math.cos(ang + a), p_to[1] - d * math.sin(ang + a))
    if kind == "open":
        svg.poly([pt(10, 0.42), p_to, pt(10, -0.42)], fill="none", close=False)
    elif kind == "filled":
        svg.poly([pt(10, 0.38), p_to, pt(10, -0.38)], fill=INK)
    elif kind == "triangle":
        svg.poly([pt(13, 0.42), p_to, pt(13, -0.42)], fill=PAPER)
    elif kind == "diamond":
        back = (p_to[0] - 16 * math.cos(ang), p_to[1] - 16 * math.sin(ang))
        svg.poly([p_to, pt(8.6, 0.45), back, pt(8.6, -0.45)], fill=INK)


# ---------------------------------------------------------------- elements
def op_text(o):
    n, ps, rt = o
    return f"+ {n}({', '.join(t for _, t in ps)})" + (f": {rt}" if rt else "")


def draw_element(svg, e, r, dia):
    x, y, w, h = r
    cx, cy = x + w / 2, y + h / 2
    t = e.etype
    if t == "Boundary":
        svg.rect(x, y, w, h, fill="none", sw=1.3)
        svg.text(cx, y + 17, e.name, bold=True)
    elif t == "ActivityPartition":
        svg.rect(x, y, w, h, fill="none")
        svg.rect(x, y, w, 28, fill=FILL)
        svg.text(cx, y + 18.5, e.name, bold=True)
    elif t == "Actor":
        hd = 8
        svg.add(f'<circle cx="{cx}" cy="{y + hd + 1}" r="{hd}" fill="{PAPER}" stroke="{INK}" stroke-width="1.2"/>')
        svg.line(cx, y + 2 * hd + 1, cx, y + h - 20, sw=1.2)
        svg.line(cx - 15, y + 26, cx + 15, y + 26, sw=1.2)
        svg.line(cx, y + h - 20, cx - 12, y + h - 1, sw=1.2)
        svg.line(cx, y + h - 20, cx + 12, y + h - 1, sw=1.2)
        ls = ([f"«{e.stereo}»"] if e.stereo else []) + wrap(e.name, 104)
        for i, s in enumerate(ls):
            svg.text(cx, y + h + 13 + i * 13.5, s, halo=True)
    elif t == "UseCase":
        svg.add(f'<ellipse cx="{cx}" cy="{cy}" rx="{w / 2}" ry="{h / 2}" fill="{FILL}" stroke="{INK}" stroke-width="1.1"/>')
        svg.lines(cx, cy, wrap(e.name, w - 34))
    elif t == "Class":
        svg.rect(x, y, w, h, fill=FILL)
        yy = y + 16
        if e.stereo:
            svg.text(cx, yy, f"«{e.stereo}»"); yy += 14
        svg.text(cx, yy + 2, e.name, bold=True, italic=e.abstract)
        if not dia.hide_features:
            yy += 12
            svg.line(x, yy, x + w, yy)
            for an, at in e.attrs:
                yy += 15; svg.text(x + 6, yy, f"- {an}: {at}", anchor="start")
            yy += 7
            svg.line(x, yy, x + w, yy)
            for o in e.ops:
                yy += 15; svg.text(x + 6, yy, op_text(o), anchor="start")
    elif t == "Requirement":
        svg.rect(x, y, w, h, fill=FILL)
        svg.text(cx, y + 14, f"«{e.stereo}»", fs=11)
        svg.lines(cx, y + 14 + (h - 14) / 2, wrap(e.name, w - 12), lh=13.5)
    elif t == "Action":
        svg.rect(x, y, w, h, rx=10, fill=FILL)
        svg.lines(cx, cy, wrap(e.name, w - 12), lh=14)
    elif t in ("Decision", "MergeNode"):
        svg.poly([(cx, y), (x + w, cy), (cx, y + h), (x, cy)], fill=PAPER)
        if e.name:
            svg.text(x - 4, y - 3, e.name, anchor="end" if cx > 80 else "start", italic=True, halo=True)
    elif t == "Synchronization":
        svg.rect(x, y, w, h, fill=INK)
    elif t == "StateNode":
        rad = w / 2
        if e.ntype in (100, 3):
            svg.add(f'<circle cx="{cx}" cy="{cy}" r="{rad - 1}" fill="{INK}"/>')
        elif e.ntype in (101, 4):
            svg.add(f'<circle cx="{cx}" cy="{cy}" r="{rad}" fill="{PAPER}" stroke="{INK}" stroke-width="1.2"/>')
            svg.add(f'<circle cx="{cx}" cy="{cy}" r="{rad - 4.5}" fill="{INK}"/>')
        else:                                   # flow final
            svg.add(f'<circle cx="{cx}" cy="{cy}" r="{rad}" fill="{PAPER}" stroke="{INK}" stroke-width="1.2"/>')
            k = rad * 0.7
            svg.line(cx - k, cy - k, cx + k, cy + k); svg.line(cx - k, cy + k, cx + k, cy - k)
        if e.ntype in (101, 102):
            svg.text(cx + rad + 5, cy + 4, e.name, anchor="start", italic=True, fs=11.5)
    elif t == "State":
        svg.rect(x, y, w, h, rx=12, fill=FILL)
        svg.text(cx, cy + 4, e.name, bold=True)
    elif t in ("Node", "Device"):
        d = 8
        svg.poly([(x, y), (x + d, y - d), (x + w + d, y - d), (x + w, y)], fill=FILL)
        svg.poly([(x + w, y), (x + w + d, y - d), (x + w + d, y + h - d), (x + w, y + h)], fill=FILL)
        svg.rect(x, y, w, h, fill=PAPER)
        ls = ([f"«{e.stereo}»"] if e.stereo else []) + wrap(e.name, w - 10, bold=True)
        nested = any(M.ELEMENTS[k].parent == e.key for k, *_ in dia.objs)
        y0 = y + 15 if nested or h > 70 else cy - (len(ls) - 1) * 7 + 4
        for i, s in enumerate(ls):
            svg.text(cx, y0 + i * 14, s, bold=not s.startswith("«"))
    elif t == "Component":
        svg.rect(x, y, w, h, fill=FILL)
        ix, iy = x + w - 18, y + 6                 # component icon
        svg.rect(ix, iy, 11, 13, fill=PAPER, sw=0.9); svg.rect(ix - 4, iy + 2, 7, 3, fill=PAPER, sw=0.9)
        svg.rect(ix - 4, iy + 8, 7, 3, fill=PAPER, sw=0.9)
        svg.lines(cx - 8, cy, wrap(e.name, w - 34), lh=13.5)


CONTAINERS = ("Boundary", "ActivityPartition")


def label_for(c):
    if c.ctype == "UseCase": return f"«{c.stereo}»"
    if c.ctype == "Dependency": return f"«{c.stereo}»" if c.stereo else ""
    if c.ctype == "ControlFlow": return f"[{c.guard}]" if c.guard else ""
    if c.ctype == "StateFlow":
        s = c.name + (f" [{c.guard}]" if c.guard else "") + (f" / {c.effect}" if c.effect else "")
        return s.strip()
    if c.ctype in ("Association", "CommunicationPath"): return c.name
    return ""


def draw_structural(dia, out):
    svg = Svg(*dia.size)
    rects = {k: (x, y, w, h) for k, x, y, w, h in dia.objs}
    order = sorted(dia.objs, key=lambda o: (0 if M.ELEMENTS[o[0]].etype in CONTAINERS else
                                            1 if M.ELEMENTS[o[0]].etype in ("Node", "Device") else 2))
    for k, *r in order:
        draw_element(svg, M.ELEMENTS[k], r, dia)
    lint, segs = [], []
    for c in M.C:
        if c.src not in rects or c.dst not in rects or c.ctype == "Realisation" and dia.dtype != "Custom":
            continue
        ra, rb = rects[c.src], rects[c.dst]
        dx, dy = dia.offsets.get(c.key, (0, 0))
        ca = (ra[0] + ra[2] / 2 + dx, ra[1] + ra[3] / 2 + dy)
        cb = (rb[0] + rb[2] / 2 + dx, rb[1] + rb[3] / 2 + dy)
        ea, eb = M.ELEMENTS[c.src], M.ELEMENTS[c.dst]
        p1, p2 = clip(shape_of(ea), ra, ca, cb), clip(shape_of(eb), rb, cb, ca)
        dash = "5,4" if c.ctype in ("UseCase", "Dependency", "Realisation") else ""
        svg.line(*p1, *p2, dash=dash)
        if c.ctype in ("UseCase", "Dependency"): arrow(svg, p1, p2, "open")
        elif c.ctype in ("ControlFlow", "StateFlow"): arrow(svg, p1, p2, "open")
        elif c.ctype in ("Generalization", "Realisation"): arrow(svg, p1, p2, "triangle")
        elif c.ctype == "Aggregation": arrow(svg, p1, p2, "diamond")
        # labels
        L = math.hypot(p2[0] - p1[0], p2[1] - p1[1]) or 1
        ux, uy = (p2[0] - p1[0]) / L, (p2[1] - p1[1]) / L
        nx, ny = -uy, ux
        if nx > 0 or (nx == 0 and ny > 0): nx, ny = -nx, -ny      # normal pointing up / left
        lab = label_for(c)
        if lab and not (dia.hide_features and c.ctype == "Association"):
            f = dia.lpos.get(c.key, 0.36 if c.ctype == "ControlFlow" else 0.5)
            mx, my = p1[0] + (p2[0] - p1[0]) * f, p1[1] + (p2[1] - p1[1]) * f
            horizontal, vertical = abs(uy) < 0.25, abs(ux) < 0.25
            side = dia.lside.get(c.key, "above" if horizontal and c.ctype != "ControlFlow" else
                                 "right" if vertical and c.ctype == "ControlFlow" else "on")
            if c.ctype == "Association" and L < tw(lab, fs=11.8) + 70:
                lab = ""                      # no room on a short connector: multiplicities take priority
            ls = wrap(lab, 118 if side in ("left", "right") else 150 if c.ctype == "StateFlow" else 130) if lab else []
            oy, anchor = 0, "middle"
            if side == "above": oy = -(len(ls) * 13.5) / 2 - 3
            elif side == "below": oy = (len(ls) * 13.5) / 2 + 3
            elif side == "left": mx, anchor = mx - 7, "end"
            elif side == "right": mx, anchor = mx + 7, "start"
            for i, s in enumerate(ls):
                svg.text(mx, my + oy + (i - (len(ls) - 1) / 2) * 13.5 + 4, s, anchor=anchor, halo=True, fs=11.8)
        for mult, p, sgn, d in ((c.smult, p1, 1, 1), (c.dmult, p2, -1, -1)):
            if mult:
                off = 15 if c.ctype != "Aggregation" or d == 1 else 24
                q = (p[0] + ux * off * d + nx * 9 * sgn, p[1] + uy * off * d + ny * 9 * sgn)
                svg.text(q[0], q[1] + 4, mult, fs=11.5, halo=True)
        # lint
        skip = {c.src, c.dst, ea.parent, eb.parent}
        for k, r in rects.items():
            e = M.ELEMENTS[k]
            if k in skip or e.etype in CONTAINERS or e.parent in (c.src, c.dst):
                continue
            if seg_hits_rect(p1, p2, r):
                lint.append(f"{dia.key}: {c.key} {c.src}->{c.dst} passes through {k}")
        segs.append((c.key, p1, p2))
    svg.save(out)
    return lint


def draw_sequence(dia, out):
    svg = Svg(*dia.size)
    cxs, tops, bots = {}, {}, {}
    for k, x, y, w, h in dia.objs:
        e = M.ELEMENTS[k]
        if e.etype == "InteractionFragment":
            continue
        cx = x + w / 2
        cxs[k], tops[k], bots[k] = cx, y, y + h
        if e.etype == "Actor":
            svg.add(f'<circle cx="{cx}" cy="{y - 22}" r="6.5" fill="{PAPER}" stroke="{INK}" stroke-width="1.2"/>')
            svg.line(cx, y - 15.5, cx, y + 2, sw=1.2); svg.line(cx - 11, y - 9, cx + 11, y - 9, sw=1.2)
            svg.line(cx, y + 2, cx - 9, y + 14, sw=1.2); svg.line(cx, y + 2, cx + 9, y + 14, sw=1.2)
            ls = wrap(e.name, w + 8)
            for i, s in enumerate(ls):
                svg.text(cx, y + 28 + i * 13.5, s, bold=True, halo=True)
            y0 = y + 28 + len(ls) * 13.5 - 6
        else:
            svg.rect(x, y - 30, w, 62, fill="none", sw=0)
            name = ":" + M.ELEMENTS[e.classifier].name
            ls = wrap(name, w + 10, bold=True)
            bh = 22 + 14 * (len(ls) - 1) + 8
            bw = max(tw(s, True) for s in ls) + 14
            svg.rect(cx - bw / 2, y - 6, bw, bh, fill=FILL)
            svg.lines(cx, y - 6 + bh / 2, ls, bold=True)
            y0 = y - 6 + bh
        svg.line(cx, y0, cx, y + h, dash="6,4", sw=1)
    for k, x, y, w, h in dia.objs:
        e = M.ELEMENTS[k]
        if e.etype == "InteractionFragment":
            svg.rect(x, y, w, h, fill="none", sw=1.1)
            svg.poly([(x, y), (x + 34, y), (x + 34, y + 12), (x + 27, y + 19), (x, y + 19)], fill=FILL)
            svg.text(x + 15, y + 14, "opt", bold=True, fs=11.5)
            svg.text(x + 40, y + 14, f"[{e.name}]", anchor="start", fs=11.8, halo=True)
    for i, m in enumerate(dia.msgs):
        xa, xb, y = cxs[m.src], cxs[m.dst], m.y
        num = f"{i + 1}: "
        if m.src == m.dst:
            svg.rect(xa - 5, y - 4, 10, 30, fill=PAPER)
            svg.poly([(xa + 5, y), (xa + 42, y), (xa + 42, y + 18), (xa + 5, y + 18)], fill="none", close=False)
            arrow(svg, (xa + 42, y + 18), (xa + 5, y + 18), "filled")
            svg.text(xa + 48, y + 13, num + m.name, anchor="start", fs=11.8, halo=True)
            continue
        d = 1 if xb > xa else -1
        if m.kind != "return" and M.ELEMENTS[m.dst].etype != "Actor":
            svg.rect(xb - 5, y - 3, 10, 26, fill=PAPER)
        p1, p2 = (xa + 5 * d, y), (xb - 5 * d, y)
        svg.line(*p1, *p2, dash="6,4" if m.kind == "return" else "")
        arrow(svg, p1, p2, "filled" if m.kind == "call" else "open")
        lab = num + m.name
        mid = (xa + xb) / 2
        half = tw(lab, fs=11.8) / 2 + 4
        mid = min(max(mid, half + 2), dia.size[0] - half - 2)
        svg.text(mid, y - 5, lab, fs=11.8, halo=True)
    svg.save(out)
    return []


def render_all(outdir, zoom=3.0):
    outdir = Path(outdir); outdir.mkdir(parents=True, exist_ok=True)
    lint = []
    for d in M.D:
        svg = outdir / f"{d.key}.svg"
        lint += (draw_sequence if d.dtype == "Sequence" else draw_structural)(d, svg)
        subprocess.run(["rsvg-convert", "-z", str(zoom), "-o", str(outdir / f"{d.key}.png"), str(svg)], check=True)
    return lint


if __name__ == "__main__":
    problems = render_all(sys.argv[1] if len(sys.argv) > 1 else "../02_ea_model/diagrams")
    print(f"rendered {len(M.D)} diagrams; layout lint: {len(problems)} issue(s)")
    for p in problems:
        print("  ", p)
