"""
C2D (Collection-to-Dock) system: UML model definition (single source of truth).

Everything that describes the model lives here as plain Python data:
packages, elements, connectors and diagrams with their layout. Three programs
read it:

  build_qea.py        writes the Sparx Enterprise Architect repository (.qea)
  render_diagrams.py  draws the same diagrams as SVG/PNG for the report
  check_model.py      runs the cross-diagram consistency checks and exports
                      the element lists and the traceability matrix

Geometry is in pixels, origin top-left, y downwards: (x, y, width, height).
build_qea.py converts it to EA's convention (y negative downwards).
"""
from dataclasses import dataclass, field
import c2d_requirements as R


@dataclass
class El:                      # a model element
    key: str
    etype: str                 # EA Object_Type
    name: str
    pkg: str
    stereo: str = ""
    notes: str = ""
    parent: str = ""           # key of the owning element (nesting)
    attrs: tuple = ()          # (name, type)
    ops: tuple = ()            # (name, ((pname, ptype), ...), return type)
    ntype: int = 0             # EA NType (kind of pseudo-state, fragment ...)
    abstract: bool = False
    classifier: str = ""       # for lifelines: key of the class
    tags: dict = field(default_factory=dict)


@dataclass
class Con:                     # a model connector
    key: str
    ctype: str                 # EA Connector_Type
    src: str
    dst: str
    name: str = ""
    stereo: str = ""
    smult: str = ""
    dmult: str = ""
    directed: bool = True
    subtype: str = ""
    guard: str = ""
    effect: str = ""


@dataclass
class Msg:                     # a sequence-diagram message
    src: str
    dst: str
    name: str
    y: int
    kind: str = "call"         # call | return | async


@dataclass
class Dia:
    key: str
    name: str
    dtype: str                 # EA Diagram_Type
    pkg: str
    objs: list                 # (element key, x, y, w, h)
    notes: str = ""
    hide_features: bool = False
    msgs: list = field(default_factory=list)
    offsets: dict = field(default_factory=dict)   # connector key -> (dx, dy) parallel shift
    lpos: dict = field(default_factory=dict)      # connector key -> label position along the line (0..1)
    lside: dict = field(default_factory=dict)     # connector key -> above | below | left | right | on
    size: tuple = (0, 0)       # canvas (w, h) for the renderer


PACKAGES = [  # (key, name, parent key)  -- parent "" = directly under the model root
    ("SYS", "C2D System", ""),
    ("REQ", "01 Requirements", "SYS"),
    ("UCM", "02 Use Case Model", "SYS"),
    ("DOM", "03 Domain Model", "SYS"),
    ("BEH", "04 Behaviour", "SYS"),
    ("ARC", "05 Architecture", "SYS"),
]

E: list = []      # elements
C: list = []      # connectors
D: list = []      # diagrams


def el(*a, **k):
    E.append(El(*a, **k)); return E[-1]


def con(*a, **k):
    C.append(Con(*a, **k)); return C[-1]


# --------------------------------------------------------------------------
# 01 Requirements (generated from c2d_requirements.py)
# --------------------------------------------------------------------------
for rid, name, stmt, why, actor, prio, acc, ucs in R.FR:
    el(rid, "Requirement", f"{rid} {name}", "REQ", stereo="Functional",
       notes=f"{stmt}\n\nRationale: {why}\nAcceptance criterion: {acc}",
       tags={"Priority": prio, "Responsible actor": actor})
for rid, attr, stmt, ver in R.NFR:
    el(rid, "Requirement", f"{rid} {attr}", "REQ", stereo="Non-functional",
       notes=f"{stmt}\n\nVerification: {ver}", tags={"Quality attribute": attr})

# --------------------------------------------------------------------------
# 02 Use case model
# --------------------------------------------------------------------------
ACTORS = [  # key, name, stereotype, note
    ("A_SO", "Society Operator", "", "Secretary or tester of the village dairy cooperative society who runs collection and looks after the cooler."),
    ("A_RS", "Route Supervisor", "", "Union procurement staff responsible for the societies and the tanker on one route."),
    ("A_DO", "Dock Officer", "", "Plant reception and quality staff who weigh and test each society's milk."),
    ("A_AO", "Accounts Officer", "", "Union accounts staff who maintain rate charts and payment cycles."),
    ("A_SA", "System Administrator", "", "Maintains users, roles and the device register."),
    ("A_FM", "Farmer", "", "Member who pours milk. Receives the collection message; does not operate the system."),
    ("A_TD", "Tanker Driver", "", "Confirms the pickup figures with a confirmation code."),
    ("A_AMCU", "AMCU", "device", "Automatic milk collection unit: electronic weighing scale and milk analyser."),
    ("A_BMC", "BMC Sensor Unit", "device", "Temperature probe and power-status sensor on the bulk milk cooler."),
    ("A_SMS", "SMS Gateway", "external system", "Third-party message gateway."),
    ("A_ACC", "Union Accounting System", "external system", "Existing system that pays members; receives approved statements."),
]
for k, n, s, note in ACTORS:
    el(k, "Actor", n, "UCM", stereo=s, notes=note)

el("B_SYS", "Boundary", "C2D System", "UCM", notes="System boundary of the Collection-to-Dock system.")

USECASES = [  # key, id, name, one-line description
    ("UC01", "UC-01", "Record Milk Collection", "Capture one pour from the devices, price it and store it in the shift ledger."),
    ("UC02", "UC-02", "Record Manual Entry", "Extension of UC-01 when a device reading is unavailable; needs a reason code."),
    ("UC03", "UC-03", "Close Shift and Seal Ledger", "Seal the shift with a hash chain and synchronise it to the Union server."),
    ("UC04", "UC-04", "Monitor Milk Chilling", "Store cooler readings and evaluate chilling rules at the edge."),
    ("UC05", "UC-05", "Raise Exception Case", "Extension that opens a chilling or variance case and notifies the people responsible."),
    ("UC06", "UC-06", "Acknowledge Exception and Record Action", "Operator acknowledges a case and logs what was done."),
    ("UC07", "UC-07", "Decide Exception Disposition", "Supervisor decides the lot disposition or the variance responsibility and closes the case."),
    ("UC08", "UC-08", "Record Tanker Pickup", "Record quantity, temperature and seal at pickup, confirmed by the driver."),
    ("UC09", "UC-09", "Record Dock Receipt and Reconcile", "Record plant quantity and tests; the system reconciles them with the pickup."),
    ("UC10", "UC-10", "Generate Payment Statement", "Produce member statements for a cycle from sealed shifts and export them."),
    ("UC11", "UC-11", "Maintain Rate Chart", "Create and approve effective-dated fat and SNF rate charts."),
    ("UC12", "UC-12", "Manage Users, Roles and Devices", "Maintain users, their role and the register of field devices."),
    ("UC13", "UC-13", "Send Notification", "Included behaviour: queue a message and record its delivery status."),
    ("UC14", "UC-14", "Verify Ledger Integrity", "Recompute a shift's hash chain and review the audit trail."),
    ("UC15", "UC-15", "View Procurement Dashboard", "Reports on procurement, chilling compliance, variance and exceptions."),
]
UCKEY = {uid: k for k, uid, _, _ in USECASES}
for k, uid, n, note in USECASES:
    spec = R.UC_SPECS.get(uid)
    txt = note
    if spec:
        txt += ("\n\nGoal: " + spec["goal"] + "\nTrigger: " + spec["trigger"] +
                "\nPreconditions: " + " ".join(spec["pre"]) +
                "\nBasic flow: " + " ".join(f"{i+1}. {s}" for i, s in enumerate(spec["basic"])) +
                "\nAlternate flows: " + " ".join(spec["alt"]) +
                "\nPostconditions: " + " ".join(spec["post"]))
    el(k, "UseCase", f"{uid} {n}", "UCM", notes=txt)

# actor - use case associations
for i, (a, u) in enumerate([
        ("A_SO", "UC01"), ("A_AMCU", "UC01"), ("A_SO", "UC03"), ("A_BMC", "UC04"), ("A_SO", "UC06"),
        ("A_RS", "UC07"), ("A_SO", "UC08"), ("A_TD", "UC08"), ("A_DO", "UC09"), ("A_AO", "UC10"),
        ("A_ACC", "UC10"), ("A_AO", "UC11"), ("A_SA", "UC12"), ("A_FM", "UC13"), ("A_SMS", "UC13"),
        ("A_AO", "UC14"), ("A_RS", "UC15"), ("A_AO", "UC15")]):
    con(f"UA{i+1:02d}", "Association", a, u, directed=False)
# include: base -> included ; extend: extension -> base
for i, (s, d) in enumerate([("UC01", "UC13"), ("UC05", "UC13"), ("UC10", "UC13")]):
    con(f"INC{i+1}", "UseCase", s, d, stereo="include", subtype="Includes")
for i, (s, d, cond) in enumerate([("UC02", "UC01", "device reading unavailable"),
                                  ("UC05", "UC04", "chilling rule breached"),
                                  ("UC05", "UC09", "variance beyond tolerance or lot rejected")]):
    con(f"EXT{i+1}", "UseCase", s, d, stereo="extend", subtype="Extends", guard=cond)
# traceability: use case realises requirement
for rid, *_rest, ucs in R.FR:
    for u in ucs:
        con(f"RZ_{u}_{rid}", "Realisation", UCKEY[u], rid)

# --------------------------------------------------------------------------
# 03 Domain model: entity classes
# --------------------------------------------------------------------------
S, I, N, B, DT, DA = "String", "Integer", "Decimal", "Boolean", "DateTime", "Date"
CLASSES = {
 "Route": dict(a=[("routeCode", S), ("name", S)], n="A tanker route: the set of societies served by one supervisor."),
 "Society": dict(a=[("societyCode", S), ("name", S), ("village", S), ("active", B)],
                 n="Village dairy cooperative society where milk is collected and chilled."),
 "Member": dict(a=[("memberCode", S), ("name", S), ("mobile", S), ("bankAccountRef", S), ("active", B)],
                n="Farmer who is a pouring member of one society. Mobile and bank reference are personal data (NFR-08)."),
 "User": dict(a=[("userId", S), ("fullName", S), ("role", "UserRole"), ("passwordHash", S), ("active", B)],
              o=[("hasPermission", (("function", S),), B)],
              n="A person who signs in. Exactly one role per user (NFR-01)."),
 "Device": dict(a=[("deviceId", S), ("deviceType", "DeviceType"), ("serialNo", S), ("keyFingerprint", S),
                   ("status", "DeviceStatus"), ("lastSeenAt", DT)],
                o=[("verifySignature", (("payload", S), ("signature", S)), B)],
                n="Registered field device: collection unit, cooler sensor or edge gateway (NFR-02)."),
 "RateChart": dict(a=[("chartId", I), ("milkType", "MilkType"), ("effectiveFrom", DA), ("status", "ChartStatus")],
                   o=[("rateFor", (("fatPct", N), ("snfPct", N)), N)],
                   n="Effective-dated price table. An approved chart is never edited, only superseded (FR-17)."),
 "RateChartLine": dict(a=[("fatFrom", N), ("fatTo", N), ("snfFrom", N), ("snfTo", N), ("ratePerKg", N)],
                       n="One fat and SNF band of a rate chart."),
 "CollectionShift": dict(a=[("shiftId", I), ("shiftDate", DA), ("shiftCode", "ShiftCode"), ("status", "ShiftStatus"),
                            ("openedAt", DT), ("sealedAt", DT), ("ledgerHash", S)],
                         o=[("addEntry", (("entry", "CollectionEntry"),), ""), ("seal", (), S), ("verifyChain", (), B)],
                         n="Morning or evening collection session of a society: the shift ledger (FR-05)."),
 "CollectionEntry": dict(a=[("entryId", S), ("quantityKg", N), ("fatPct", N), ("snfPct", N), ("ratePerKg", N),
                            ("amount", N), ("captureMode", "CaptureMode"), ("manualReason", S), ("deviceId", S),
                            ("capturedAt", DT), ("syncedAt", DT), ("prevHash", S), ("entryHash", S)],
                         o=[("computeHash", (("prevHash", S),), S)],
                         n="One pour by one member. Immutable once its shift is sealed."),
 "BulkMilkCooler": dict(a=[("bmcCode", S), ("capacityLitres", I)], n="Refrigerated tank at the society."),
 "TankLot": dict(a=[("lotId", I), ("openedAt", DT), ("sealedAt", DT), ("status", "LotStatus"), ("quantityKg", N)],
                 o=[("changeStatus", (("newStatus", "LotStatus"), ("reason", S)), ""), ("isChilled", (), B)],
                 n="Milk held in one cooler between two tanker pickups; pools one or two shifts. Its lifecycle is the state machine STM-01."),
 "TemperatureReading": dict(a=[("readingId", I), ("readAt", DT), ("milkTempC", N), ("powerOn", B), ("syncedAt", DT)],
                            n="One sensor sample. The lot it belongs to is derived from the cooler and the time."),
 "ExceptionCase": dict(a=[("caseId", I), ("status", "CaseStatus"), ("raisedAt", DT), ("acknowledgedAt", DT),
                          ("decidedAt", DT), ("closedAt", DT), ("disposition", "Disposition")],
                       o=[("acknowledge", (("user", "User"),), ""), ("escalate", (), ""),
                          ("decide", (("disposition", "Disposition"), ("reason", S), ("user", "User")), ""),
                          ("close", (), "")],
                       abstract=True, n="A tracked exception on a lot. Lifecycle: state machine STM-02."),
 "ChillingException": dict(a=[("ruleCode", "ChillingRule"), ("peakTempC", N), ("minutesOverLimit", I)],
                           n="Case raised by chilling rule R1, R2 or R3 (FR-08)."),
 "VarianceException": dict(a=[("quantityVariancePct", N), ("fatVariance", N), ("snfVariance", N),
                              ("responsibility", "Responsibility")],
                           n="Case raised when pickup and dock figures differ beyond tolerance or the lot is rejected (FR-14)."),
 "CaseAction": dict(a=[("actionId", I), ("actionAt", DT), ("actionType", "ActionType"), ("remarks", S), ("actedBy", "User")],
                    n="Append-only log of what was done on a case and by whom (FR-10)."),
 "Notification": dict(a=[("notificationId", I), ("channel", "Channel"), ("recipient", S), ("purpose", S),
                         ("entryId", S), ("queuedAt", DT), ("status", "DeliveryStatus")],
                      n="Message queued for a member or staff user, with delivery status (FR-04, FR-09)."),
 "TankerTrip": dict(a=[("tripId", I), ("tripDate", DA), ("vehicleNo", S), ("driverName", S)],
                    n="One tanker run. Its route is derived from the societies it collects from."),
 "PickupRecord": dict(a=[("pickupId", I), ("pickedAt", DT), ("quantityKg", N), ("milkTempC", N), ("sealNo", S),
                         ("driverConfirmed", B)],
                      n="Transfer of one lot from society to tanker, confirmed by the driver (FR-12)."),
 "DockReceipt": dict(a=[("receiptId", I), ("receivedAt", DT), ("quantityKg", N), ("fatPct", N), ("snfPct", N),
                        ("milkTempC", N), ("decision", "DockDecision"), ("remarks", S)],
                     n="Plant measurement and acceptance decision for one pickup (FR-13)."),
 "PaymentCycle": dict(a=[("cycleId", I), ("fromDate", DA), ("toDate", DA), ("status", "CycleStatus")],
                      o=[("generateStatements", (), ""), ("approve", (("user", "User"),), "")],
                      n="Ten-day payment period (FR-16)."),
 "PaymentStatement": dict(a=[("statementId", I), ("totalQuantityKg", N), ("grossAmount", N), ("netAmount", N),
                             ("status", "StatementStatus")],
                          n="One member's verified total for a cycle, built from sealed shifts only."),
 "AuditEvent": dict(a=[("eventId", I), ("eventAt", DT), ("action", S), ("objectType", S), ("objectId", S)],
                    n="Record of a create, decision or administration event (FR-19)."),
}
SERVICES = {
 "CollectionService": dict(o=[("startEntry", (("memberCode", S),), ""),
                              ("enterManual", (("quantityKg", N), ("fatPct", N), ("snfPct", N), ("reasonCode", S)), ""),
                              ("closeShift", (("shiftId", I),), ""), ("syncShift", (("shiftId", I),), "")],
                           n="Edge-side control class for UC-01 to UC-03."),
 "ChillingMonitor": dict(o=[("submitReading", (("deviceId", S), ("milkTempC", N), ("powerOn", B), ("signature", S)), ""),
                            ("authenticateDevice", (("deviceId", S), ("signature", S)), B),
                            ("evaluateRules", (("lot", "TankLot"), ("reading", "TemperatureReading")), "ChillingRule")],
                         n="Edge-side rule engine for UC-04 (rules R1 to R3)."),
 "ExceptionService": dict(o=[("raiseChillingException", (("lotId", I), ("ruleCode", "ChillingRule"), ("readingId", I)), I),
                             ("raiseVarianceException", (("lotId", I), ("receiptId", I)), I),
                             ("acknowledge", (("caseId", I), ("userId", S), ("remarks", S)), ""),
                             ("escalateOverdue", (), ""),
                             ("decideDisposition", (("caseId", I), ("disposition", "Disposition"), ("reason", S), ("userId", S)), "")],
                          n="Server-side control class for UC-05 to UC-07."),
 "ReconciliationService": dict(o=[("reconcile", (("receiptId", I),), B)], n="Server-side control class for UC-09."),
 "NotificationService": dict(o=[("notifyMember", (("entryId", S),), ""), ("notifyCase", (("caseId", I), ("recipients", S)), "")],
                             n="Server-side control class for UC-13."),
}
ENUMS = {  # enumeration name -> literals (documented in the data dictionary; used as attribute types)
 "UserRole": ["SocietyOperator", "RouteSupervisor", "DockOfficer", "AccountsOfficer", "SystemAdministrator"],
 "DeviceType": ["CollectionUnit", "CoolerSensor", "EdgeGateway"],
 "DeviceStatus": ["Active", "Inactive"],
 "MilkType": ["Cow", "Buffalo", "Mixed"],
 "ChartStatus": ["Draft", "Approved", "Superseded"],
 "ShiftCode": ["Morning", "Evening"],
 "ShiftStatus": ["Open", "Sealed", "Synced"],
 "CaptureMode": ["Device", "Manual"],
 "LotStatus": ["Open", "Chilling", "Chilled", "AtRisk", "Held", "Dispatched", "Received", "UnderReview", "Reconciled", "Rejected"],
 "CaseStatus": ["Raised", "Acknowledged", "Escalated", "Decided", "Closed"],
 "Disposition": ["Release", "EarlyPickup", "HoldForDockTest", "Reject", "ResponsibilityAllocated"],
 "ChillingRule": ["R1_SlowChilling", "R2_WarmHolding", "R3_SensorSilence"],
 "Responsibility": ["Society", "Transporter", "Plant", "MeasurementTolerance"],
 "ActionType": ["Acknowledge", "Note", "Escalate", "Decide", "Close"],
 "Channel": ["SMS", "App"],
 "DeliveryStatus": ["Queued", "Sent", "Failed"],
 "DockDecision": ["Accepted", "Downgraded", "Rejected"],
 "CycleStatus": ["Open", "Approved", "Exported"],
 "StatementStatus": ["Draft", "Approved"],
}
for k, d in CLASSES.items():
    el(k, "Class", k, "DOM", notes=d["n"], attrs=tuple(d["a"]), ops=tuple(d.get("o", ())), abstract=d.get("abstract", False))
for k, d in SERVICES.items():
    el(k, "Class", k, "DOM", stereo="control", notes=d["n"], ops=tuple(d["o"]))

ASSOC = [  # key, source, target, name, source multiplicity, target multiplicity
 ("AS01", "Route", "Society", "serves", "1", "1..*"),
 ("AS02", "Route", "User", "supervised by", "0..*", "1"),
 ("AS03", "Society", "User", "operated by", "0..1", "1..*"),
 ("AS04", "Society", "Member", "has", "1", "0..*"),
 ("AS05", "Society", "BulkMilkCooler", "owns", "1", "1..*"),
 ("AS06", "Society", "Device", "hosts", "1", "0..*"),
 ("AS07", "BulkMilkCooler", "Device", "monitored by", "0..1", "0..1"),
 ("AS08", "Society", "CollectionShift", "runs", "1", "0..*"),
 ("AS09", "CollectionEntry", "Member", "poured by", "0..*", "1"),
 ("AS10", "CollectionEntry", "RateChart", "priced under", "0..*", "1"),
 ("AS11", "TankLot", "CollectionShift", "pools", "0..1", "1..2"),
 ("AS12", "BulkMilkCooler", "TankLot", "holds", "1", "0..*"),
 ("AS13", "BulkMilkCooler", "TemperatureReading", "sampled as", "1", "0..*"),
 ("AS14", "TankLot", "ExceptionCase", "subject of", "1", "0..*"),
 ("AS15", "ChillingException", "TemperatureReading", "triggered by", "0..*", "1"),
 ("AS16", "VarianceException", "DockReceipt", "based on", "0..1", "1"),
 ("AS17", "ExceptionCase", "Notification", "announced by", "0..1", "0..*"),
 ("AS18", "TankerTrip", "PickupRecord", "makes", "1", "1..*"),
 ("AS19", "PickupRecord", "TankLot", "collects", "0..1", "1"),
 ("AS20", "PickupRecord", "DockReceipt", "received as", "1", "0..1"),
 ("AS21", "PaymentStatement", "Member", "pays", "0..*", "1"),
 ("AS22", "AuditEvent", "User", "performed by", "0..*", "1"),
]
for k, s, d, n, sm, dm in ASSOC:
    con(k, "Association", s, d, name=n, smult=sm, dmult=dm, directed=False)
# composition: part -> whole (EA draws the diamond at the target end)
for k, part, whole, pm in [("CP1", "CollectionEntry", "CollectionShift", "0..*"),
                           ("CP2", "RateChartLine", "RateChart", "1..*"),
                           ("CP3", "CaseAction", "ExceptionCase", "0..*"),
                           ("CP4", "PaymentStatement", "PaymentCycle", "0..*")]:
    con(k, "Aggregation", part, whole, subtype="Strong", smult=pm, dmult="1")
con("GN1", "Generalization", "ChillingException", "ExceptionCase")
con("GN2", "Generalization", "VarianceException", "ExceptionCase")
for k, s, d in [("DP1", "CollectionService", "NotificationService"), ("DP2", "ChillingMonitor", "ExceptionService"),
                ("DP3", "ReconciliationService", "ExceptionService"), ("DP4", "ExceptionService", "NotificationService")]:
    con(k, "Dependency", s, d, stereo="use")

# --------------------------------------------------------------------------
# 04 Behaviour: activity diagram ACT-01
# --------------------------------------------------------------------------
LANES = [("P_EDGE", "Society Edge Unit", 0), ("P_SO", "Society Operator", 150), ("P_SRV", "Union Server", 300),
         ("P_RS", "Route Supervisor", 450), ("P_DOCK", "Dock Officer", 600)]
LANE_W, ACT_H = 150, 1035
for k, n, x in LANES:
    el(k, "ActivityPartition", n, "BEH")
LX = {k: x + LANE_W // 2 for k, _, x in LANES}
NODES = [  # key, type, name, lane, centre y, NType
 ("n_init", "StateNode", "Start", "P_SO", 48, 100),
 ("a1", "Action", "Record member pours", "P_SO", 100, 0),
 ("a2", "Action", "Close shift", "P_SO", 162, 0),
 ("a3", "Action", "Seal shift ledger with hash chain", "P_EDGE", 162, 0),
 ("f1", "Synchronization", "", "P_EDGE", 214, 0),
 ("a4", "Action", "Monitor cooler temperature", "P_EDGE", 264, 0),
 ("a5", "Action", "Store synchronised ledger", "P_SRV", 264, 0),
 ("ff", "StateNode", "Sync done", "P_SRV", 320, 102),
 ("d1", "Decision", "", "P_EDGE", 326, 0),
 ("a6", "Action", "Open exception case and notify", "P_SRV", 384, 0),
 ("a7", "Action", "Acknowledge and record action", "P_SO", 440, 0),
 ("a8", "Action", "Decide disposition", "P_RS", 496, 0),
 ("d2", "Decision", "", "P_RS", 552, 0),
 ("a9", "Action", "Record lot as rejected", "P_RS", 608, 0),
 ("fin1", "StateNode", "Lot rejected", "P_RS", 664, 101),
 ("m1", "MergeNode", "", "P_SO", 664, 0),
 ("a10", "Action", "Record tanker pickup with driver confirmation", "P_SO", 722, 0),
 ("a11", "Action", "Record dock receipt and tests", "P_DOCK", 722, 0),
 ("a12", "Action", "Reconcile pickup with receipt", "P_SRV", 782, 0),
 ("d3", "Decision", "", "P_SRV", 840, 0),
 ("a13", "Action", "Resolve variance and record responsibility", "P_RS", 840, 0),
 ("m2", "MergeNode", "", "P_SRV", 898, 0),
 ("a14", "Action", "Mark lot reconciled", "P_SRV", 952, 0),
 ("fin2", "StateNode", "Lot reconciled", "P_SRV", 1006, 101),
]
ACT_OBJS = [(k, x, 0, LANE_W, ACT_H) for k, _, x in LANES]
for k, t, n, lane, cy, nt in NODES:
    el(k, t, n, "BEH", parent=lane, ntype=nt)
    w, h = {"Action": (126, 42), "Decision": (34, 34), "MergeNode": (30, 30),
            "Synchronization": (110, 8), "StateNode": (22, 22)}[t]
    ACT_OBJS.append((k, LX[lane] - w // 2, cy - h // 2, w, h))
FLOWS = [("n_init", "a1", ""), ("a1", "a2", ""), ("a2", "a3", ""), ("a3", "f1", ""), ("f1", "a4", ""), ("f1", "a5", ""),
         ("a5", "ff", ""), ("a4", "d1", ""), ("d1", "a6", "rule breached"), ("d1", "m1", "no breach"), ("a6", "a7", ""), ("a7", "a8", ""),
         ("a8", "d2", ""), ("d2", "a9", "Reject"), ("a9", "fin1", ""), ("d2", "m1", "Release, Early Pickup or Hold"),
         ("m1", "a10", ""), ("a10", "a11", ""), ("a11", "a12", ""), ("a12", "d3", ""), ("d3", "m2", "within tolerance"),
         ("d3", "a13", "beyond tolerance"), ("a13", "m2", ""), ("m2", "a14", ""), ("a14", "fin2", "")]
for i, (s, d, g) in enumerate(FLOWS):
    con(f"CF{i+1:02d}", "ControlFlow", s, d, guard=g)
D.append(Dia("ACT-01", "ACT-01 Collection to dock with chilling and variance exceptions", "Activity", "BEH", ACT_OBJS,
             notes="End-to-end workflow of one tank lot. The fork models real concurrency: the ledger is synchronised "
                   "whenever the network allows while chilling is monitored at the edge. Exception paths: chilling "
                   "breach (ending in rejection or release) and variance beyond tolerance.",
             lpos={"CF10": 0.3, "CF16": 0.5}, size=(752, ACT_H + 4)))

# --------------------------------------------------------------------------
# 04 Behaviour: state machines STM-01 (TankLot) and STM-02 (ExceptionCase)
# --------------------------------------------------------------------------
SW, SH = 100, 44
LOT_STATES = {"Open": (95, 55), "Chilling": (265, 55), "Chilled": (470, 55), "Dispatched": (665, 55),
              "AtRisk": (265, 195), "Held": (470, 195), "Received": (665, 195),
              "Rejected": (470, 335), "UnderReview": (665, 335), "Reconciled": (520, 465)}
STM1 = [("s1_init", 12, 45, 20, 20), ("s1_final", 384, 454, 22, 22)]
el("s1_init", "StateNode", "Initial", "BEH", ntype=3)
el("s1_final", "StateNode", "Final", "BEH", ntype=4)
for n, (cx, cy) in LOT_STATES.items():
    el("LS_" + n, "State", n, "BEH")
    STM1.append(("LS_" + n, cx - SW // 2, cy - SH // 2, SW, SH))
LOT_TRANS = [  # key, source, target, trigger, guard, effect, meaning
 ("LT01", "s1_init", "LS_Open", "", "", "", "A lot is opened by the first pour into an empty cooler."),
 ("LT02", "LS_Open", "LS_Chilling", "shiftSealed", "", "", "The shift ledger is sealed; the clock for rule R1 starts."),
 ("LT03", "LS_Chilling", "LS_Chilled", "reading", "<= 4 °C", "", "A reading at or below 4 °C arrives."),
 ("LT04", "LS_Chilled", "LS_Chilling", "shiftOpened", "2nd shift", "", "A second shift starts pouring into the chilled lot; the R1 clock restarts when that shift is sealed."),
 ("LT05", "LS_Chilling", "LS_AtRisk", "breach", "R1 or R3", "openCase", "Slow chilling or sensor silence; a ChillingException is opened."),
 ("LT06", "LS_Chilled", "LS_AtRisk", "breach", "R2 or R3", "openCase", "Warm holding or sensor silence; a ChillingException is opened."),
 ("LT07", "LS_AtRisk", "LS_Chilled", "decide", "Release", "", "Supervisor releases the lot for normal dispatch."),
 ("LT08", "LS_AtRisk", "LS_Held", "decide", "Hold", "", "Supervisor holds the lot for a dock test before acceptance."),
 ("LT09", "LS_AtRisk", "LS_Rejected", "decide", "Reject", "", "Supervisor rejects the lot at the society."),
 ("LT10", "LS_AtRisk", "LS_Dispatched", "pickup", "Early Pickup", "", "Supervisor ordered an early pickup and the driver confirmed it."),
 ("LT11", "LS_Chilled", "LS_Dispatched", "pickup", "", "", "Normal pickup, confirmed by the driver."),
 ("LT12", "LS_Held", "LS_Dispatched", "pickup", "", "", "Pickup of a held lot, confirmed by the driver."),
 ("LT13", "LS_Dispatched", "LS_Received", "receipt", "accepted", "", "Dock decision is Accepted or Downgraded."),
 ("LT14", "LS_Dispatched", "LS_Rejected", "receipt", "rejected", "openCase", "Dock decision is Rejected; a VarianceException is opened to settle responsibility."),
 ("LT15", "LS_Received", "LS_Reconciled", "reconcile", "within tolerance", "", "All variances are within tolerance."),
 ("LT16", "LS_Received", "LS_UnderReview", "reconcile", "beyond tolerance", "openCase", "A variance exceeds its tolerance; a VarianceException is opened."),
 ("LT17", "LS_UnderReview", "LS_Reconciled", "resolve", "", "", "Supervisor records the responsible party and closes the case."),
 ("LT18", "LS_Reconciled", "s1_final", "", "", "", "End of the lot."),
 ("LT19", "LS_Rejected", "s1_final", "", "", "", "End of the lot."),
]
for k, s_, d_, trg, g, eff, _why in LOT_TRANS:
    con(k, "StateFlow", s_, d_, name=trg, guard=g, effect=eff)
D.append(Dia("STM-01", "STM-01 Tank lot lifecycle", "Statechart", "BEH", STM1,
             notes="Lifecycle of TankLot.status. The same transition list is loaded into the SQLite prototype, "
                   "where a trigger refuses any other status change (FR-11).",
             offsets={"LT03": (0, -9), "LT04": (0, 9), "LT06": (-8, -8), "LT07": (8, 8)},
             lpos={"LT06": 0.3, "LT07": 0.3, "LT10": 0.46, "LT14": 0.72, "LT15": 0.82, "LT17": 0.22},
             lside={"LT04": "below", "LT05": "left", "LT13": "right", "LT16": "right"},
             size=(790, 492)))

CASE_STATES = {"Raised": (110, 55), "Acknowledged": (320, 55), "Decided": (510, 55), "Closed": (680, 55),
               "Escalated": (215, 185)}
STM2 = [("s2_init", 12, 45, 20, 20), ("s2_final", 669, 150, 22, 22)]
el("s2_init", "StateNode", "Initial", "BEH", ntype=3)
el("s2_final", "StateNode", "Final", "BEH", ntype=4)
for n, (cx, cy) in CASE_STATES.items():
    el("CS_" + n, "State", n, "BEH")
    STM2.append(("CS_" + n, cx - SW // 2, cy - SH // 2, SW, SH))
CASE_TRANS = [
 ("CT1", "s2_init", "CS_Raised", "", "", ""),
 ("CT2", "CS_Raised", "CS_Acknowledged", "acknowledge", "", ""),
 ("CT3", "CS_Raised", "CS_Escalated", "after 15 min", "no acknowledgement", "notify"),
 ("CT4", "CS_Escalated", "CS_Acknowledged", "acknowledge", "", ""),
 ("CT5", "CS_Acknowledged", "CS_Decided", "decide", "", ""),
 ("CT6", "CS_Escalated", "CS_Decided", "decide", "", ""),
 ("CT7", "CS_Decided", "CS_Closed", "close", "", ""),
 ("CT8", "CS_Closed", "s2_final", "", "", ""),
]
for k, s, d, trg, g, eff in CASE_TRANS:
    con(k, "StateFlow", s, d, name=trg, guard=g, effect=eff)
D.append(Dia("STM-02", "STM-02 Exception case lifecycle", "Statechart", "BEH", STM2,
             notes="Lifecycle of ExceptionCase.status (FR-09 to FR-11, FR-15). A decision is accepted only if it is a valid transition of the lot (STM-01).",
             lpos={"CT3": 0.55, "CT4": 0.5, "CT6": 0.62}, lside={"CT3": "left"}, size=(750, 225)))

# --------------------------------------------------------------------------
# 04 Behaviour: sequence diagrams
# --------------------------------------------------------------------------
def lifelines(prefix, spec, top=50, bottom=640, w=100):
    """spec: (key or class, centre x). Class names get a lifeline element typed by the class."""
    objs = []
    for name, cx in spec:
        if name.startswith("A_"):
            key = name                                   # the actor itself is the lifeline
        else:
            key = f"{prefix}_{name}"
            el(key, "Sequence", "", "BEH", classifier=name)
        objs.append((key, cx - w // 2, top, w, bottom - top))
    return objs


S1 = lifelines("L1", [("A_BMC", 60), ("ChillingMonitor", 178), ("ExceptionService", 296), ("TankLot", 410),
                      ("NotificationService", 524), ("A_SO", 640), ("A_RS", 745)], bottom=640)
el("FR1_opt1", "InteractionFragment", "rule R1, R2 or R3 breached", "BEH", ntype=1)
el("FR1_opt2", "InteractionFragment", "not acknowledged in 15 min", "BEH", ntype=1)
S1 += [("FR1_opt1", 120, 250, 680, 370), ("FR1_opt2", 220, 438, 240, 56)]
D.append(Dia("SEQ-01", "SEQ-01 Detect and handle a chilling excursion", "Sequence", "BEH", S1,
             notes="Realises UC-04, UC-05, UC-06 and UC-07. The first three messages run on the society edge unit, "
                   "so detection does not need the network.",
             msgs=[Msg("A_BMC", "L1_ChillingMonitor", "submitReading(deviceId, milkTempC, powerOn, signature)", 135, "async"),
                   Msg("L1_ChillingMonitor", "L1_ChillingMonitor", "authenticateDevice(deviceId, signature)", 170),
                   Msg("L1_ChillingMonitor", "L1_ChillingMonitor", "evaluateRules(lot, reading)", 212),
                   Msg("L1_ChillingMonitor", "L1_ExceptionService", "raiseChillingException(lotId, ruleCode, readingId)", 285),
                   Msg("L1_ExceptionService", "L1_TankLot", "changeStatus(AtRisk, reason)", 320),
                   Msg("L1_ExceptionService", "L1_NotificationService", "notifyCase(caseId, recipients)", 355),
                   Msg("L1_NotificationService", "A_SO", "chillingAlert(caseId)", 390, "async"),
                   Msg("L1_NotificationService", "A_RS", "chillingAlert(caseId)", 420, "async"),
                   Msg("L1_ExceptionService", "L1_ExceptionService", "escalateOverdue()", 462),
                   Msg("A_SO", "L1_ExceptionService", "acknowledge(caseId, userId, remarks)", 525),
                   Msg("A_RS", "L1_ExceptionService", "decideDisposition(caseId, disposition, reason, userId)", 560),
                   Msg("L1_ExceptionService", "L1_TankLot", "changeStatus(newStatus, reason)", 595)],
             size=(810, 655)))

S2 = lifelines("L2", [("A_SO", 60), ("CollectionService", 190), ("A_AMCU", 315), ("RateChart", 430),
                      ("CollectionShift", 550), ("NotificationService", 680)], bottom=625)
el("FR2_opt1", "InteractionFragment", "device reading unavailable", "BEH", ntype=1)
S2 += [("FR2_opt1", 20, 232, 330, 52)]
D.append(Dia("SEQ-02", "SEQ-02 Record a collection entry and seal the shift", "Sequence", "BEH", S2,
             notes="Realises UC-01, UC-02 and UC-03.",
             msgs=[Msg("A_SO", "L2_CollectionService", "startEntry(memberCode)", 135),
                   Msg("L2_CollectionService", "A_AMCU", "readInstruments()", 170),
                   Msg("A_AMCU", "L2_CollectionService", "quantityKg, fatPct, snfPct", 205, "return"),
                   Msg("A_SO", "L2_CollectionService", "enterManual(quantityKg, fatPct, snfPct, reasonCode)", 262),
                   Msg("L2_CollectionService", "L2_RateChart", "rateFor(fatPct, snfPct)", 312),
                   Msg("L2_RateChart", "L2_CollectionService", "ratePerKg", 345, "return"),
                   Msg("L2_CollectionService", "L2_CollectionShift", "addEntry(entry)", 380),
                   Msg("L2_CollectionService", "L2_NotificationService", "notifyMember(entryId)", 415),
                   Msg("A_SO", "L2_CollectionService", "closeShift(shiftId)", 465),
                   Msg("L2_CollectionService", "L2_CollectionShift", "seal()", 500),
                   Msg("L2_CollectionShift", "L2_CollectionService", "ledgerHash", 533, "return"),
                   Msg("L2_CollectionService", "L2_CollectionService", "syncShift(shiftId)", 568)],
             size=(745, 640)))

# --------------------------------------------------------------------------
# 05 Architecture: deployment diagram DEP-01
# --------------------------------------------------------------------------
NODESPEC = [  # key, type, name, stereotype, rect, note
 ("N_AMCU", "Device", "AMCU (scale and analyser)", "device", (10, 45, 140, 56), "Collection instruments at the society."),
 ("N_SENS", "Device", "BMC Sensor Unit", "device", (10, 150, 140, 56), "Temperature probe and power sensor on the cooler."),
 ("N_EDGE", "Device", "Society Edge Unit", "device", (190, 20, 175, 240),
  "Tablet or mini-PC at the society. Works offline; holds the local ledger and the rule engine."),
 ("N_APP", "Node", "Union Application Server", "", (455, 20, 175, 240), "Central application services of the Union."),
 ("N_CLIENT", "Device", "Staff Client (browser or phone)", "device", (455, 310, 175, 56),
  "Used by Route Supervisor, Dock Officer, Accounts Officer and System Administrator."),
 ("N_DB", "Node", "Union Database Server", "", (670, 20, 130, 95), "Relational database of record."),
 ("N_SMS", "Node", "SMS Gateway", "external system", (670, 150, 130, 50), "External service."),
 ("N_ACC", "Node", "Union Accounting System", "external system", (670, 232, 130, 50), "Existing system; receives statement files."),
]
COMPS = [("N_EDGE", ["CollectionService", "ChillingMonitor (rule engine)", "Local Ledger Store (SQLite)", "Sync Agent"]),
         ("N_APP", ["ExceptionService", "ReconciliationService", "NotificationService", "Payment Statement Module"]),
         ("N_DB", ["Central Database"])]
DEP = []
for k, t, n, s, r, note in NODESPEC:
    el(k, t, n, "ARC", stereo=s, notes=note)
    DEP.append((k, *r))
RECT = {k: r for k, _, _, _, r, _ in NODESPEC}
for nk, names in COMPS:
    x, y, w, h = RECT[nk]
    for i, n in enumerate(names):
        ck = f"C_{nk[2:]}_{i+1}"
        el(ck, "Component", n, "ARC", parent=nk)
        DEP.append((ck, x + 12, y + 42 + i * 48, w - 24, 34))
for k, s, d, n in [("CM1", "N_AMCU", "N_EDGE", "USB"), ("CM2", "N_SENS", "N_EDGE", "RS-485"),
                   ("CM3", "N_EDGE", "N_APP", "HTTPS (queued)"), ("CM4", "N_APP", "N_DB", "SQL"),
                   ("CM5", "N_APP", "N_SMS", "HTTPS"), ("CM6", "N_APP", "N_ACC", "SFTP"),
                   ("CM7", "N_CLIENT", "N_APP", "HTTPS")]:
    con(k, "CommunicationPath", s, d, name=n, directed=False)
D.append(Dia("DEP-01", "DEP-01 Edge and Union deployment", "Deployment", "ARC", DEP,
             notes="Three zones: field (collection unit, sensor, edge unit), Union (application and database servers, "
                   "staff clients) and external services. The edge unit queues data when the mobile link is down.",
             size=(812, 380)))

# --------------------------------------------------------------------------
# 02 Use case diagram UC-01 (layout)
# --------------------------------------------------------------------------
UW, UH = 176, 52
ROWY = [75 + 76 * i for i in range(8)]
COL1 = ["UC04", "UC08", "UC06", "UC03", "UC01", "UC02", "UC12"]
COL2 = ["UC09", "UC05", "UC13", "UC10", "UC14", "UC11", "UC15", "UC07"]
C1X, C2X, AW, AH = 278, 508, 44, 60          # column centres; actor figure size (EA draws the name below it)
UCD = [("B_SYS", 166, 14, 454, 634)]
UCD += [(k, C1X - UW // 2, ROWY[i] - UH // 2, UW, UH) for i, k in enumerate(COL1)]
UCD += [(k, C2X - UW // 2, ROWY[i] - UH // 2, UW, UH) for i, k in enumerate(COL2)]
UCD += [(k, 50, y, AW, AH) for k, y in [("A_BMC", 20), ("A_TD", 128), ("A_SO", 240), ("A_AMCU", 356), ("A_SA", 500)]]
UCD += [(k, 690, y, AW, AH) for k, y in [("A_DO", 14), ("A_FM", 112), ("A_SMS", 212), ("A_ACC", 312), ("A_AO", 424), ("A_RS", 528)]]
D.append(Dia("UC-01", "UC-01 Use cases of the C2D system", "Use Case", "UCM", UCD,
             notes="Fifteen use cases. UC-13 is included by three use cases that send messages; UC-02 and UC-05 are "
                   "extensions that run only under the stated condition.", size=(785, 662)))

# --------------------------------------------------------------------------
# 03 Class diagrams (layout)
# --------------------------------------------------------------------------
def grid(cells, x0, y0, px, py, w, h):
    return [(k, x0 + c * px, y0 + r * py, w, h) for k, (c, r) in cells.items()]


OVERVIEW = {"PaymentCycle": (0, 0), "RateChart": (1, 0), "RateChartLine": (2, 0), "TankerTrip": (3, 0),
            "DockReceipt": (4, 0), "PaymentStatement": (0, 1), "CollectionEntry": (1, 1), "CollectionShift": (2, 1),
            "PickupRecord": (3, 1), "VarianceException": (4, 1), "Member": (0, 2), "Society": (1, 2),
            "TankLot": (2, 2), "ExceptionCase": (3, 2), "CaseAction": (4, 2), "Route": (0, 3), "Device": (1, 3),
            "BulkMilkCooler": (2, 3), "ChillingException": (3, 3), "Notification": (4, 3),
            "TemperatureReading": (2, 4)}
D.append(Dia("CLS-01", "CLS-01 Domain classes: overview", "Logical", "DOM", grid(OVERVIEW, 10, 14, 152, 80, 124, 34),
             notes="All domain classes except User and AuditEvent (shown on CLS-02), names and multiplicities only.",
             hide_features=True, size=(752, 382)))


def feature_height(k):
    c = CLASSES.get(k) or SERVICES.get(k)
    na, no = len(c.get("a", ())), len(c.get("o", ()))
    return 30 + (14 if k in SERVICES else 0) + max(na, 1) * 15 + 8 + (no * 15 + 8 if no else 8)


def detail(cells, colx, widths, rowgap=46, y0=14, bottom=()):
    """Place classes on a (column, row) grid; row height follows the tallest class in the row."""
    rows = sorted({r for _, r in cells.values()})
    rowh = {r: max(feature_height(k) for k, (_, rr) in cells.items() if rr == r) for r in rows}
    ry, y = {}, y0
    for r in rows:
        ry[r] = y; y += rowh[r] + rowgap
    return [(k, colx[c], ry[r] + (rowh[r] - feature_height(k) if k in bottom else 0), widths[c], feature_height(k))
            for k, (c, r) in cells.items()], y - rowgap + 14


A_CELLS = {"RateChartLine": (0, 0), "RateChart": (1, 0), "Member": (0, 1), "CollectionEntry": (1, 1),
           "CollectionShift": (2, 1), "TankLot": (3, 1), "Route": (0, 2), "Society": (1, 2), "BulkMilkCooler": (2, 2),
           "TemperatureReading": (3, 2), "User": (0, 3), "AuditEvent": (1, 3), "Device": (2, 3)}
objs, hgt = detail(A_CELLS, [14, 290, 574, 876], [200, 208, 226, 232], rowgap=52, bottom=("Member",))
D.append(Dia("CLS-02", "CLS-02 Collection, pricing, chilling and security classes", "Logical", "DOM", objs,
             notes="Attributes and operations of the classes behind UC-01 to UC-04, UC-11, UC-12 and UC-14.",
             size=(1122, hgt)))
B_CELLS = {"TankerTrip": (0, 0), "PickupRecord": (1, 0), "DockReceipt": (2, 0), "VarianceException": (3, 0),
           "Member": (0, 1), "TankLot": (1, 1), "ExceptionCase": (2, 1), "CaseAction": (3, 1),
           "PaymentStatement": (0, 2), "TemperatureReading": (1, 2), "ChillingException": (2, 2),
           "Notification": (3, 2), "PaymentCycle": (0, 3)}
objs, hgt = detail(B_CELLS, [14, 300, 596, 924], [204, 214, 246, 234], rowgap=54)
D.append(Dia("CLS-03", "CLS-03 Exception, dispatch, reconciliation and payment classes", "Logical", "DOM", objs,
             notes="Attributes and operations of the classes behind UC-05 to UC-10. ExceptionCase is abstract; its two "
                   "subclasses carry the evidence specific to chilling and to variance.",
             size=(1172, hgt)))
S_CELLS = {"CollectionService": (0, 0), "ChillingMonitor": (1, 0), "ReconciliationService": (2, 0),
           "NotificationService": (0, 1), "ExceptionService": (1, 1)}
objs, hgt = detail(S_CELLS, [14, 400, 800], [330, 345, 190], rowgap=56)
D.append(Dia("CLS-04", "CLS-04 Control classes and their dependencies", "Logical", "DOM", objs,
             notes="Control classes whose operations are the messages of SEQ-01 and SEQ-02. They are deployed as "
                   "the components of DEP-01.", size=(1004, hgt)))

# --------------------------------------------------------------------------
# 01 Requirements catalogue diagram
# --------------------------------------------------------------------------
REQD = [(f[0], 14 + (i % 5) * 196, 14 + (i // 5) * 66, 182, 52) for i, f in enumerate(list(R.FR) + list(R.NFR))]
D.append(Dia("REQ-01", "REQ-01 Requirements catalogue", "Custom", "REQ", REQD,
             notes="Functional and non-functional requirements. Use the Relationship Matrix (source: 02 Use Case "
                   "Model, target: 01 Requirements, link type Realisation) to see traceability.", size=(1000, 420)))

ELEMENTS = {e.key: e for e in E}
CONNECTORS = {c.key: c for c in C}
DIAGRAMS = {d.key: d for d in D}
assert len(ELEMENTS) == len(E), "duplicate element key"
assert len(CONNECTORS) == len(C), "duplicate connector key"

if __name__ == "__main__":
    from collections import Counter
    print("elements", len(E), dict(Counter(e.etype for e in E)))
    print("connectors", len(C), dict(Counter(c.ctype for c in C)))
    print("diagrams", [(d.key, len(d.objs), d.size) for d in D])
