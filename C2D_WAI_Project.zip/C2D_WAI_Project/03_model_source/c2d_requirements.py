"""
C2D (Collection-to-Dock) system: requirements baseline.

Single source for the functional requirements (FR), non-functional requirements
(NFR), access matrix and detailed use-case specifications. The UML model
(c2d_model.py), the Enterprise Architect repository (build_qea.py), the
traceability matrix (check_model.py) and the report tables are all generated
from these structures, so a requirement is edited in one place only.

Thresholds and tolerances are DESIGN VALUES proposed for the illustrative
Union. They are configurable (NFR-10) and are not measured results.
"""

# (id, short name, statement, rationale, responsible actor, priority,
#  acceptance criterion, use cases that realise it)
FR = [
 ("FR-01", "Device-captured collection entry",
  "For each pour the system shall take quantity (kg) from the registered weighing scale and fat and SNF (%) "
  "from the registered milk analyser, and store them with the member, shift, capture time and device identifier.",
  "Hand-copied readings can be mistaken or altered, and a member has no way to check them.",
  "Society Operator", "Must",
  "With the collection unit connected, a saved entry holds the device identifier and the same three values the "
  "devices reported, and the operator has no means of editing them.",
  ["UC-01"]),
 ("FR-02", "Rate-chart pricing",
  "The system shall price each entry from the rate chart in force on the collection date, using the fat and SNF "
  "band of the entry, and store the rate and the amount.",
  "Two-axis pricing has to be applied identically at every society.",
  "Society Operator", "Must",
  "For a test entry the stored amount equals band rate x quantity rounded to two decimals, and an entry dated "
  "before a new chart takes effect is priced on the earlier chart.",
  ["UC-01", "UC-11"]),
 ("FR-03", "Controlled manual entry",
  "When a device reading is unavailable the system shall accept a manual entry only with a reason code, mark the "
  "entry as manual and list it in the shift summary.",
  "Manual entry is legitimate during device failure but is also an opening for manipulation.",
  "Society Operator", "Must",
  "A manual entry without a reason code is refused, and every manual entry appears in the manual-entry report "
  "with its reason.",
  ["UC-02"]),
 ("FR-04", "Member notification",
  "The system shall send each member a message stating quantity, fat, SNF, rate and amount for every saved entry "
  "and record the delivery status.",
  "Immediate disclosure lets a member contest a reading while the sample still exists.",
  "Society Operator", "Should",
  "One notification record exists for each saved entry, with status Sent or Failed.",
  ["UC-13", "UC-01"]),
 ("FR-05", "Shift sealing",
  "On shift closure the system shall chain the entries of the shift with a cryptographic hash, store the final "
  "hash as the shift seal and refuse any later change to a sealed entry.",
  "A sealed ledger gives the Union and the member the same evidence.",
  "Society Operator", "Must",
  "An attempt to update or delete a sealed entry is rejected, and recomputing the chain after an out-of-band "
  "change identifies the first altered entry.",
  ["UC-03", "UC-14"]),
 ("FR-06", "Offline capture and synchronisation",
  "The society edge unit shall record entries and sensor readings without connectivity and send them to the "
  "Union server when connectivity returns, keeping the original capture times and creating no duplicates.",
  "Village connectivity is intermittent and collection cannot wait for it.",
  "Society Operator", "Must",
  "Records captured with the network disabled reach the server after reconnection with unchanged capture time, "
  "a later synchronisation time and no repeated identifier.",
  ["UC-03", "UC-04"]),
 ("FR-07", "Chilling data capture",
  "The system shall record milk temperature and power status from each bulk milk cooler sensor at a fixed "
  "interval (design value five minutes).",
  "A chilling failure is otherwise invisible to the Union until the tanker reaches the dock.",
  "BMC Sensor Unit", "Must",
  "At least 95% of the readings expected in a 24-hour test period are stored for each cooler.",
  ["UC-04"]),
 ("FR-08", "Chilling rule evaluation",
  "The edge unit shall evaluate every reading against three configurable rules: R1 slow chilling (milk above "
  "4 °C four hours after the shift is sealed), R2 warm holding (a chilled lot above 7 °C for 30 consecutive "
  "minutes) and R3 sensor silence (no reading for 20 minutes).",
  "The rules run at the society so that detection does not depend on the network.",
  "BMC Sensor Unit", "Must",
  "For a set of simulated series the rule engine reports one breach per episode, at the first breaching "
  "reading, and none for a compliant series.",
  ["UC-04"]),
 ("FR-09", "Exception case creation",
  "On a rule breach or a variance beyond tolerance the system shall open an exception case recording its type, "
  "the lot, the triggering evidence and the time, and shall notify the Society Operator and the Route Supervisor.",
  "An alert that is not a tracked case is easily ignored and leaves no record of who knew what.",
  "Route Supervisor", "Must",
  "The case exists with status Raised and two notification records.",
  ["UC-05", "UC-13"]),
 ("FR-10", "Acknowledgement, action log and escalation",
  "The Society Operator shall acknowledge a case and log the actions taken; a case not acknowledged within "
  "15 minutes (configurable) shall be escalated to the Route Supervisor.",
  "Milk warms once chilling stops, so an unattended alert has to reach someone who can act.",
  "Society Operator", "Must",
  "Acknowledgement moves the case to Acknowledged and stores user and time; an unacknowledged case becomes "
  "Escalated at the limit; logged actions cannot be edited or deleted.",
  ["UC-06"]),
 ("FR-11", "Disposition decision",
  "The Route Supervisor shall decide the disposition of an at-risk lot as Release, Early Pickup, Hold for Dock "
  "Test or Reject, with a reason, and the system shall move the lot to the corresponding state.",
  "The decision carries a financial consequence and must be attributable to an authorised person.",
  "Route Supervisor", "Must",
  "Only a user with the Route Supervisor role can record the decision, and a lot status change that is not a "
  "transition of the lot state machine is refused.",
  ["UC-07"]),
 ("FR-12", "Tanker pickup with driver confirmation",
  "The system shall record quantity, milk temperature and seal number at pickup and require the tanker "
  "driver's confirmation code before the lot is marked Dispatched.",
  "Custody passes from society to transporter at this point, so both must agree on the figures.",
  "Society Operator", "Must",
  "A pickup without driver confirmation cannot be saved.",
  ["UC-08"]),
 ("FR-13", "Dock receipt",
  "The Dock Officer shall record received quantity, fat, SNF, temperature and an acceptance decision "
  "(Accepted, Downgraded or Rejected) for each society pickup.",
  "The plant measurement is the reference against which the society figures are judged.",
  "Dock Officer", "Must",
  "Exactly one receipt can exist for a pickup, and the decision is mandatory.",
  ["UC-09"]),
 ("FR-14", "Reconciliation and variance exception",
  "On saving a dock receipt the system shall compute the quantity variance (%) between pickup and receipt and "
  "the fat and SNF differences between the society ledger and the dock test, and open a variance exception when "
  "any exceeds its tolerance (design values 0.5%, 0.10 and 0.20 percentage points) or the receipt decision is Rejected.",
  "Unexplained differences are where disputes between society, transporter and plant begin.",
  "Dock Officer", "Must",
  "Computed variances match an independent calculation on test data, and an exception is opened if and only if "
  "a tolerance is exceeded or the decision is Rejected.",
  ["UC-09", "UC-05"]),
 ("FR-15", "Variance resolution",
  "The Route Supervisor shall close a variance exception by recording the party responsible (Society, "
  "Transporter, Plant or Measurement Tolerance) and remarks.",
  "A recorded allocation turns a recurring argument into data that can be analysed.",
  "Route Supervisor", "Should",
  "A variance case cannot be closed without a responsibility value.",
  ["UC-07"]),
 ("FR-16", "Member payment statement",
  "The Accounts Officer shall generate, for a payment cycle, one statement per member from sealed shifts only "
  "and export the approved statements to the Union accounting system.",
  "Payment should rest only on records that can no longer be altered.",
  "Accounts Officer", "Must",
  "Statement totals equal the sum of the member's entries in the cycle, and a cycle containing an unsealed "
  "shift cannot be approved.",
  ["UC-10"]),
 ("FR-17", "Rate chart maintenance",
  "The Accounts Officer shall create rate charts with an effective date; an approved chart cannot be edited, "
  "only superseded.",
  "Prices change, but past entries must stay explainable.",
  "Accounts Officer", "Should",
  "Editing an approved chart is refused, and two charts for the same milk type cannot share an effective date.",
  ["UC-11"]),
 ("FR-18", "User, role and device administration",
  "The System Administrator shall create users with one role, register devices with a unique identifier and "
  "key, and deactivate either.",
  "Access control and device authentication depend on a maintained register.",
  "System Administrator", "Must",
  "A deactivated user cannot sign in, and a reading from an unregistered or deactivated device is rejected and "
  "logged.",
  ["UC-12"]),
 ("FR-19", "Audit trail and integrity verification",
  "The system shall log every create, decision and administration event with user, time and object, and shall "
  "let the Accounts Officer verify the hash chain of any shift.",
  "Evidence has to be checkable by someone other than the person who entered it.",
  "Accounts Officer", "Must",
  "Each tested action produces one audit event; verification of an untouched shift passes and verification of "
  "an altered copy fails.",
  ["UC-14"]),
 ("FR-20", "Procurement dashboard",
  "The system shall report procurement by route, chilling compliance, pickup-to-dock variance, exception "
  "ageing and manual-entry share for a selected period.",
  "Supervisors need a summary of the exceptions more than a list of every transaction.",
  "Route Supervisor", "Should",
  "Each reported figure equals the result of the documented SQL query on the same data.",
  ["UC-15"]),
]

# (id, quality attribute, requirement with design target, verification)
NFR = [
 ("NFR-01", "Security: access control",
  "Each function is available only to the roles shown in the access matrix.",
  "Every role and function combination in the matrix is exercised in acceptance testing; all must behave as specified."),
 ("NFR-02", "Security: device authentication",
  "The edge unit and the server accept data only from registered, active devices whose message signature verifies.",
  "Readings replayed from an unregistered identifier or with an altered payload are rejected in test (target: none accepted)."),
 ("NFR-03", "Integrity: tamper evidence",
  "Any change to a sealed collection entry is detectable from the stored hash chain.",
  "Tamper test on a copy of the database: every single-field change is detected (target 100%)."),
 ("NFR-04", "Availability: offline tolerance",
  "The edge unit continues collection and monitoring for at least 72 hours without connectivity and loses no record.",
  "Network disabled for 72 hours in a pilot society; record counts before and after synchronisation are equal."),
 ("NFR-05", "Performance",
  "An entry is saved at the edge within 2 seconds; an exception alert is dispatched within 60 seconds of the "
  "breaching reading reaching the edge unit; a dashboard report for 30 days returns within 5 seconds.",
  "Timed test scripts at pilot data volumes."),
 ("NFR-06", "Availability: server",
  "The Union server is available for 99% of collection hours (04:00 to 10:00 and 16:00 to 21:00) in a month.",
  "Monthly uptime log."),
 ("NFR-07", "Usability",
  "Operator screens are available in Hindi and English, and a device-captured entry needs at most three operator actions.",
  "Task walk-through with trained operators in the pilot (target: 9 of 10 complete an entry unaided)."),
 ("NFR-08", "Privacy",
  "Member mobile numbers and bank references are shown only to roles that need them and are used only for "
  "collection messages and payment, in line with the Digital Personal Data Protection Act, 2023.",
  "Screen and report review against the access matrix; notice wording reviewed by the Union."),
 ("NFR-09", "Data integrity",
  "The database enforces keys, referential integrity and range checks on quantity, fat, SNF and temperature.",
  "Constraint tests in the SQLite prototype: each invalid insert is rejected."),
 ("NFR-10", "Configurability",
  "Thresholds, tolerances and time limits can be changed by an authorised user without a software change, and each change is audited.",
  "Change a threshold in test, confirm new behaviour and the audit event."),
]

ROLES = ["Society Operator", "Route Supervisor", "Dock Officer", "Accounts Officer", "System Administrator"]

# Access matrix: use case -> roles allowed to start it (NFR-01). Device and
# system initiated use cases have no human role.
ACCESS = {
 "UC-01": ["Society Operator"], "UC-02": ["Society Operator"], "UC-03": ["Society Operator"],
 "UC-04": [], "UC-05": [], "UC-06": ["Society Operator"], "UC-07": ["Route Supervisor"],
 "UC-08": ["Society Operator"], "UC-09": ["Dock Officer"], "UC-10": ["Accounts Officer"],
 "UC-11": ["Accounts Officer"], "UC-12": ["System Administrator"], "UC-13": [],
 "UC-14": ["Accounts Officer"], "UC-15": ["Route Supervisor", "Accounts Officer"],
}

# Detailed use-case specifications (the four that carry most of the design).
UC_SPECS = {
 "UC-01": dict(
  goal="Record one member's pour with device-captured quantity and quality and a computed amount.",
  primary="Society Operator", secondary="AMCU (scale and analyser), Farmer (through UC-13)",
  trigger="A member presents milk during an open shift.",
  pre=["The operator is signed in with the Society Operator role.", "A shift is open for the society.",
       "An approved rate chart covers the shift date."],
  post=["A collection entry is stored in the shift ledger with rate, amount and hash.",
        "A notification to the member is queued."],
  basic=["The operator selects the member by code.",
         "The system reads quantity from the scale and fat and SNF from the analyser.",
         "The system finds the rate for the fat and SNF band in the rate chart in force and computes the amount.",
         "The system stores the entry, linked to the previous entry by hash.",
         "The system queues the member notification (include UC-13) and shows the result to the operator."],
  alt=["2a. A device reading is unavailable: the operator records a manual entry with a reason code (extend UC-02).",
       "3a. No band matches the fat and SNF values: the entry is refused and the operator is told to retest.",
       "4a. The edge unit is offline: the entry is stored locally and synchronised later (FR-06)."],
  frs=["FR-01", "FR-02", "FR-04", "FR-06"]),
 "UC-04": dict(
  goal="Keep a continuous temperature record of each cooler and detect chilling failures at the society.",
  primary="BMC Sensor Unit", secondary="none",
  trigger="The sensor unit sends a reading (every five minutes).",
  pre=["The sensor unit is a registered, active device."],
  post=["The reading is stored at the edge and later on the server.",
        "The chilling state of the open lot is up to date."],
  basic=["The sensor unit submits milk temperature, power status and a signature.",
         "The edge unit authenticates the device and stores the reading.",
         "The edge unit evaluates rules R1, R2 and R3 for the lot in the cooler.",
         "No rule is breached; when the lot first reaches 4 °C its status becomes Chilled."],
  alt=["2a. The signature does not verify: the reading is rejected and an audit event is written (FR-18).",
       "3a. A rule is breached: an exception case is raised (extend UC-05).",
       "1a. No reading arrives for 20 minutes: rule R3 raises a sensor-silence case (extend UC-05)."],
  frs=["FR-06", "FR-07", "FR-08"]),
 "UC-07": dict(
  goal="Decide what happens to an at-risk lot, or who bears a variance, and close the case.",
  primary="Route Supervisor", secondary="none",
  trigger="The supervisor opens a case that is Acknowledged or Escalated.",
  pre=["The user is signed in with the Route Supervisor role.", "The case belongs to a society on the supervisor's route."],
  post=["The decision, reason, user and time are stored and cannot be changed.",
        "The lot status has moved along a valid transition.", "The case is Closed."],
  basic=["The system shows the case with its evidence: readings, operator actions, quantities.",
         "For a chilling case the supervisor chooses Release, Early Pickup, Hold for Dock Test or Reject and enters a reason.",
         "The system records the decision, changes the lot status and closes the case.",
         "The system writes an audit event."],
  alt=["2a. Variance case: the supervisor records the responsible party and remarks instead of a disposition (FR-15).",
       "3a. The requested lot status is not a valid transition: the decision is refused and the reason is shown."],
  frs=["FR-11", "FR-15", "FR-19"]),
 "UC-09": dict(
  goal="Record what the plant received from a society and reconcile it with what the society dispatched.",
  primary="Dock Officer", secondary="none",
  trigger="A tanker compartment for a society is unloaded and tested at the dock.",
  pre=["The user is signed in with the Dock Officer role.", "A pickup record exists for the lot and has no receipt."],
  post=["A dock receipt is stored.", "The lot is Received, Rejected, Reconciled or Under Review.",
        "A variance case exists if a tolerance was exceeded."],
  basic=["The officer selects the trip and the society pickup.",
         "The officer enters received quantity, fat, SNF, temperature and the acceptance decision.",
         "The system stores the receipt and computes quantity, fat and SNF variances.",
         "All variances are within tolerance: the lot becomes Reconciled."],
  alt=["2a. The decision is Rejected: the lot becomes Rejected and a variance case is raised for responsibility.",
       "4a. A variance exceeds its tolerance: the lot becomes Under Review and a variance case is raised (extend UC-05)."],
  frs=["FR-13", "FR-14", "FR-09"]),
}
