"""
Cross-artefact consistency checks and exports for the C2D model.

Checks that the requirements, the UML diagrams, the Enterprise Architect
repository and the SQLite schema agree with one another, and writes the
element lists and the requirements traceability matrix used in the report.

Usage:  python3 check_model.py            (writes ../docs/model_checks.md and ../docs/exports/*.csv)
Exit code 0 only if every check passes.
"""
import csv
import json
import re
import sqlite3
import sys
from collections import defaultdict
from pathlib import Path

import c2d_model as M
import c2d_requirements as R

ROOT = Path(__file__).resolve().parent.parent
DOCS, EXP = ROOT / "docs", ROOT / "docs" / "exports"
SCHEMA = (ROOT / "04_database" / "schema.sql").read_text(encoding="utf-8")
snake = lambda s: re.sub(r"(?<!^)(?=[A-Z])", "_", s).lower()

# class -> table. Three classes share one table (single-table inheritance).
TABLE = {"User": "app_user", "ExceptionCase": "exception_case", "ChillingException": "exception_case",
         "VarianceException": "exception_case"}
for k in M.CLASSES:
    TABLE.setdefault(k, snake(k))
EXTRA_TABLES = {"lot_transition": "state machine STM-01 held as data (FR-11)", "config": "thresholds and tolerances (NFR-10)"}
# attributes whose column has a different name or lives elsewhere, with the reason
COLUMN = {("User", "userId"): "user_id", ("Device", "deviceId"): "device_id",
          ("TankLot", "lotId"): "lot_id", ("ExceptionCase", "caseId"): "case_id"}
# which tests of 04_database/run_checks.py verify each requirement ("" = cannot be decided in a database prototype)
TESTS = {"FR-01": "", "FR-02": "T-02a, T-02b", "FR-03": "T-03a, T-03b", "FR-04": "T-04", "FR-05": "T-05a to T-05e",
         "FR-06": "T-06 (simulated link delay)", "FR-07": "", "FR-08": "T-08", "FR-09": "T-09", "FR-10": "T-10a to T-10c",
         "FR-11": "T-11a to T-11c", "FR-12": "T-12", "FR-13": "T-13a, T-13b", "FR-14": "T-14a, T-14b", "FR-15": "T-15",
         "FR-16": "T-16a, T-16b", "FR-17": "T-17a, T-17b", "FR-18": "T-18a, T-18b", "FR-19": "T-05d, T-05e",
         "FR-20": "Queries Q1 to Q10"}
# main model elements that carry each requirement (besides its use cases)
ELEMENTS = {
 "FR-01": "CollectionEntry, Device; SEQ-02 messages 1 to 3",
 "FR-02": "RateChart.rateFor, RateChartLine; SEQ-02 messages 5 and 6",
 "FR-03": "CollectionService.enterManual; CollectionEntry.captureMode, manualReason; SEQ-02 opt fragment",
 "FR-04": "NotificationService.notifyMember; Notification",
 "FR-05": "CollectionShift.seal, verifyChain; CollectionEntry.computeHash; ACT-01 Seal shift ledger",
 "FR-06": "CollectionService.syncShift; DEP-01 Sync Agent and Local Ledger Store; ACT-01 fork",
 "FR-07": "TemperatureReading; ChillingMonitor.submitReading; DEP-01 BMC Sensor Unit",
 "FR-08": "ChillingMonitor.evaluateRules; STM-01 LT03, LT05, LT06",
 "FR-09": "ExceptionService.raiseChillingException, raiseVarianceException; ExceptionCase; STM-02",
 "FR-10": "ExceptionService.acknowledge, escalateOverdue; CaseAction; STM-02 CT2 to CT4",
 "FR-11": "ExceptionService.decideDisposition; TankLot.changeStatus; STM-01 LT07 to LT10",
 "FR-12": "PickupRecord; STM-01 LT10 to LT12; ACT-01 Record tanker pickup",
 "FR-13": "DockReceipt; STM-01 LT13, LT14; ACT-01 Record dock receipt",
 "FR-14": "ReconciliationService.reconcile; VarianceException; STM-01 LT15, LT16",
 "FR-15": "VarianceException.responsibility; STM-01 LT17",
 "FR-16": "PaymentCycle.generateStatements, approve; PaymentStatement",
 "FR-17": "RateChart.status, effectiveFrom",
 "FR-18": "User, Device.verifySignature; ChillingMonitor.authenticateDevice",
 "FR-19": "AuditEvent; CollectionShift.verifyChain",
 "FR-20": "Views v_shift_totals, v_lot_ledger, v_reconciliation; queries.sql",
}

results = []


def check(cid, text, problems):
    problems = list(problems)
    results.append(dict(id=cid, check=text, result="PASS" if not problems else "FAIL", detail="; ".join(map(str, problems[:6]))))


def reach(start, edges):
    seen, todo = {start}, [start]
    while todo:
        n = todo.pop()
        for a, b in edges:
            if a == n and b not in seen:
                seen.add(b); todo.append(b)
    return seen


def run():
    by = defaultdict(list)
    for e in M.E:
        by[e.etype].append(e)
    cons = defaultdict(list)
    for c in M.C:
        cons[c.ctype].append(c)

    # C01-C02 requirements and use cases
    realised = {c.dst for c in cons["Realisation"]}
    realising = {c.src for c in cons["Realisation"]}
    check("C01", "Every functional requirement is realised by at least one use case, and every use case realises at least one requirement",
          [f[0] for f in R.FR if f[0] not in realised] + [e.name for e in by["UseCase"] if e.key not in realising])
    linked = {c.src for c in cons["Association"]} | {c.dst for c in cons["Association"]}
    ext_or_inc = {c.src for c in cons["UseCase"] if c.stereo == "extend"} | {c.dst for c in cons["UseCase"] if c.stereo == "include"}
    check("C02", "Every actor takes part in a use case, and every base use case has an actor",
          [a.name for a in by["Actor"] if a.key not in linked] +
          [u.name for u in by["UseCase"] if u.key not in linked and u.key not in ext_or_inc])
    check("C03", "Every use case has an entry in the access matrix and every role there is a UserRole literal",
          [u for _, u, _, _ in M.USECASES if u not in R.ACCESS] +
          [r for rs in R.ACCESS.values() for r in rs if r.replace(" ", "") not in M.ENUMS["UserRole"]])

    # C04 sequence diagrams against the class model
    bad = []
    for d in M.D:
        for m in d.msgs:
            tgt = M.ELEMENTS[m.dst]
            if tgt.etype == "Sequence":
                cls = M.ELEMENTS.get(tgt.classifier)
                if not cls or cls.etype != "Class":
                    bad.append(f"{d.key}: lifeline {m.dst} has no class")
                elif m.kind != "return" and m.name.split("(")[0] not in [o[0] for o in cls.ops]:
                    bad.append(f"{d.key}: {m.name.split('(')[0]} is not an operation of {cls.name}")
    n_msgs = sum(len(d.msgs) for d in M.D)
    check("C04", f"Every lifeline is an actor or an instance of a model class, and every call ({n_msgs} messages) names an operation of the receiving class", bad)

    # C05-C06 state machines
    for cid, prefix, init, final, enum in (("C05", "LS_", "s1_init", "s1_final", "LotStatus"), ("C06", "CS_", "s2_init", "s2_final", "CaseStatus")):
        states = [e.name for e in by["State"] if e.key.startswith(prefix)]
        tr = [(c.src, c.dst) for c in cons["StateFlow"] if c.src.startswith((prefix, init)) ]
        keys = [prefix + s for s in states]
        probs = [f"enumeration differs: {sorted(set(states) ^ set(M.ENUMS[enum]))}"] if set(states) != set(M.ENUMS[enum]) else []
        probs += [f"{k} unreachable" for k in keys if k not in reach(init, tr)]
        probs += [f"{k} cannot reach the final state" for k in keys if final not in reach(k, tr)]
        seen = set()
        for c in cons["StateFlow"]:
            sig = (c.src, c.name, c.guard)
            if c.src.startswith(prefix) and sig in seen:
                probs.append(f"non-deterministic: {sig}")
            seen.add(sig)
        check(cid, f"State machine states equal the {enum} enumeration; every state is reachable, can reach the final state, and has no two transitions with the same trigger and guard", probs)

    # C07 activity diagram
    flows = [(c.src, c.dst) for c in cons["ControlFlow"]]
    nodes = [n[0] for n in M.NODES]
    out = defaultdict(list)
    for c in cons["ControlFlow"]:
        out[c.src].append(c)
    finals = [n[0] for n in M.NODES if n[5] in (101, 102)]
    probs = [f"{n} unreachable" for n in nodes if n not in reach("n_init", flows)]
    probs += [f"{n} cannot reach an end node" for n in nodes if not (set(finals) & reach(n, flows))]
    for n in M.NODES:
        k, t = n[0], n[1]
        if t == "Decision" and (len(out[k]) < 2 or any(not c.guard for c in out[k]) or len({c.guard for c in out[k]}) < len(out[k])):
            probs.append(f"decision {k} needs two or more flows with distinct guards")
        if t == "Synchronization" and len(out[k]) < 2:
            probs.append(f"fork {k} needs two outgoing flows")
        if t == "Action" and len(out[k]) != 1:
            probs.append(f"action {k} must have exactly one outgoing flow")
    lane = {k: (x, x + M.LANE_W) for k, _, x in M.LANES}
    for k, x, y, w, h in M.ACT_OBJS:
        e = M.ELEMENTS[k]
        if e.parent and not (lane[e.parent][0] <= x and x + w <= lane[e.parent][1]):
            probs.append(f"{k} is drawn outside its partition")
    check("C07", "Activity diagram: every node is reachable and can reach an end node; decisions have guarded, distinct branches; the fork has two branches; each node is drawn inside its partition", probs)

    # C08 control classes and deployed components
    comps = {e.name.split(" (")[0] for e in by["Component"]}
    check("C08", "Every control class is deployed as a component on DEP-01", [k for k in M.SERVICES if k not in comps])

    # C09-C11 class model against the relational schema
    tables = {m.group(1): m.group(2) for m in re.finditer(r"CREATE TABLE (\w+) \((.*?)\n\);", SCHEMA, re.S)}
    cols = {t: set(re.findall(r"^\s{4}(\w+)\s+(?:TEXT|INTEGER|REAL)", body, re.M)) for t, body in tables.items()}
    probs = [f"{k}: table {t} missing" for k, t in TABLE.items() if t not in tables]
    probs += [f"table {t} has no class" for t in tables if t not in TABLE.values() and t not in EXTRA_TABLES]
    for k, d in M.CLASSES.items():
        for an, _ in d["a"]:
            col = COLUMN.get((k, an), snake(an))
            if TABLE[k] in cols and col not in cols[TABLE[k]]:
                probs.append(f"{k}.{an}: no column {TABLE[k]}.{col}")
    n_attr = sum(len(d["a"]) for d in M.CLASSES.values())
    check("C09", f"Every entity class maps to a table and every attribute ({n_attr}) to a column; every table maps to a class or is a documented extra", probs)

    def in_list(table, column):
        m = re.search(rf"^\s{{4}}{column}\s[^\n]*?\n?\s*CHECK \({column} IN \(([^)]*)\)", tables[table], re.M) or \
            re.search(rf"{column}\s[^\n]*CHECK \({column} IN \(([^)]*)\)", tables[table])
        return set(re.findall(r"'([^']*)'", m.group(1))) if m else set()
    pairs = [("tank_lot", "status", "LotStatus"), ("exception_case", "status", "CaseStatus"), ("exception_case", "disposition", "Disposition"),
             ("exception_case", "rule_code", "ChillingRule"), ("exception_case", "responsibility", "Responsibility"),
             ("app_user", "role", "UserRole"), ("device", "device_type", "DeviceType"), ("dock_receipt", "decision", "DockDecision"),
             ("collection_shift", "status", "ShiftStatus"), ("collection_shift", "shift_code", "ShiftCode"),
             ("collection_entry", "capture_mode", "CaptureMode"), ("rate_chart", "status", "ChartStatus"),
             ("payment_cycle", "status", "CycleStatus"), ("case_action", "action_type", "ActionType"),
             ("notification", "status", "DeliveryStatus"), ("rate_chart", "milk_type", "MilkType")]
    check("C10", f"The value lists enforced by the database equal the model enumerations ({len(pairs)} columns)",
          [f"{t}.{c} {sorted(in_list(t, c) ^ set(M.ENUMS[e]))}" for t, c, e in pairs if in_list(t, c) != set(M.ENUMS[e])])
    db = ROOT / "04_database" / "c2d_prototype.sqlite"
    if db.exists():
        con = sqlite3.connect(f"file:{db}?mode=ro", uri=True)
        in_db = {(a, b) for a, b in con.execute("SELECT from_status, to_status FROM lot_transition")}
        in_model = {(s[3:], d[3:]) for _, s, d, *_ in M.LOT_TRANS if s.startswith("LS_") and d.startswith("LS_")}
        used = {r[0] for r in con.execute("SELECT DISTINCT status FROM tank_lot")}
        check("C11", "The transitions enforced by the database trigger equal the transitions of STM-01", sorted(in_db ^ in_model))
        con.close()

    # C12 Enterprise Architect repository against the model
    qea = ROOT / "02_ea_model" / "C2D_Model.qea"
    if qea.exists():
        con = sqlite3.connect(f"file:{qea}?mode=ro", uri=True)
        n = lambda t, w="1=1": con.execute(f"SELECT count(*) FROM {t} WHERE {w}").fetchone()[0]
        exp = {"elements": (len(M.E), n("t_object", "Object_Type <> 'Package'")), "packages": (len(M.PACKAGES), n("t_package", "Parent_ID <> 0")),
               "connectors": (len(M.C) + n_msgs, n("t_connector")), "diagrams": (len(M.D), n("t_diagram")),
               "diagram objects": (sum(len(d.objs) for d in M.D), n("t_diagramobjects")),
               "attributes": (sum(len(e.attrs) for e in M.E), n("t_attribute")), "operations": (sum(len(e.ops) for e in M.E), n("t_operation"))}
        check("C12", "The Enterprise Architect repository holds exactly the model: " + ", ".join(f"{v[0]} {k}" for k, v in exp.items()),
              [f"{k}: model {a}, repository {b}" for k, (a, b) in exp.items() if a != b])
        con.close()
    return results


def exports():
    EXP.mkdir(parents=True, exist_ok=True)
    def w(name, header, rows):
        with open(EXP / name, "w", newline="", encoding="utf-8") as f:
            csv.writer(f).writerows([header] + rows)
    w("actors.csv", ["Actor", "Kind", "Description"], [[n, s or "person", note] for _, n, s, note in M.ACTORS])
    w("use_cases.csv", ["ID", "Use case", "Description", "Roles allowed (NFR-01)"],
      [[u, n, note, ", ".join(R.ACCESS[u]) or "device or system"] for _, u, n, note in M.USECASES])
    w("classes.csv", ["Class", "Kind", "Member", "Type or signature", "Description"],
      [[k, "entity", "", "", d["n"]] for k, d in M.CLASSES.items()] +
      [[k, "entity", a, t, ""] for k, d in M.CLASSES.items() for a, t in d["a"]] +
      [[k, "entity" if k in M.CLASSES else "control", o[0] + "()", "(" + ", ".join(f"{p}: {t}" for p, t in o[1]) + ")" + (": " + o[2] if o[2] else ""), ""]
       for k, d in {**M.CLASSES, **M.SERVICES}.items() for o in d.get("o", [])])
    w("relationships.csv", ["Kind", "Source", "Source multiplicity", "Target", "Target multiplicity", "Name or stereotype"],
      [[c.ctype + (" (composition)" if c.subtype == "Strong" else ""), M.ELEMENTS[c.src].name, c.smult, M.ELEMENTS[c.dst].name, c.dmult, c.name or c.stereo]
       for c in M.C if c.ctype in ("Association", "Aggregation", "Generalization", "Dependency", "UseCase", "CommunicationPath")])
    w("lot_transitions.csv", ["ID", "From", "To", "Trigger", "Guard", "Effect", "Meaning"],
      [[k, s.replace("LS_", "").replace("s1_init", "(initial)"), d.replace("LS_", "").replace("s1_final", "(final)"), t, g, e, why] for k, s, d, t, g, e, why in M.LOT_TRANS])
    w("enumerations.csv", ["Enumeration", "Literals"], [[k, ", ".join(v)] for k, v in M.ENUMS.items()])
    w("class_table_mapping.csv", ["Class", "Table", "Note"],
      [[k, t, "single-table inheritance with discriminator case_type" if t == "exception_case" else ""] for k, t in TABLE.items()] +
      [["(none)", t, why] for t, why in EXTRA_TABLES.items()])
    rtm = []
    for rid, name, stmt, why, actor, prio, acc, ucs in R.FR:
        dias = sorted({d.key for d in M.D for k, *_ in d.objs if k in [M.UCKEY[u] for u in ucs]} |
                      {m for m in re.findall(r"(SEQ-\d+|ACT-\d+|STM-\d+|DEP-\d+)", ELEMENTS[rid])})
        rtm.append([rid, name, prio, ", ".join(ucs), ELEMENTS[rid], ", ".join(dias), acc, TESTS[rid] or "Not executable in the prototype: pilot test"])
    w("traceability_matrix.csv", ["Requirement", "Name", "Priority", "Use cases", "Model elements", "Diagrams", "Acceptance criterion", "Verified by"], rtm)
    (EXP / "model_summary.json").write_text(json.dumps(dict(
        elements=len(M.E), connectors=len(M.C), diagrams=[(d.key, d.name, d.dtype) for d in M.D], actors=len(M.ACTORS), use_cases=len(M.USECASES),
        entity_classes=len(M.CLASSES), control_classes=len(M.SERVICES), attributes=sum(len(d["a"]) for d in M.CLASSES.values()),
        operations=sum(len(d.get("o", [])) for d in {**M.CLASSES, **M.SERVICES}.values()), fr=len(R.FR), nfr=len(R.NFR),
        packages=[(k, n, p) for k, n, p in M.PACKAGES], checks=results), indent=1), encoding="utf-8")


if __name__ == "__main__":
    res = run()
    exports()
    lines = ["# Model consistency checks\n", "| ID | Check | Result | Detail |", "|---|---|---|---|"]
    lines += [f"| {r['id']} | {r['check']} | {r['result']} | {r['detail']} |" for r in res]
    (DOCS / "model_checks.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    for r in res:
        print(f"[{r['result']}] {r['id']} {r['check'][:110]}" + (f"\n        {r['detail']}" if r["detail"] else ""))
    sys.exit(0 if all(r["result"] == "PASS" for r in res) else 1)
