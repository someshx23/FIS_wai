/*
 * Runs C2D_build_script.js against a small mock of Enterprise Architect's Automation Interface.
 *   node test_ea_script.js ../02_ea_model/C2D_build_script.js
 * This checks syntax, control flow and the number of objects the script asks for.
 * It does not prove that Enterprise Architect accepts every call; only a run inside EA can show that.
 */
const fs = require("fs"), vm = require("vm");
const file = process.argv[2] || require("path").join(__dirname, "..", "02_ea_model", "C2D_build_script.js");
const src = fs.readFileSync(file, "utf8").replace(/^!INC .*$/m, "");

let nextId = 1;
const count = { Packages: 0, Elements: 0, Connectors: 0, Diagrams: 0, DiagramObjects: 0, Attributes: 0, Methods: 0, Parameters: 0, TaggedValues: 0 };
const types = { Elements: new Set(), Connectors: new Set(), Diagrams: new Set() };
function collection(kind) {
  return { items: [], AddNew(name, type) { count[kind]++; if (types[kind]) types[kind].add(type); const o = make(kind, name, type); this.items.push(o); return o; }, Refresh() {} };
}
function make(kind, name, type) {
  const o = { Name: name, Type: type, Update() { return true; } };
  if (kind === "Packages") Object.assign(o, { PackageID: nextId++, Packages: collection("Packages"), Elements: collection("Elements"), Diagrams: collection("Diagrams") });
  if (kind === "Elements") Object.assign(o, { ElementID: nextId++, Elements: collection("Elements"), Attributes: collection("Attributes"), Methods: collection("Methods"),
    Connectors: collection("Connectors"), TaggedValues: collection("TaggedValues") });
  if (kind === "Methods") o.Parameters = collection("Parameters");
  if (kind === "Connectors") Object.assign(o, { ConnectorID: nextId++, ClientEnd: { Update() {} }, SupplierEnd: { Update() {} } });
  if (kind === "Diagrams") Object.assign(o, { DiagramID: nextId++, DiagramObjects: collection("DiagramObjects") });
  return o;
}
const out = [], sql = [];
const root = make("Packages", "Model", "");
const sandbox = { Session: { Output: s => out.push(s) },
  Repository: { EnsureOutputVisible() {}, GetTreeSelectedPackage: () => root, RefreshModelView() {}, Execute: s => sql.push(s) } };
vm.runInNewContext(src, sandbox, { filename: file });

console.log(out.join("\n"));
console.log("mock counts:", JSON.stringify(count));
console.log("element types:", [...types.Elements].sort().join(", "));
console.log("connector types:", [...types.Connectors].sort().join(", "));
console.log("diagram types:", [...types.Diagrams].sort().join(", "));
console.log("direct SQL updates (async and return messages):", sql.length);
const ok = out.some(l => l.startsWith("No failures reported")) && out[0].replace("C2D model built: ", "") === out[1].replace("Expected:        ", "");
console.log(ok ? "MOCK RUN PASSED" : "MOCK RUN FAILED");
process.exit(ok ? 0 : 1);
