"""
Builds the Sparx Enterprise Architect project file (C2D_Model.qea) from c2d_model.py.

A .qea file is a SQLite database (Sparx Systems, EA 16 and later). This script
copies an EMPTY EA project (base_empty.qea: the EA repository schema plus EA's
own reference tables, with no model content) and inserts the packages,
elements, features, connectors, diagrams and diagram layout as rows, using the
same column conventions that Enterprise Architect itself used in the classroom
project the base was taken from.

    python3 build_qea.py make-base <any existing .qea> base_empty.qea   # once
    python3 build_qea.py build base_empty.qea ../02_ea_model/C2D_Model.qea

IMPORTANT: the result is checked structurally by this script (see verify()),
but this script cannot open it in Enterprise Architect. After opening it in
EA, run the Project Integrity Check (see docs/EA_GUIDE.md).
"""
import hashlib
import shutil
import sqlite3
import sys
import uuid
from datetime import datetime

import c2d_model as M
import c2d_requirements as R

AUTHOR = "AI-assisted build"
NOW = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
NS = uuid.UUID("6f1c2d00-0c2d-4c2d-8c2d-00c2d0c2d001")

MODEL_TABLES = ["t_object", "t_connector", "t_diagram", "t_diagramobjects", "t_diagramlinks", "t_operation",
                "t_operationparams", "t_attribute", "t_xref", "t_objectproperties", "t_objectscenarios"]

DIAGRAM_PDATA = ("HideRel=0;ShowTags=0;ShowReqs=0;ShowCons=0;OpParams=1;ShowSN=0;ScalePI=0;PPgs.cx=0;PPgs.cy=0;PSize=1;"
                 "ShowIcons=1;SuppCN=0;HideProps=0;HideParents=0;UseAlias=0;HideAtts={h};HideOps={h};HideStereo=0;"
                 "HideEStereo=0;ShowRec=1;ShowRes=0;ShowShape=1;FormName=;")
SWIMLANES = ("locked=false;orientation=0;width=0;inbar=false;names=false;color=-1;bold=false;fcol=0;tcol=-1;ofCol=-1;"
             "ufCol=-1;hl=1;ufh=0;hh=0;cls=0;bw=0;hli=0;bro=0;")
STYLEEX = ("ExcludeRTF=0;DocAll=0;HideQuals=0;AttPkg=1;ShowTests=0;ShowMaint=0;SuppressFOC={foc};{seq}MatrixActive=0;"
           "SwimlanesActive=1;KanbanActive=0;MatrixLineWidth=1;MatrixLineClr=0;MatrixLocked=0;TConnectorNotation=UML 2.1;"
           "TExplicitNavigability=0;AdvancedElementProps=1;AdvancedFeatureProps=1;AdvancedConnectorProps=1;"
           "m_bElementClassifier=1;SPT=1;MDGDgm=;STBLDgm=;ShowNotes=0;VisibleAttributeDetail=0;ShowOpRetType=1;"
           "SuppressBrackets=0;SuppConnectorLabels=0;PrintPageHeadFoot=0;ShowAsList=0;SuppressedCompartments=;Theme=:119;")
END_UNSPEC = "Union=0;Derived=0;AllowDuplicates=0;Owned=0;Navigable=Unspecified;"
END_NONNAV = "Union=0;Derived=0;AllowDuplicates=0;Owned=0;Navigable=Non-Navigable;"
END_NAV = "Union=0;Derived=0;AllowDuplicates=0;Owned=0;Navigable=Navigable;"
END_FLOW = "Union=0;Derived=0;AllowDuplicates=0;"


def guid(*parts):
    """Deterministic GUID in EA's style: upper case with a lower-case third group."""
    u = str(uuid.uuid5(NS, "|".join(parts))).upper().split("-")
    u[2] = u[2].lower()
    return "{" + "-".join(u) + "}"


def duid(*parts):
    return hashlib.sha1("|".join(parts).encode()).hexdigest()[:8].upper()


def insert(cur, table, **cols):
    keys = list(cols)
    cur.execute(f'INSERT INTO "{table}" ({",".join(chr(34) + k + chr(34) for k in keys)}) VALUES ({",".join("?" * len(keys))})',
                [cols[k] for k in keys])
    return cur.lastrowid


def make_base(src, dst):
    """Strip all model content from an existing EA project, keeping schema and EA reference data."""
    shutil.copyfile(src, dst)
    con = sqlite3.connect(dst)
    cur = con.cursor()
    for t in MODEL_TABLES:
        cur.execute(f'DELETE FROM "{t}"')
    cur.execute("DELETE FROM t_package WHERE Parent_ID <> 0")          # keep only the model root
    cur.execute("DELETE FROM sqlite_sequence WHERE name IN (%s)" % ",".join("?" * len(MODEL_TABLES)), MODEL_TABLES)
    cur.execute("UPDATE sqlite_sequence SET seq = (SELECT max(Package_ID) FROM t_package) WHERE name = 't_package'")
    cur.execute("UPDATE usys_system SET Value = ? WHERE Property = 'ProjectGUID'", (guid("project", "base"),))
    con.commit()
    cur.execute("VACUUM")
    con.close()


def build(base, out):
    shutil.copyfile(base, out)
    con = sqlite3.connect(out)
    cur = con.cursor()
    cur.execute("UPDATE usys_system SET Value = ? WHERE Property = 'ProjectGUID'", (guid("project", "C2D"),))
    root_id = cur.execute("SELECT Package_ID FROM t_package WHERE Parent_ID = 0").fetchone()[0]

    # ---- packages (each package is a t_package row plus a t_object row of type Package)
    pkg_id = {"": root_id}
    for pos, (key, name, parent) in enumerate(M.PACKAGES):
        g = guid("package", key)
        pid = insert(cur, "t_package", Name=name, Parent_ID=pkg_id[parent], CreatedDate=NOW, ModifiedDate=NOW, ea_guid=g,
                     IsControlled=0, Protected=0, UseDTD=0, LogXML=0, Version="1.0", TPos=pos,
                     PackageFlags="isModel=1;VICON=3;" if parent == "" else None)
        pkg_id[key] = pid
        insert(cur, "t_object", Object_Type="Package", Diagram_ID=0, Name=name, Author=AUTHOR, Version="1.0",
               Package_ID=pkg_id[parent], NType=0, Complexity="1", Effort=0, Backcolor=-1, BorderStyle=0, BorderWidth=-1,
               Fontcolor=-1, Bordercolor=-1, CreatedDate=NOW, ModifiedDate=NOW, Status="Proposed", Abstract="0", Tagged=0,
               PDATA1=str(pid), GenType="<none>", Phase="1.0", Scope="Public", Classifier=0, ea_guid=g, ParentID=0,
               IsRoot=0, IsLeaf=0, IsSpec=0, IsActive=0)

    # ---- elements (two passes so that parents and classifiers exist before they are referenced)
    obj_id, obj_guid = {}, {}
    order = sorted(M.E, key=lambda e: (1 if e.parent else 0, 1 if e.classifier else 0))
    for e in order:
        g = guid("element", e.key)
        name = e.name or None
        if e.etype == "InteractionFragment":
            name = f"[{e.name}]"
        oid = insert(cur, "t_object", Object_Type=e.etype, Diagram_ID=0, Name=name, Author=AUTHOR, Version="1.0",
                     Note=e.notes or None, Package_ID=pkg_id[e.pkg], Stereotype=e.stereo or None, NType=e.ntype,
                     Complexity="1", Effort=0, Backcolor=-1, BorderStyle=3 if e.etype == "ActivityPartition" else 0,
                     BorderWidth=-1, Fontcolor=-1, Bordercolor=-1, CreatedDate=NOW, ModifiedDate=NOW, Status="Proposed",
                     Abstract="1" if e.abstract else "0", Tagged=0, PDATA4="0" if e.etype == "Class" else None,
                     GenType="<none>", Phase="1.0", Scope="Public",
                     Classifier=obj_id[e.classifier] if e.classifier else 0,
                     Classifier_guid=obj_guid[e.classifier] if e.classifier else None,
                     ea_guid=g, ParentID=obj_id[e.parent] if e.parent else 0, IsRoot=0, IsLeaf=0, IsSpec=0, IsActive=0)
        obj_id[e.key], obj_guid[e.key] = oid, g
        for pos, (an, at) in enumerate(e.attrs):
            insert(cur, "t_attribute", Object_ID=oid, Name=an, Scope="Private", Containment="Not Specified", IsStatic=0,
                   IsCollection=0, IsOrdered=0, AllowDuplicates=0, LowerBound="1", UpperBound="1", Derived="0", Pos=pos,
                   Length=0, Precision=0, Scale=0, Const=0, Classifier="0", Type=at, ea_guid=guid("attr", e.key, an),
                   StyleEx="volatile=0;")
        for pos, (on, params, rt) in enumerate(e.ops):
            op = insert(cur, "t_operation", Object_ID=oid, Name=on, Scope="Public", Type=rt or "void",
                        Concurrency="Sequential", Pos=pos, Pure=0, IsRoot=0, IsLeaf=0, IsQuery=0,
                        ea_guid=guid("op", e.key, on))
            for ppos, (pn, pt) in enumerate(params):
                insert(cur, "t_operationparams", OperationID=op, Name=pn, Type=pt, Pos=ppos, Kind="in",
                       ea_guid=guid("param", e.key, on, pn))
        for prop, val in e.tags.items():
            insert(cur, "t_objectproperties", Object_ID=oid, Property=prop, Value=val, ea_guid=guid("tag", e.key, prop))

    # ---- structured text of the four detailed use cases as EA scenarios
    for uid, spec in R.UC_SPECS.items():
        oid = obj_id[M.UCKEY[uid]]
        insert(cur, "t_objectscenarios", Object_ID=oid, Scenario="Basic Path", ScenarioType="Basic Path", EValue=1,
               Notes="\r\n".join(f"{i + 1}. {s}" for i, s in enumerate(spec["basic"])), ea_guid=guid("scn", uid, "basic"))
        insert(cur, "t_objectscenarios", Object_ID=oid, Scenario="Alternate and exception flows", ScenarioType="Alternate",
               EValue=2, Notes="\r\n".join(spec["alt"]), ea_guid=guid("scn", uid, "alt"))

    # ---- connectors
    con_id = {}
    for c in M.C:
        directed = c.directed
        if c.ctype in ("ControlFlow",):
            s_style = d_style = END_FLOW
        elif directed:
            s_style, d_style = END_NONNAV, END_NAV
        else:
            s_style = d_style = END_UNSPEC
        cols = dict(Name=c.name or None, Direction="Source -> Destination" if directed else "Unspecified",
                    Connector_Type=c.ctype, SubType=c.subtype or None, SourceCard=c.smult or None, SourceAccess="Public",
                    DestCard=c.dmult or None, DestAccess="Public", SourceContainment="Unspecified",
                    DestContainment="Unspecified", SourceIsAggregate=0, SourceIsOrdered=0,
                    DestIsAggregate=2 if c.ctype == "Aggregation" else 0, DestIsOrdered=0,
                    Start_Object_ID=obj_id[c.src], End_Object_ID=obj_id[c.dst], Start_Edge=0, End_Edge=0, PtStartX=0,
                    PtStartY=0, PtEndX=0, PtEndY=0, SeqNo=0, HeadStyle=0, LineStyle=0, RouteStyle=3, IsBold=0,
                    LineColor=-1, Stereotype=c.stereo or None, VirtualInheritance="0", PDATA5="SX=0;SY=0;EX=0;EY=0;",
                    DiagramID=0, ea_guid=guid("connector", c.key), SourceIsNavigable=0, DestIsNavigable=1 if directed else 0,
                    IsRoot=0, IsLeaf=0, SourceChangeable="none", DestChangeable="none", SourceTS="instance",
                    DestTS="instance", Target2=0, SourceStyle=s_style, DestStyle=d_style)
        if c.ctype in ("ControlFlow", "StateFlow") and c.guard:
            cols["PDATA2"] = c.guard                          # guard condition
        if c.ctype == "StateFlow" and c.effect:
            cols["PDATA3"] = c.effect                         # effect (action on transition)
        if c.ctype == "UseCase" and c.guard:
            cols["Notes"] = "Condition: " + c.guard
        if c.ctype == "StateFlow":
            why = {t[0]: t[6] for t in M.LOT_TRANS}.get(c.key)
            if why:
                cols["Notes"] = why
        con_id[c.key] = insert(cur, "t_connector", **cols)

    # ---- diagrams
    for pos, d in enumerate(M.D):
        seq = "INT_ARGS=;INT_RET=;INT_ATT=;SeqTopMargin=50;" if d.dtype == "Sequence" else ""
        did = insert(cur, "t_diagram", Package_ID=pkg_id[d.pkg], ParentID=0, Diagram_Type=d.dtype, Name=d.name,
                     Version="1.0", Author=AUTHOR, ShowDetails=0, Notes=d.notes or None, AttPub=1, AttPri=1, AttPro=1,
                     Orientation="L" if d.size[0] > 900 else "P", cx=850, cy=1098, Scale=100, CreatedDate=NOW,
                     ModifiedDate=NOW, ShowForeign=1, ShowBorder=1, ShowPackageContents=1,
                     PDATA=DIAGRAM_PDATA.format(h=1 if d.hide_features else 0), Locked=0, ea_guid=guid("diagram", d.key),
                     TPos=pos, Swimlanes=SWIMLANES,
                     StyleEx=STYLEEX.format(foc=0 if d.dtype == "Sequence" else 1, seq=seq))
        rect, uid_of = {}, {}
        n = len(d.objs)
        # z-order: EA draws the highest Sequence number first (at the back), so containers get the high numbers
        back = [o for o in d.objs if M.ELEMENTS[o[0]].etype in ("Boundary", "ActivityPartition", "InteractionFragment")]
        mid = [o for o in d.objs if M.ELEMENTS[o[0]].etype in ("Node", "Device") and o not in back]
        front = [o for o in d.objs if o not in back and o not in mid]
        for z, (k, x, y, w, h) in enumerate(front + mid + back, start=1):
            e = M.ELEMENTS[k]
            u = duid(d.key, k)
            style = f"DUID={u};"
            if e.etype == "ActivityPartition":
                style = f"Dockable=on;DUID={u};VPartition=1;"
            insert(cur, "t_diagramobjects", Diagram_ID=did, Object_ID=obj_id[k], RectTop=-y, RectLeft=x, RectRight=x + w,
                   RectBottom=-(y + h), Sequence=z, ObjectStyle=style)
            rect[k], uid_of[k] = (x, y, w, h), u
        if d.dtype == "Sequence":
            centre = {k: x + w // 2 for k, (x, y, w, h) in rect.items()}
            for i, m in enumerate(d.msgs, start=1):
                xa, xb = centre[m.src], centre[m.dst]
                self_msg = m.src == m.dst
                right = xb >= xa
                insert(cur, "t_connector", Name=m.name, Direction="Source -> Destination", Connector_Type="Sequence",
                       SourceAccess="Public", DestAccess="Public", SourceContainment="Unspecified",
                       DestContainment="Unspecified", SourceIsAggregate=0, SourceIsOrdered=0, DestIsAggregate=0,
                       DestIsOrdered=0, Start_Object_ID=obj_id[m.src], End_Object_ID=obj_id[m.dst],
                       Start_Edge=2 if right else 4, End_Edge=2 if self_msg else (4 if right else 2),
                       PtStartX=xa + (5 if right else -5), PtStartY=-m.y,
                       PtEndX=xa + 5 if self_msg else xb - (5 if right else -5), PtEndY=-(m.y + 20) if self_msg else -m.y,
                       SeqNo=i, HeadStyle=0, LineStyle=0, RouteStyle=1, IsBold=0, LineColor=-1, VirtualInheritance="0",
                       PDATA1="Asynchronous" if m.kind == "async" else "Synchronous", PDATA2="retval=void;",
                       PDATA3="Call", PDATA4="1" if m.kind == "return" else "0", PDATA5="SX=0;SY=0;EX=0;EY=0;",
                       DiagramID=did, ea_guid=guid("message", d.key, str(i)), SourceIsNavigable=0, DestIsNavigable=1,
                       IsRoot=0, IsLeaf=0, SourceChangeable="none", DestChangeable="none", SourceTS="instance",
                       DestTS="instance", StateFlags="Activation=0;ExtendActivationUp=0;", Target2=0,
                       SourceStyle=END_NONNAV, DestStyle=END_NAV)
            continue
        for c in M.C:
            if c.src in rect and c.dst in rect:
                (x1, y1, w1, h1), (x2, y2, w2, h2) = rect[c.src], rect[c.dst]
                dx, dy = (x2 + w2 / 2) - (x1 + w1 / 2), (y2 + h2 / 2) - (y1 + h1 / 2)
                # edge of the source the line leaves from: 1 top, 2 right, 3 bottom, 4 left
                edge = (2 if dx > 0 else 4) if abs(dx) * h1 >= abs(dy) * w1 else (3 if dy > 0 else 1)
                ox, oy = d.offsets.get(c.key, (0, 0))
                insert(cur, "t_diagramlinks", DiagramID=did, ConnectorID=con_id[c.key],
                       Geometry=f"SX={ox};SY={-oy};EX={ox};EY={-oy};EDGE={edge};$LLB=;LLT=;LMT=;LMB=;LRT=;LRB=;IRHS=;ILHS=;",
                       Style=f"Mode=3;EOID={uid_of[c.dst]};SOID={uid_of[c.src]};Color=-1;LWidth=0;", Hidden=0)
    con.commit()
    problems = verify(cur)
    con.close()
    return problems


def verify(cur):
    """Structural checks on the finished repository. Returns a list of problems (empty = all passed)."""
    q = lambda sql: cur.execute(sql).fetchall()
    checks = {
     "sqlite integrity_check": [r for r in q("PRAGMA integrity_check") if r[0] != "ok"],
     "object in missing package": q("SELECT Object_ID FROM t_object WHERE Package_ID NOT IN (SELECT Package_ID FROM t_package)"),
     "object with missing parent": q("SELECT Object_ID FROM t_object WHERE ParentID <> 0 AND ParentID NOT IN (SELECT Object_ID FROM t_object)"),
     "object type not known to EA": q("SELECT DISTINCT Object_Type FROM t_object WHERE Object_Type NOT IN (SELECT Object_Type FROM t_objecttypes)"),
     "connector type not known to EA": q("SELECT DISTINCT Connector_Type FROM t_connector WHERE Connector_Type NOT IN (SELECT Connector_Type FROM t_connectortypes)"),
     "diagram type not known to EA": q("SELECT DISTINCT Diagram_Type FROM t_diagram WHERE Diagram_Type NOT IN (SELECT Diagram_Type FROM t_diagramtypes)"),
     "connector with missing end": q("SELECT Connector_ID FROM t_connector WHERE Start_Object_ID NOT IN (SELECT Object_ID FROM t_object) OR End_Object_ID NOT IN (SELECT Object_ID FROM t_object)"),
     "diagram in missing package": q("SELECT Diagram_ID FROM t_diagram WHERE Package_ID NOT IN (SELECT Package_ID FROM t_package)"),
     "diagram object without element or diagram": q("SELECT Instance_ID FROM t_diagramobjects WHERE Object_ID NOT IN (SELECT Object_ID FROM t_object) OR Diagram_ID NOT IN (SELECT Diagram_ID FROM t_diagram)"),
     "diagram link without connector or diagram": q("SELECT Instance_ID FROM t_diagramlinks WHERE ConnectorID NOT IN (SELECT Connector_ID FROM t_connector) OR DiagramID NOT IN (SELECT Diagram_ID FROM t_diagram)"),
     "diagram link whose ends are not both on the diagram": q(
        "SELECT l.Instance_ID FROM t_diagramlinks l JOIN t_connector c ON c.Connector_ID = l.ConnectorID WHERE "
        "c.Start_Object_ID NOT IN (SELECT Object_ID FROM t_diagramobjects o WHERE o.Diagram_ID = l.DiagramID) OR "
        "c.End_Object_ID NOT IN (SELECT Object_ID FROM t_diagramobjects o WHERE o.Diagram_ID = l.DiagramID)"),
     "message whose lifelines are not on its diagram": q(
        "SELECT c.Connector_ID FROM t_connector c WHERE c.Connector_Type = 'Sequence' AND ("
        "c.Start_Object_ID NOT IN (SELECT Object_ID FROM t_diagramobjects o WHERE o.Diagram_ID = c.DiagramID) OR "
        "c.End_Object_ID NOT IN (SELECT Object_ID FROM t_diagramobjects o WHERE o.Diagram_ID = c.DiagramID))"),
     "attribute or operation without owner": q("SELECT ID FROM t_attribute WHERE Object_ID NOT IN (SELECT Object_ID FROM t_object) "
                                               "UNION SELECT OperationID FROM t_operation WHERE Object_ID NOT IN (SELECT Object_ID FROM t_object)"),
     "duplicate GUID": q("SELECT g FROM (SELECT ea_guid g FROM t_object WHERE Object_Type <> 'Package' UNION ALL SELECT ea_guid FROM t_package "
                         "UNION ALL SELECT ea_guid FROM t_connector UNION ALL SELECT ea_guid FROM t_diagram) GROUP BY g HAVING count(*) > 1"),
     "package without its package element": q("SELECT Package_ID FROM t_package p WHERE Parent_ID <> 0 AND NOT EXISTS "
                                              "(SELECT 1 FROM t_object o WHERE o.Object_Type = 'Package' AND o.ea_guid = p.ea_guid AND o.PDATA1 = CAST(p.Package_ID AS TEXT))"),
     "lifeline with missing classifier": q("SELECT Object_ID FROM t_object WHERE Classifier <> 0 AND Classifier NOT IN (SELECT Object_ID FROM t_object)"),
     "degenerate rectangle": q("SELECT Instance_ID FROM t_diagramobjects WHERE RectRight <= RectLeft OR RectBottom >= RectTop"),
    }
    counts = {t: q(f'SELECT count(*) FROM "{t}"')[0][0] for t in
              ["t_package", "t_object", "t_attribute", "t_operation", "t_connector", "t_diagram", "t_diagramobjects", "t_diagramlinks"]}
    print("repository row counts:", counts)
    problems = []
    for name, rows in checks.items():
        print(f"  [{'PASS' if not rows else 'FAIL'}] no {name}" + ("" if not rows else f": {rows[:5]}"))
        if rows:
            problems.append(name)
    return problems


if __name__ == "__main__":
    if sys.argv[1] == "make-base":
        make_base(sys.argv[2], sys.argv[3]); print("base written:", sys.argv[3])
    else:
        bad = build(sys.argv[2], sys.argv[3])
        print("written:", sys.argv[3], "| structural problems:", len(bad))
        sys.exit(1 if bad else 0)
