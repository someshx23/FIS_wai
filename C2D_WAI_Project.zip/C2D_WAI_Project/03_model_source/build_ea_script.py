"""Writes 02_ea_model/C2D_build_script.js: a script for Enterprise Architect's own scripting window that builds the
C2D model through the Automation Interface. It is the fallback route if C2D_Model.qea does not open cleanly.

    python3 build_ea_script.py ../02_ea_model/C2D_build_script.js

The script is generated from the same definition as the .qea file (c2d_model.py). It has been run against a mock
of the Automation Interface (test_ea_script.js) to check syntax, control flow and object counts. It has NOT been
run inside Enterprise Architect.
"""
import json, sys
from pathlib import Path
import c2d_model as M

order = sorted(M.E, key=lambda e: (1 if e.parent else 0, 1 if e.classifier else 0))
model = dict(
    packages=[list(p) for p in M.PACKAGES],
    elements=[dict(key=e.key, etype=e.etype, name=(f"[{e.name}]" if e.etype == "InteractionFragment" else e.name), pkg=e.pkg,
                   stereo=e.stereo, notes=e.notes, parent=e.parent, attrs=[list(a) for a in e.attrs],
                   ops=[[o[0], [list(p) for p in o[1]], o[2]] for o in e.ops], ntype=e.ntype, abstract=bool(e.abstract),
                   classifier=e.classifier, tags=e.tags) for e in order],
    connectors=[dict(key=c.key, ctype=c.ctype, src=c.src, dst=c.dst, name=c.name, stereo=c.stereo, smult=c.smult, dmult=c.dmult,
                     directed=bool(c.directed), subtype=c.subtype, guard=c.guard, effect=c.effect) for c in M.C],
    diagrams=[],
)
BACK, MID = ("Boundary", "ActivityPartition", "InteractionFragment"), ("Node", "Device")
for d in M.D:
    back = [o for o in d.objs if M.ELEMENTS[o[0]].etype in BACK]
    mid = [o for o in d.objs if M.ELEMENTS[o[0]].etype in MID and o not in back]
    front = [o for o in d.objs if o not in back and o not in mid]
    model["diagrams"].append(dict(key=d.key, name=d.name, dtype=d.dtype, pkg=d.pkg, notes=d.notes,
                                  objs=[list(o) for o in front + mid + back],
                                  msgs=[[m.src, m.dst, m.name, m.y, m.kind] for m in d.msgs]))

RUNTIME = r'''
function log(s) { Session.Output(s); }

function main() {
    Repository.EnsureOutputVisible("Script");
    var root = Repository.GetTreeSelectedPackage();
    if (!root) { log("Select a package in the Browser (for example the model root) and run the script again."); return; }
    var pk = {}, el = {}, made = { packages: 0, elements: 0, connectors: 0, messages: 0, diagrams: 0, diagramObjects: 0 }, failed = [];
    var i, j, k;

    // ---- packages
    for (i = 0; i < MODEL.packages.length; i++) {
        var p = MODEL.packages[i];
        try {
            var parent = p[2] === "" ? root : pk[p[2]];
            var np = parent.Packages.AddNew(p[1], "");
            np.Update(); parent.Packages.Refresh();
            pk[p[0]] = np; made.packages++;
        } catch (err) { failed.push("package " + p[1] + ": " + err); }
    }

    // ---- elements (parents and classifiers come first in the list)
    for (i = 0; i < MODEL.elements.length; i++) {
        var e = MODEL.elements[i];
        try {
            var owner = e.parent ? el[e.parent].Elements : pk[e.pkg].Elements;
            var x = owner.AddNew(e.name, e.etype);
            if (e.stereo) x.Stereotype = e.stereo;
            if (e.notes) x.Notes = e.notes;
            if (e.ntype) x.Subtype = e.ntype;
            if (e.abstract) x.Abstract = "1";
            if (e.classifier) x.ClassifierID = el[e.classifier].ElementID;
            x.Update();
            for (j = 0; j < e.attrs.length; j++) {
                var a = x.Attributes.AddNew(e.attrs[j][0], e.attrs[j][1]);
                a.Visibility = "Private"; a.Update();
            }
            x.Attributes.Refresh();
            for (j = 0; j < e.ops.length; j++) {
                var m = x.Methods.AddNew(e.ops[j][0], e.ops[j][2] || "void");
                m.Visibility = "Public"; m.Update();
                for (k = 0; k < e.ops[j][1].length; k++) {
                    var q = m.Parameters.AddNew(e.ops[j][1][k][0], e.ops[j][1][k][1]);
                    q.Kind = "in"; q.Update();
                }
                m.Parameters.Refresh();
            }
            x.Methods.Refresh();
            for (var prop in e.tags) {
                if (e.tags.hasOwnProperty(prop)) { var t = x.TaggedValues.AddNew(prop, e.tags[prop]); t.Update(); }
            }
            x.TaggedValues.Refresh();
            owner.Refresh();
            el[e.key] = x; made.elements++;
        } catch (err) { failed.push("element " + e.key + ": " + err); }
    }

    // ---- connectors
    for (i = 0; i < MODEL.connectors.length; i++) {
        var c = MODEL.connectors[i];
        try {
            var s = el[c.src], d = el[c.dst];
            var con = s.Connectors.AddNew(c.name || "", c.ctype);
            con.SupplierID = d.ElementID;
            if (c.stereo) con.Stereotype = c.stereo;
            if (c.subtype) con.Subtype = c.subtype;
            con.Direction = c.directed ? "Source -> Destination" : "Unspecified";
            if (c.guard && (c.ctype === "ControlFlow" || c.ctype === "StateFlow")) con.TransitionGuard = c.guard;
            if (c.effect && c.ctype === "StateFlow") con.TransitionAction = c.effect;
            con.Update();
            if (c.smult) { con.ClientEnd.Cardinality = c.smult; con.ClientEnd.Update(); }
            if (c.dmult) { con.SupplierEnd.Cardinality = c.dmult; con.SupplierEnd.Update(); }
            if (c.ctype === "Aggregation") { con.SupplierEnd.Aggregation = 2; con.SupplierEnd.Update(); }   // composite, whole at the target end
            s.Connectors.Refresh();
            made.connectors++;
        } catch (err) { failed.push("connector " + c.key + ": " + err); }
    }

    // ---- diagrams, with the same element positions as the .qea file
    for (i = 0; i < MODEL.diagrams.length; i++) {
        var g = MODEL.diagrams[i];
        try {
            var dia = pk[g.pkg].Diagrams.AddNew(g.name, g.dtype);
            if (g.notes) dia.Notes = g.notes;
            dia.Update(); pk[g.pkg].Diagrams.Refresh();
            for (j = 0; j < g.objs.length; j++) {
                var o = g.objs[j], left = o[1], top = o[2], w = o[3], h = o[4];
                var dobj = dia.DiagramObjects.AddNew("l=" + left + ";r=" + (left + w) + ";t=" + top + ";b=" + (top + h) + ";", "");
                dobj.ElementID = el[o[0]].ElementID;
                dobj.Sequence = j + 1;
                dobj.Update(); made.diagramObjects++;
            }
            dia.DiagramObjects.Refresh();
            for (j = 0; j < g.msgs.length; j++) {
                var msg = g.msgs[j];
                var mc = el[msg[0]].Connectors.AddNew(msg[2], "Sequence");
                mc.SupplierID = el[msg[1]].ElementID;
                mc.DiagramID = dia.DiagramID;
                mc.SequenceNo = j + 1;
                mc.Update();
                try { mc.StartPointY = -msg[3]; mc.EndPointY = -msg[3]; mc.Update(); } catch (ignore1) { }
                try {                                                     // asynchronous and return messages
                    if (msg[4] === "async") Repository.Execute("UPDATE t_connector SET PDATA1='Asynchronous' WHERE Connector_ID=" + mc.ConnectorID);
                    if (msg[4] === "return") Repository.Execute("UPDATE t_connector SET PDATA4='1' WHERE Connector_ID=" + mc.ConnectorID);
                } catch (ignore2) { }
                made.messages++;
            }
            dia.Update(); made.diagrams++;
        } catch (err) { failed.push("diagram " + g.key + ": " + err); }
    }

    Repository.RefreshModelView(root.PackageID);
    log("C2D model built: " + made.packages + " packages, " + made.elements + " elements, " + made.connectors + " connectors, " +
        made.messages + " sequence messages, " + made.diagrams + " diagrams, " + made.diagramObjects + " diagram objects.");
    log("Expected:        " + EXPECTED);
    if (failed.length) { log(failed.length + " item(s) could not be created:"); for (i = 0; i < failed.length; i++) log("  " + failed[i]); }
    else log("No failures reported. Open each diagram and adjust the layout where needed.");
}

main();
'''

HEADER = '''!INC Local Scripts.EAConstants-JavaScript

/*
 * C2D_build_script.js : fallback build of the C2D model inside Enterprise Architect.
 *
 * Use this only if C2D_Model.qea does not open cleanly.
 *   1. Create a new, empty project (File > New Project) and select the model root in the Browser.
 *   2. Open the Scripting window (Specialize ribbon > Tools > Scripting), create a new JavaScript script
 *      in a local group, paste this whole file into it and run it.
 *   3. Read the System Output window (Script tab). It reports what was created and anything that failed.
 *
 * Generated by 03_model_source/build_ea_script.py from c2d_model.py, the same definition as the .qea file.
 * Status: checked against a mock of the Automation Interface for syntax, control flow and counts.
 *         NOT yet run inside Enterprise Architect. Expect to tidy diagram layouts by hand:
 *         the script places elements, and Enterprise Architect routes the connectors itself.
 * Known differences from the .qea file: CLS-01 shows attributes until you hide them in the diagram
 * properties, and the four use-case scenarios (Annexure C of the report) are not created.
 */
'''

def main(out):
    seq = sum(len(d["msgs"]) for d in model["diagrams"])
    expected = (f'{len(model["packages"])} packages, {len(model["elements"])} elements, {len(model["connectors"])} connectors, '
                f'{seq} sequence messages, {len(model["diagrams"])} diagrams, {sum(len(d["objs"]) for d in model["diagrams"])} diagram objects.')
    js = HEADER + "var EXPECTED = " + json.dumps(expected) + ";\nvar MODEL = " + json.dumps(model, ensure_ascii=True, separators=(",", ":")) + ";\n" + RUNTIME
    Path(out).write_text(js, encoding="utf-8")
    print("written", out, f"({len(js) // 1024} KB);", expected)

if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else str(Path(__file__).parent.parent / "02_ea_model" / "C2D_build_script.js"))
