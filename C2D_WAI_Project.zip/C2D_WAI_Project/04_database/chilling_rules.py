"""
Chilling rule engine of the C2D system (FR-08): prototype of the logic that the
ChillingMonitor control class runs on the society edge unit.

Rules (thresholds are configurable design values, NFR-10):
  R1 slow chilling   : milk above the target (4 C) r1_hours (4 h) after the latest shift of the lot was sealed
  R2 warm holding    : a chilled lot above r2_temp_c (7 C) for r2_minutes (30) consecutive minutes
  R3 sensor silence  : no reading for r3_minutes (20) while the lot is being chilled or held

The engine is fed events in time order and mirrors the part of the tank-lot
state machine (STM-01) that depends on temperature. It reports ONE breach per
episode: after a breach the lot is AtRisk and nothing more is evaluated until
a supervisor decision arrives (FR-11).

Run this file directly to execute the FR-08 acceptance test.
"""
from dataclasses import dataclass
from datetime import datetime, timedelta


@dataclass
class RuleConfig:
    chill_target_c: float = 4.0
    r1_hours: float = 4.0
    r2_temp_c: float = 7.0
    r2_minutes: int = 30
    r3_minutes: int = 20


class LotMonitor:
    """Chilling state of one tank lot."""

    def __init__(self, cfg: RuleConfig = RuleConfig()):
        self.cfg = cfg
        self.status = "Open"          # Open | Chilling | Chilled | AtRisk | Held | Rejected
        self.shift_open = True        # a lot is created by the first pour of a shift
        self.last_seal = None         # time the latest pooled shift was sealed (R1 clock)
        self.warm_since = None        # start of the current run above r2_temp_c
        self.last_reading_at = None
        self.silence_reported = False

    # -- events from collection ------------------------------------------------
    def shift_opened(self, now):
        """A further shift starts pouring into the lot. Returns the new status if it changed (LT04)."""
        self.shift_open = True
        if self.status == "Chilled":
            self.status, self.warm_since = "Chilling", None
            return "Chilling"
        return None

    def shift_sealed(self, now):
        """The shift ledger is sealed. Returns the new status if it changed (LT02)."""
        self.shift_open, self.last_seal = False, now
        if self.status == "Open":
            self.status = "Chilling"
            return "Chilling"
        return None

    # -- events from the sensor ------------------------------------------------
    def reading(self, now, temp_c):
        """A reading arrived. Returns None, 'Chilled' (LT03) or the code of the rule breached."""
        self.last_reading_at, self.silence_reported = now, False
        if self.shift_open:
            return None                               # warm milk is being added: rules are suspended
        c = self.cfg
        if self.status == "Chilling":
            if temp_c <= c.chill_target_c:
                self.status, self.warm_since = "Chilled", None
                return "Chilled"
            if self.last_seal and now >= self.last_seal + timedelta(hours=c.r1_hours):
                self.status = "AtRisk"
                return "R1_SlowChilling"
        elif self.status == "Chilled":
            if temp_c > c.r2_temp_c:
                self.warm_since = self.warm_since or now
                if now - self.warm_since >= timedelta(minutes=c.r2_minutes):
                    self.status = "AtRisk"
                    return "R2_WarmHolding"
            else:
                self.warm_since = None
        return None

    def tick(self, now):
        """Edge timer, called every interval whether or not a reading arrived. Returns 'R3_SensorSilence' or None."""
        if (self.status in ("Chilling", "Chilled") and not self.shift_open and self.last_reading_at
                and not self.silence_reported
                and now - self.last_reading_at >= timedelta(minutes=self.cfg.r3_minutes)):
            self.silence_reported, self.status = True, "AtRisk"
            return "R3_SensorSilence"
        return None

    # -- event from the supervisor ---------------------------------------------
    def decided(self, disposition):
        """Apply a disposition to an AtRisk lot (LT07 to LT09). Returns the new status."""
        self.status = {"Release": "Chilled", "HoldForDockTest": "Held", "Reject": "Rejected"}.get(disposition, self.status)
        self.warm_since = None
        return self.status


# ------------------------------------------------------------------ acceptance test for FR-08
def _run(series, seal_at=0, gaps=()):
    """series: temperature every 5 minutes after the lot's shift is sealed at minute seal_at."""
    t0 = datetime(2026, 9, 1, 7, 30)
    m = LotMonitor()
    m.shift_sealed(t0 + timedelta(minutes=seal_at))
    breaches = []
    for i, temp in enumerate(series):
        now = t0 + timedelta(minutes=5 * i)
        if i not in gaps:
            r = m.reading(now, temp)
            if r and r.startswith("R"):
                breaches.append((r, 5 * i))
        r = m.tick(now)
        if r:
            breaches.append((r, 5 * i))
    return breaches


def acceptance_test():
    """Five simulated series. Expected: one breach per episode at the first breaching reading, none when compliant."""
    cooling = [20 - 0.55 * i if 20 - 0.55 * i > 3.6 else 3.6 for i in range(80)]            # reaches 4 C after 2.5 h
    slow = [20 - 0.22 * i if 20 - 0.22 * i > 3.6 else 3.6 for i in range(80)]               # still 9.4 C at 4 h
    warm = cooling[:40] + [3.6 + 0.25 * i for i in range(20)] + [8.6] * 20                    # chilled, then warms past 7 C
    blip = cooling[:40] + [7.5] * 5 + [3.8] * 35                                              # 25 minutes above 7 C only
    cases = [
        ("compliant chilling", _run(cooling), []),
        ("slow chilling", _run(slow), [("R1_SlowChilling", 240)]),
        ("warm holding", _run(warm), [("R2_WarmHolding", 300)]),
        ("short warm blip", _run(blip), []),
        ("sensor silent 25 min", _run(cooling, gaps=range(50, 55)), [("R3_SensorSilence", 265)]),
    ]
    results = [(name, got, exp, got == exp) for name, got, exp in cases]
    return results


if __name__ == "__main__":
    ok = True
    for name, got, exp, passed in acceptance_test():
        ok &= passed
        print(f"[{'PASS' if passed else 'FAIL'}] {name}: breaches={got} expected={exp}")
    raise SystemExit(0 if ok else 1)
