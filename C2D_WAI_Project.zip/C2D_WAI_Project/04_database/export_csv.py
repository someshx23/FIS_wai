"""Exports every table of the prototype database to ../data/<table>.csv and writes ../data/DATA_DICTIONARY.md.
All data are synthetic (see generate_data.py); no real person, society or organisation is represented.

    python3 export_csv.py
"""
import csv, sqlite3
from pathlib import Path

HERE = Path(__file__).parent
OUT = HERE.parent / "data"
ABOUT = {
    "app_user": "Staff users and their single role (User class). Password hashes are of made-up strings.",
    "route": "Tanker routes (Route).", "society": "Village dairy cooperative societies (Society).",
    "member": "Members who pour milk (Member). Names, mobile numbers and bank references are placeholders.",
    "device": "Registered collection units, cooler sensors and edge units (Device).",
    "bulk_milk_cooler": "One bulk milk cooler per society (BulkMilkCooler).",
    "rate_chart": "Versioned price charts (RateChart).", "rate_chart_line": "Fat and SNF bands with a rate per kg (RateChartLine).",
    "tank_lot": "Milk held in one cooler between two pickups (TankLot); status follows state machine STM-01.",
    "lot_transition": "The allowed lot status changes, loaded from the UML model. No class: reference data used by a trigger.",
    "collection_shift": "Morning and evening shifts with the sealed ledger hash (CollectionShift).",
    "collection_entry": "One pour by one member, priced and hash-chained (CollectionEntry).",
    "temperature_reading": "Cooler readings at five-minute intervals while a lot is in the cooler (TemperatureReading).",
    "tanker_trip": "One tanker run on one day (TankerTrip).", "pickup_record": "Transfer of one lot to a tanker, confirmed by the driver (PickupRecord).",
    "dock_receipt": "Measurement and acceptance decision at the plant dock (DockReceipt).",
    "exception_case": "Chilling and variance cases in one table, told apart by case_type (ExceptionCase and its two subclasses).",
    "case_action": "Append-only log of what was done on a case (CaseAction).",
    "notification": "Messages queued for members and staff (Notification).",
    "payment_cycle": "Ten-day payment cycles (PaymentCycle).", "payment_statement": "One member's total for one cycle (PaymentStatement).",
    "audit_event": "Record of creations, decisions and administrative changes (AuditEvent).",
    "config": "Thresholds and tolerances used by the rules. No class: configuration (NFR-10).",
}

def main():
    db = sqlite3.connect(f"file:{HERE / 'c2d_prototype.sqlite'}?mode=ro", uri=True)
    OUT.mkdir(exist_ok=True)
    tables = [r[0] for r in db.execute("SELECT name FROM sqlite_master WHERE type='table' ORDER BY rowid")]
    md = ["# Data dictionary", "",
          "All files in this folder are exports of `04_database/c2d_prototype.sqlite`. **The data are synthetic.** They were produced by",
          "`04_database/generate_data.py` from a fixed random seed, with problems planted at seven societies so that every exception",
          "path of the design is exercised. They describe no real person, society, route or organisation, and nothing about the",
          "performance of any real dairy union can be concluded from them.", "",
          "Column constraints (value lists, ranges, foreign keys) are defined in `04_database/schema.sql`.", ""]
    for t in tables:
        cur = db.execute(f"SELECT * FROM {t}")
        cols = [c[0] for c in cur.description]
        n = 0
        with open(OUT / f"{t}.csv", "w", newline="", encoding="utf-8") as f:
            w = csv.writer(f); w.writerow(cols)
            for row in cur:
                w.writerow(row); n += 1
        info = db.execute(f"PRAGMA table_info({t})").fetchall()
        fks = {r[3]: f"{r[2]}.{r[4]}" for r in db.execute(f"PRAGMA foreign_key_list({t})")}
        md += [f"## {t}.csv", "", f"{ABOUT[t]} Rows: {n:,}.", "", "| Column | Type | Key | Required | Refers to |", "|---|---|---|---|---|"]
        md += [f"| {c[1]} | {c[2]} | {'PK' if c[5] else ''} | {'yes' if c[3] or c[5] else ''} | {fks.get(c[1], '')} |" for c in info]
        md.append("")
    (OUT / "DATA_DICTIONARY.md").write_text("\n".join(md), encoding="utf-8")
    print("exported", len(tables), "tables to", OUT)

if __name__ == "__main__":
    main()
