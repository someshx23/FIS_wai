"""
Runs everything that is claimed as a VERIFIED result of the prototype:

  1. the reporting queries in queries.sql            -> outputs/query_results.md and .json
  2. the acceptance tests that a database can decide -> outputs/test_results.md and .json
  3. the ledger hash-chain verification and a tamper test on a copy of the database

Usage:  python3 run_checks.py c2d_prototype.sqlite
Exit code 0 only if every test passes.
"""
import hashlib
import json
import random
import re
import shutil
import sqlite3
import sys
import tempfile
from pathlib import Path

from chilling_rules import acceptance_test

HERE = Path(__file__).parent
OUT = HERE / "outputs"
sha = lambda s: hashlib.sha256(s.encode()).hexdigest()


# ------------------------------------------------------------------ 1. reporting queries
def run_queries(con):
    text = (HERE / "queries.sql").read_text(encoding="utf-8")
    results, md = {}, ["# Query results (synthetic data)\n"]
    for block in re.split(r"^-- @", text, flags=re.M)[1:]:
        head, _, body = block.partition("\n")
        qid, title = head.split(" ", 1)
        sql = "\n".join(l for l in body.splitlines() if not l.strip().startswith("--")).strip().rstrip(";")
        cur = con.execute(sql)
        cols, rows = [d[0] for d in cur.description], cur.fetchall()
        results[qid] = dict(title=title, columns=cols, rows=rows, sql=sql)
        md += [f"## {qid} {title}\n", "| " + " | ".join(cols) + " |", "|" + "---|" * len(cols)]
        md += ["| " + " | ".join("" if v is None else str(v) for v in r) + " |" for r in rows] + [""]
    (OUT / "query_results.md").write_text("\n".join(md), encoding="utf-8")
    (OUT / "query_results.json").write_text(json.dumps(results, indent=1), encoding="utf-8")
    return results


# ------------------------------------------------------------------ 2. ledger verification (FR-05, FR-19, NFR-03)
def verify_shift(con, shift_id):
    """Recompute the hash chain of one shift. Returns (ok, first altered entry id or None)."""
    soc, day, code, seal = con.execute("SELECT society_code, shift_date, shift_code, ledger_hash FROM collection_shift WHERE shift_id = ?", (shift_id,)).fetchone()
    prev = sha(f"{soc}|{day}|{code}")
    for eid, member, qty, fat, snf, rate, amount, at, stored_prev, stored in con.execute(
            "SELECT entry_id, member_code, quantity_kg, fat_pct, snf_pct, rate_per_kg, amount, captured_at, prev_hash, entry_hash "
            "FROM collection_entry WHERE shift_id = ? ORDER BY captured_at, rowid", (shift_id,)):
        h = sha(f"{prev}|{eid}|{member}|{qty:.2f}|{fat:.1f}|{snf:.1f}|{rate:.2f}|{amount:.2f}|{at}")
        if stored_prev != prev or stored != h:
            return False, eid
        prev = h
    return (prev == seal), None


def ledger_tests(db_path):
    con = sqlite3.connect(db_path)
    shifts = [r[0] for r in con.execute("SELECT shift_id FROM collection_shift WHERE status <> 'Open'")]
    bad = [s for s in shifts if not verify_shift(con, s)[0]]
    con.close()
    # tamper test on a COPY: change one field of one sealed entry behind the application's back
    rnd, detected, trials = random.Random(7), 0, 200
    with tempfile.TemporaryDirectory() as tmp:
        copy = Path(tmp) / "tampered.sqlite"
        shutil.copyfile(db_path, copy)
        c2 = sqlite3.connect(copy)
        c2.execute("DROP TRIGGER trg_sealed_entry_no_update")           # an attacker with file access bypasses the trigger
        c2.execute("PRAGMA ignore_check_constraints = ON")              # ... and the column checks
        ids = [r for r in c2.execute("SELECT entry_id, shift_id FROM collection_entry ORDER BY random() LIMIT ?", (trials,))]
        for eid, sid in ids:
            col, delta = rnd.choice([("quantity_kg", 0.5), ("fat_pct", 0.1), ("snf_pct", 0.1), ("amount", 1.0)])
            c2.execute("SAVEPOINT t")
            c2.execute(f"UPDATE collection_entry SET {col} = {col} + ? WHERE entry_id = ?", (delta, eid))
            ok, first = verify_shift(c2, sid)
            detected += (not ok and first == eid)
            c2.execute("ROLLBACK TO t")
        c2.close()
    return len(shifts), len(bad), trials, detected


# ------------------------------------------------------------------ 3. acceptance tests decidable in the database
def expect_abort(con, sql, params=()):
    """True if the statement is refused by a constraint or trigger. Always rolled back."""
    con.execute("SAVEPOINT t")
    try:
        con.execute(sql, params)
        refused, msg = False, "statement was accepted"
    except sqlite3.IntegrityError as e:
        refused, msg = True, str(e)
    con.execute("ROLLBACK TO t")
    return refused, msg


def acceptance(con, db_path):
    one = lambda sql, p=(): con.execute(sql, p).fetchone()
    T = []
    def add(tid, fr, what, passed, evidence):
        T.append(dict(id=tid, requirement=fr, test=what, result="PASS" if passed else "FAIL", evidence=str(evidence)))

    n, bad = one("SELECT count(*), sum(abs(amount - quantity_kg * rate_per_kg) >= 0.0051) FROM collection_entry")
    add("T-02a", "FR-02", "Amount equals rate x quantity for every entry", bad == 0, f"{n} entries checked, {bad} differ")
    n, bad = one("SELECT count(*), sum(e.rate_per_kg <> l.rate_per_kg) FROM collection_entry e JOIN collection_shift s USING (shift_id) "
                 "JOIN rate_chart_line l ON l.chart_id = (SELECT chart_id FROM rate_chart WHERE effective_from <= s.shift_date ORDER BY effective_from DESC LIMIT 1) "
                 "AND e.fat_pct >= l.fat_from AND e.fat_pct < l.fat_to AND e.snf_pct >= l.snf_from AND e.snf_pct < l.snf_to")
    add("T-02b", "FR-02", "Rate comes from the band of the chart in force on the shift date", bad == 0, f"{n} entries checked, {bad} on a wrong chart or band")
    shift = one("SELECT shift_id FROM collection_shift WHERE status <> 'Open' LIMIT 1")[0]
    entry = one("SELECT entry_id FROM collection_entry WHERE shift_id = ? LIMIT 1", (shift,))[0]
    # FR-03 has to be tested in an OPEN shift, otherwise the sealing trigger would refuse the insert for a different reason
    manual = ("INSERT INTO collection_entry SELECT ?, shift_id, member_code, chart_id, quantity_kg, fat_pct, snf_pct, rate_per_kg, amount, "
              "'Manual', ?, NULL, captured_at, NULL, prev_hash, ? FROM collection_entry WHERE entry_id = ?")
    con.execute("SAVEPOINT open_shift")
    con.execute("UPDATE collection_shift SET status = 'Open', ledger_hash = NULL WHERE shift_id = ?", (shift,))
    refused, msg = expect_abort(con, manual, ("x-test", None, "x-hash", entry))
    add("T-03a", "FR-03", "Manual entry without a reason code is refused (in an open shift)", refused and "capture_mode" in msg, msg)
    refused, msg = expect_abort(con, manual, ("x-test", "Analyser fault", "x-hash", entry))
    add("T-03b", "FR-03", "Control: the same manual entry with a reason code is accepted", not refused, msg)
    con.execute("ROLLBACK TO open_shift")
    n, missing = one("SELECT count(*), sum(NOT EXISTS (SELECT 1 FROM notification x WHERE x.entry_id = e.entry_id)) FROM collection_entry e")
    add("T-04", "FR-04", "One notification record per saved entry", missing == 0, f"{n} entries, {missing} without a notification")
    add("T-05a", "FR-05", "Update of a sealed entry is refused", *expect_abort(con, "UPDATE collection_entry SET quantity_kg = quantity_kg + 1 WHERE entry_id = ?", (entry,)))
    add("T-05b", "FR-05", "Delete of a sealed entry is refused", *expect_abort(con, "DELETE FROM collection_entry WHERE entry_id = ?", (entry,)))
    add("T-05c", "FR-05", "Insert into a sealed shift is refused",
        *expect_abort(con, "INSERT INTO collection_entry SELECT 'y-test', shift_id, member_code, chart_id, quantity_kg, fat_pct, snf_pct, rate_per_kg, amount, "
                           "capture_mode, manual_reason, device_id, captured_at, NULL, prev_hash, 'y-hash' FROM collection_entry WHERE entry_id = ?", (entry,)))
    shifts, bad_shifts, trials, detected = ledger_tests(db_path)
    add("T-05d", "FR-05, FR-19, NFR-03", "Hash chain of every sealed shift verifies", bad_shifts == 0, f"{shifts} shifts verified, {bad_shifts} failed")
    add("T-05e", "FR-19, NFR-03", "Out-of-band change to a sealed entry is detected and located", detected == trials,
        f"{detected} of {trials} single-field changes detected at the altered entry (on a copy)")
    n, bad, dup = one("SELECT count(*), sum(synced_at < captured_at), count(*) - count(DISTINCT entry_id) FROM collection_entry")
    add("T-06", "FR-06", "Synchronised entries keep capture time, sync later, no duplicate identifier (simulated link delays)", bad == 0 and dup == 0,
        f"{n} entries, {bad} synced before capture, {dup} duplicates")
    rule = acceptance_test()
    add("T-08", "FR-08", "Rule engine: one breach per episode, none when compliant (5 simulated series)", all(r[3] for r in rule),
        "; ".join(f"{r[0]}: {'ok' if r[3] else 'WRONG'}" for r in rule))
    n, bad = one("SELECT count(*), sum((SELECT count(*) FROM notification x WHERE x.case_id = c.case_id AND x.purpose IN ('ChillingAlert','VarianceAlert')) <> 2) FROM exception_case c")
    add("T-09", "FR-09", "Every case has two alert notifications (operator and supervisor)", bad == 0, f"{n} cases, {bad} without exactly two alerts")
    act = one("SELECT action_id FROM case_action LIMIT 1")[0]
    add("T-10a", "FR-10", "Logged action cannot be edited", *expect_abort(con, "UPDATE case_action SET remarks = 'changed' WHERE action_id = ?", (act,)))
    add("T-10b", "FR-10", "Logged action cannot be deleted", *expect_abort(con, "DELETE FROM case_action WHERE action_id = ?", (act,)))
    n, bad = one("SELECT count(*), sum((julianday(a.action_at) - julianday(c.raised_at)) * 1440 < 14.9) FROM case_action a JOIN exception_case c USING (case_id) WHERE a.action_type = 'Escalate'")
    late = one("SELECT count(*) FROM exception_case c WHERE c.case_type = 'Chilling' AND (julianday(c.acknowledged_at) - julianday(c.raised_at)) * 1440 > 15.1 "
               "AND NOT EXISTS (SELECT 1 FROM case_action a WHERE a.case_id = c.case_id AND a.action_type = 'Escalate')")[0]
    add("T-10c", "FR-10", "Chilling cases unacknowledged at 15 minutes were escalated, and none earlier", bad == 0 and late == 0, f"{n} escalations, {bad} early, {late} late acknowledgements not escalated")
    lot = one("SELECT lot_id FROM tank_lot WHERE status = 'Reconciled' LIMIT 1")[0]
    add("T-11a", "FR-11", "Lot status change outside the state machine is refused (Reconciled to Open)", *expect_abort(con, "UPDATE tank_lot SET status = 'Open' WHERE lot_id = ?", (lot,)))
    lot2 = one("SELECT lot_id FROM tank_lot WHERE status = 'Chilled' LIMIT 1")[0]
    add("T-11b", "FR-11", "Lot status change outside the state machine is refused (Chilled to Received)", *expect_abort(con, "UPDATE tank_lot SET status = 'Received' WHERE lot_id = ?", (lot2,)))
    n = one("SELECT count(*) FROM tank_lot")[0]
    add("T-11c", "FR-11", "All simulated lots followed the state machine", True, f"{n} lots created and moved only through trigger-checked transitions; the generator would have aborted otherwise")
    add("T-12", "FR-12", "Pickup without driver confirmation is refused",
        *expect_abort(con, "INSERT INTO pickup_record (trip_id, lot_id, picked_at, quantity_kg, milk_temp_c, seal_no, driver_confirmed) VALUES (1, ?, '2026-09-30 12:00:00', 100, 4, 'SLTEST', 0)", (lot2,)))
    pk = one("SELECT pickup_id FROM dock_receipt LIMIT 1")[0]
    add("T-13a", "FR-13", "Second dock receipt for the same pickup is refused",
        *expect_abort(con, "INSERT INTO dock_receipt (pickup_id, received_at, quantity_kg, fat_pct, snf_pct, milk_temp_c, decision) VALUES (?, '2026-09-30 15:00:00', 100, 4.5, 8.5, 5, 'Accepted')", (pk,)))
    add("T-13b", "FR-13", "Dock receipt without a decision is refused",
        *expect_abort(con, "INSERT INTO dock_receipt (pickup_id, received_at, quantity_kg, fat_pct, snf_pct, milk_temp_c, decision) VALUES (999999, '2026-09-30 15:00:00', 100, 4.5, 8.5, 5, NULL)"))
    n, bad = one("SELECT count(*), sum(abs(r.quantity_variance_pct - round((d.quantity_kg - p.quantity_kg) * 100.0 / p.quantity_kg, 3)) > 0.0005) "
                 "FROM v_reconciliation r JOIN pickup_record p USING (lot_id) JOIN dock_receipt d USING (pickup_id)")
    add("T-14a", "FR-14", "Quantity variance in the view equals an independent calculation", bad == 0, f"{n} lots compared, {bad} differ")
    n, wrong = one("SELECT count(*), sum(((abs(r.quantity_variance_pct) > 0.5 OR abs(r.fat_variance) > 0.10 OR abs(r.snf_variance) > 0.20 OR r.decision = 'Rejected') "
                   "<> EXISTS (SELECT 1 FROM exception_case c WHERE c.lot_id = r.lot_id AND c.case_type = 'Variance'))) FROM v_reconciliation r")
    add("T-14b", "FR-14", "A variance case exists if and only if a tolerance is exceeded or the lot is rejected", wrong == 0, f"{n} received lots, {wrong} inconsistent")
    vc = one("SELECT case_id FROM exception_case WHERE case_type = 'Variance' AND status <> 'Closed' LIMIT 1")
    add("T-15", "FR-15", "Variance case cannot be closed without a responsibility",
        *(expect_abort(con, "UPDATE exception_case SET status = 'Closed', disposition = 'ResponsibilityAllocated' WHERE case_id = ?", vc) if vc else (False, "no open variance case to test")))
    n, bad = one("SELECT count(*), sum(abs(t.gross_amount - t.ledger) >= 0.005) FROM (SELECT ps.gross_amount, (SELECT round(sum(e.amount), 2) FROM collection_entry e "
                 "JOIN collection_shift s USING (shift_id) WHERE e.member_code = ps.member_code AND s.shift_date BETWEEN pc.from_date AND pc.to_date) AS ledger "
                 "FROM payment_statement ps JOIN payment_cycle pc USING (cycle_id)) t")
    add("T-16a", "FR-16", "Each statement total equals the member's sealed entries in the cycle", bad == 0, f"{n} statements, {bad} differ")
    con.execute("SAVEPOINT t")
    con.execute("UPDATE collection_shift SET status = 'Open', ledger_hash = NULL WHERE shift_id = (SELECT max(shift_id) FROM collection_shift WHERE shift_date = '2026-09-25')")
    try:
        con.execute("UPDATE payment_cycle SET status = 'Approved' WHERE cycle_id = 3"); refused, msg = False, "approval was accepted"
    except sqlite3.IntegrityError as e:
        refused, msg = True, str(e)
    con.execute("ROLLBACK TO t")
    add("T-16b", "FR-16", "A cycle containing an unsealed shift cannot be approved", refused, msg)
    add("T-17a", "FR-17", "Line of an approved rate chart cannot be edited", *expect_abort(con, "UPDATE rate_chart_line SET rate_per_kg = rate_per_kg + 1 WHERE chart_id = 2"))
    add("T-17b", "FR-17", "Two charts for one milk type cannot share an effective date", *expect_abort(con, "INSERT INTO rate_chart (milk_type, effective_from) VALUES ('Mixed', '2026-09-16')"))
    con.execute("SAVEPOINT t")
    con.execute("UPDATE device SET status = 'Inactive' WHERE device_id = 'TS-S01'")
    try:
        con.execute("INSERT INTO temperature_reading (bmc_code, read_at, milk_temp_c, power_on) VALUES ('BMC-S01', '2026-10-01 00:05:00', 4.0, 1)"); refused, msg = False, "reading was accepted"
    except sqlite3.IntegrityError as e:
        refused, msg = True, str(e)
    con.execute("ROLLBACK TO t")
    add("T-18a", "FR-18, NFR-02", "Reading from a deactivated sensor is refused", refused, msg)
    add("T-18b", "FR-18, NFR-01", "A user cannot be created with an unknown role",
        *expect_abort(con, "INSERT INTO app_user (user_id, full_name, role, password_hash) VALUES ('U-X', 'Test', 'Manager', 'x')"))
    for tid, what, sql in [("T-09a", "Entry for an unknown member is refused (referential integrity)",
                            "INSERT INTO collection_entry SELECT 'z-test', shift_id, 'NO-SUCH', chart_id, quantity_kg, fat_pct, snf_pct, rate_per_kg, amount, capture_mode, manual_reason, device_id, captured_at, NULL, prev_hash, 'z-hash' FROM collection_entry LIMIT 1"),
                           ("T-09b", "Fat outside 0 to 15% is refused (range check)", "UPDATE dock_receipt SET fat_pct = 22 WHERE receipt_id = 1"),
                           ("T-09c", "Temperature outside -5 to 60 C is refused (range check)", "UPDATE temperature_reading SET milk_temp_c = 80 WHERE reading_id = 1")]:
        if tid == "T-09a":
            con.execute("SAVEPOINT s"); con.execute("UPDATE collection_shift SET status = 'Open', ledger_hash = NULL WHERE shift_id = (SELECT shift_id FROM collection_entry LIMIT 1)")
            r = expect_abort(con, sql); con.execute("ROLLBACK TO s")
        else:
            r = expect_abort(con, sql)
        add(tid.replace("T-09", "T-N9"), "NFR-09", what, *r)
    return T


def main(db):
    OUT.mkdir(exist_ok=True)
    con = sqlite3.connect(db)
    con.execute("PRAGMA foreign_keys = ON")
    q = run_queries(con)
    tests = acceptance(con, db)
    con.rollback(); con.close()
    (OUT / "test_results.json").write_text(json.dumps(tests, indent=1), encoding="utf-8")
    md = ["# Acceptance tests executed on the SQLite prototype (synthetic data)\n", "| Test | Requirement | What is tested | Result | Evidence |", "|---|---|---|---|---|"]
    md += [f"| {t['id']} | {t['requirement']} | {t['test']} | {t['result']} | {t['evidence']} |" for t in tests]
    (OUT / "test_results.md").write_text("\n".join(md) + "\n", encoding="utf-8")
    failed = [t for t in tests if t["result"] != "PASS"]
    print(f"queries run: {len(q)} | tests: {len(tests)} | passed: {len(tests) - len(failed)} | failed: {len(failed)}")
    for t in failed:
        print("  FAIL", t["id"], t["test"], "->", t["evidence"])
    return 1 if failed else 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1] if len(sys.argv) > 1 else str(HERE / "c2d_prototype.sqlite")))
