-- ============================================================================
-- C2D prototype: business-reporting queries (FR-20)
-- Each query is introduced by a line "-- @Qn title". run_queries.py executes
-- them against c2d_prototype.sqlite and writes the results to outputs/.
-- The data are SYNTHETIC (see generate_data.py); the results show that the
-- schema answers the questions, not how any real union performs.
-- ============================================================================

-- @Q1 Procurement by route and payment cycle
SELECT so.route_code AS route, pc.cycle_id AS cycle, pc.from_date, pc.to_date, pc.status AS cycle_status,
       count(DISTINCT e.member_code)                                AS members_pouring,
       round(sum(e.quantity_kg))                                    AS quantity_kg,
       round(sum(e.quantity_kg * e.fat_pct) / sum(e.quantity_kg), 2) AS avg_fat_pct,
       round(sum(e.quantity_kg * e.snf_pct) / sum(e.quantity_kg), 2) AS avg_snf_pct,
       round(sum(e.amount))                                         AS amount_rs,
       round(sum(e.amount) / sum(e.quantity_kg), 2)                 AS rs_per_kg
FROM collection_entry e
JOIN collection_shift s ON s.shift_id = e.shift_id
JOIN society so         ON so.society_code = s.society_code
JOIN payment_cycle pc   ON s.shift_date BETWEEN pc.from_date AND pc.to_date
GROUP BY so.route_code, pc.cycle_id
ORDER BY so.route_code, pc.cycle_id;

-- @Q2 Chilling compliance by society
-- LEFT JOIN keeps societies that had no chilling case at all.
SELECT so.society_code AS society, so.route_code AS route,
       count(DISTINCT l.lot_id)                                     AS lots,
       count(DISTINCT c.lot_id)                                     AS lots_with_chilling_case,
       round(100.0 * (count(DISTINCT l.lot_id) - count(DISTINCT c.lot_id)) / count(DISTINCT l.lot_id), 1) AS pct_lots_compliant,
       coalesce(sum(c.rule_code = 'R1_SlowChilling'), 0)            AS r1_slow_chilling,
       coalesce(sum(c.rule_code = 'R2_WarmHolding'), 0)             AS r2_warm_holding,
       coalesce(sum(c.rule_code = 'R3_SensorSilence'), 0)           AS r3_sensor_silence
FROM society so
JOIN bulk_milk_cooler b ON b.society_code = so.society_code
JOIN tank_lot l         ON l.bmc_code = b.bmc_code
LEFT JOIN exception_case c ON c.lot_id = l.lot_id AND c.case_type = 'Chilling'
GROUP BY so.society_code
ORDER BY pct_lots_compliant, so.society_code;

-- @Q3 Pickup-to-dock variance by society
SELECT r.society_code AS society, r.route_code AS route, count(*) AS lots_received,
       round(avg(r.quantity_variance_pct), 2) AS avg_quantity_variance_pct,
       round(sum(r.dock_kg - r.pickup_kg))    AS net_kg_difference,
       sum(abs(r.quantity_variance_pct) > (SELECT value FROM config WHERE key = 'tol_quantity_pct'))
                                              AS lots_beyond_quantity_tolerance,
       round(avg(r.fat_variance), 3)          AS avg_fat_variance,
       sum(abs(r.fat_variance) > (SELECT value FROM config WHERE key = 'tol_fat'))
                                              AS lots_beyond_fat_tolerance,
       sum(r.decision = 'Rejected')           AS lots_rejected_at_dock
FROM v_reconciliation r
GROUP BY r.society_code
ORDER BY avg_quantity_variance_pct;

-- @Q4 Exception handling times by case type
SELECT c.case_type,
       count(*)                                                     AS cases,
       sum(c.status <> 'Closed')                                    AS still_open,
       sum(EXISTS (SELECT 1 FROM case_action a WHERE a.case_id = c.case_id AND a.action_type = 'Escalate')) AS escalated,
       round(avg((julianday(c.acknowledged_at) - julianday(c.raised_at)) * 1440), 1) AS avg_minutes_to_acknowledge,
       round(max((julianday(c.acknowledged_at) - julianday(c.raised_at)) * 1440), 0) AS max_minutes_to_acknowledge,
       round(avg((julianday(c.closed_at) - julianday(c.raised_at)) * 24), 1)        AS avg_hours_to_close
FROM exception_case c
GROUP BY c.case_type;

-- @Q5 Manual entries and quality variance by society
-- Two aggregates joined on society: a high manual share together with a negative fat variance is an audit signal.
SELECT m.society, m.entries, m.manual_entries, m.manual_pct, v.avg_fat_variance, v.lots_beyond_fat_tolerance
FROM (SELECT s.society_code AS society, count(*) AS entries, sum(e.capture_mode = 'Manual') AS manual_entries,
             round(100.0 * sum(e.capture_mode = 'Manual') / count(*), 1) AS manual_pct
      FROM collection_entry e JOIN collection_shift s ON s.shift_id = e.shift_id
      GROUP BY s.society_code) m
JOIN (SELECT society_code AS society, round(avg(fat_variance), 3) AS avg_fat_variance,
             sum(abs(fat_variance) > (SELECT value FROM config WHERE key = 'tol_fat')) AS lots_beyond_fat_tolerance
      FROM v_reconciliation GROUP BY society_code) v ON v.society = m.society
ORDER BY m.manual_pct DESC;

-- @Q6 Payment statement check for cycle 2 (statement total against the sealed ledger)
SELECT ps.member_code, ps.total_quantity_kg AS statement_kg, ps.gross_amount AS statement_rs,
       round(sum(e.quantity_kg), 2) AS ledger_kg, round(sum(e.amount), 2) AS ledger_rs,
       CASE WHEN abs(ps.gross_amount - sum(e.amount)) < 0.005 THEN 'match' ELSE 'MISMATCH' END AS result
FROM payment_statement ps
JOIN payment_cycle pc   ON pc.cycle_id = ps.cycle_id
JOIN collection_entry e ON e.member_code = ps.member_code
JOIN collection_shift s ON s.shift_id = e.shift_id AND s.shift_date BETWEEN pc.from_date AND pc.to_date
WHERE pc.cycle_id = 2
GROUP BY ps.statement_id
ORDER BY ps.gross_amount DESC
LIMIT 8;

-- @Q7 Time taken to reach 4 C after a shift is sealed, by society
-- For every sealed shift: the first reading at or below the target within 12 hours of the seal. Readings exist only while a lot is
-- in the cooler, so a shift that "never reached" the target was picked up, or its lot rejected, before it got there.
WITH chill AS (
    SELECT s.shift_id, s.society_code,
           (SELECT min(t.read_at) FROM temperature_reading t
             WHERE t.bmc_code = 'BMC-' || s.society_code AND t.read_at >= s.sealed_at
               AND t.read_at <= datetime(s.sealed_at, '+12 hours')
               AND t.milk_temp_c <= (SELECT value FROM config WHERE key = 'chill_target_c')) AS chilled_at,
           s.sealed_at
    FROM collection_shift s WHERE s.status <> 'Open')
SELECT society_code AS society, count(*) AS shifts,
       round(avg((julianday(chilled_at) - julianday(sealed_at)) * 24), 2) AS avg_hours_to_target,
       round(max((julianday(chilled_at) - julianday(sealed_at)) * 24), 2) AS max_hours_to_target,
       sum((julianday(chilled_at) - julianday(sealed_at)) * 24 > (SELECT value FROM config WHERE key = 'r1_hours')) AS shifts_over_limit,
       sum(chilled_at IS NULL)                                      AS shifts_never_reached
FROM chill
GROUP BY society_code
ORDER BY avg_hours_to_target DESC;

-- @Q8 Lots by final status
SELECT l.status, count(*) AS lots, round(sum(l.quantity_kg)) AS quantity_kg,
       round(100.0 * count(*) / (SELECT count(*) FROM tank_lot), 1) AS pct_of_lots
FROM tank_lot l
GROUP BY l.status
ORDER BY lots DESC;

-- @Q9 Synchronisation lag by society (offline tolerance, FR-06)
SELECT s.society_code AS society, count(*) AS entries,
       round(avg((julianday(e.synced_at) - julianday(s.sealed_at)) * 1440), 1) AS avg_minutes_seal_to_sync,
       round(max((julianday(e.synced_at) - julianday(s.sealed_at)) * 1440), 0) AS max_minutes_seal_to_sync,
       sum(e.synced_at IS NULL)                                      AS entries_not_yet_synced,
       sum(e.synced_at < e.captured_at)                              AS sync_before_capture
FROM collection_entry e JOIN collection_shift s ON s.shift_id = e.shift_id
GROUP BY s.society_code
ORDER BY max_minutes_seal_to_sync DESC
LIMIT 6;

-- @Q10 Responsibility recorded for closed variance cases, by route
SELECT so.route_code AS route, c.responsibility, count(*) AS cases,
       round(sum(r.dock_kg - r.pickup_kg)) AS net_kg_difference
FROM exception_case c
JOIN v_reconciliation r ON r.lot_id = c.lot_id
JOIN society so         ON so.society_code = r.society_code
WHERE c.case_type = 'Variance' AND c.status = 'Closed'
GROUP BY so.route_code, c.responsibility
ORDER BY so.route_code, cases DESC;
