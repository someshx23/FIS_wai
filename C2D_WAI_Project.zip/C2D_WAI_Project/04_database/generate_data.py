"""
Builds the SQLite prototype database of the C2D system and fills it with a
SYNTHETIC data set: 30 days of collection, chilling, pickup, dock receipt,
exception handling and payment for an illustrative union of 12 societies on
3 routes (240 members).

Nothing here is real data. The numbers are produced by the simulation below
from a fixed random seed, with deliberately planted problems so that the
exception workflow and the reports have something to show:

    S02  medium-length power cuts and an operator slow to acknowledge alerts
    S04  pickup quantity over-read by about 1.2% (dip-stick bias)
    S05  cooler compressor fault from day 8 to day 14 (slow chilling)
    S07  frequent manual entries and fat over-statement
    S08  long power cuts (warm holding)
    S10  flaky temperature sensor (silence)

Every insert and update goes through the constraints and triggers of
schema.sql, so the run is also a test: if the simulated workflow broke the
tank-lot state machine or the sealing rules, the script would stop.

Usage:  python3 generate_data.py c2d_prototype.sqlite
"""
import hashlib
import math
from decimal import Decimal, ROUND_HALF_UP
import random
import sqlite3
import sys
import uuid
from datetime import datetime, timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "03_model_source"))
import c2d_model as M                                   # the state machine comes from the UML model
from chilling_rules import LotMonitor, RuleConfig

SEED = 20261116
START = datetime(2026, 9, 1)
DAYS, STEP = 30, timedelta(minutes=5)
END = START + timedelta(days=DAYS)
CFG = RuleConfig()
TOL_QTY, TOL_FAT, TOL_SNF, ACK_LIMIT = 0.5, 0.10, 0.20, 15
WARM_RATE = 2.4      # C per hour gained by the tank while power is off: a SIMULATION ASSUMPTION, not a measured value
ts = lambda d: d.strftime("%Y-%m-%d %H:%M:%S")
sha = lambda s: hashlib.sha256(s.encode()).hexdigest()

PROFILE = {  # per-society simulation parameters (defaults below)
    "S02": dict(ack_median=14, outage_p=0.22, outage_minutes=(100, 260)), "S04": dict(pickup_bias=0.012), "S05": dict(fault_days=(8, 14)),
    "S07": dict(manual_rate=0.09, fat_bias=-0.14), "S08": dict(outage_p=0.40, outage_minutes=(150, 420), ack_median=9),
    "S10": dict(gap_p=0.30), "S11": dict(manual_rate=0.05),
}
DEFAULT = dict(ack_median=5, pickup_bias=0.0, fault_days=None, manual_rate=0.015, fat_bias=-0.02, outage_p=0.05,
               outage_minutes=(30, 110), gap_p=0.01)


def entry_hash(prev, e):
    """Hash of one ledger entry, chained to the previous one (FR-05)."""
    return sha(f"{prev}|{e['entry_id']}|{e['member']}|{e['qty']:.2f}|{e['fat']:.1f}|{e['snf']:.1f}|"
               f"{e['rate']:.2f}|{e['amount']:.2f}|{ts(e['at'])}")


def master_data(cur, rnd):
    cur.executemany("INSERT INTO config VALUES (?,?,?)", [
        ("chill_target_c", CFG.chill_target_c, "Target milk temperature (FAO, 2016: 4 C within 3 to 4 hours)"),
        ("r1_hours", CFG.r1_hours, "R1: hours after shift seal by which the target must be reached"),
        ("r2_temp_c", CFG.r2_temp_c, "R2: warm-holding limit for a chilled lot (design value)"),
        ("r2_minutes", CFG.r2_minutes, "R2: consecutive minutes above the limit (design value)"),
        ("r3_minutes", CFG.r3_minutes, "R3: sensor silence limit (design value)"),
        ("ack_minutes", ACK_LIMIT, "Escalation limit for an unacknowledged case (design value)"),
        ("tol_quantity_pct", TOL_QTY, "Pickup-to-dock quantity tolerance, % (design value)"),
        ("tol_fat", TOL_FAT, "Ledger-to-dock fat tolerance, percentage points (design value)"),
        ("tol_snf", TOL_SNF, "Ledger-to-dock SNF tolerance, percentage points (design value)")])
    cur.executemany("INSERT INTO lot_transition VALUES (?,?,?)",
                    [(s[3:], d[3:], k) for k, s, d, *_ in M.LOT_TRANS if s.startswith("LS_") and d.startswith("LS_")])
    users = [("U-ADM", "System Administrator 1", "SystemAdministrator"), ("U-DOCK", "Dock Officer 1", "DockOfficer"),
             ("U-ACC", "Accounts Officer 1", "AccountsOfficer")] + \
            [(f"U-SUP{r}", f"Route Supervisor {r}", "RouteSupervisor") for r in (1, 2, 3)]
    cur.executemany("INSERT INTO app_user (user_id, full_name, role, password_hash) VALUES (?,?,?,?)",
                    [(u, n, r, sha("demo|" + u)) for u, n, r in users])
    cur.executemany("INSERT INTO route VALUES (?,?,?)", [(f"RT{r}", f"Route {r}", f"U-SUP{r}") for r in (1, 2, 3)])
    societies = []
    for i in range(1, 13):
        s, route = f"S{i:02d}", f"RT{(i - 1) // 4 + 1}"
        societies.append((s, route))
        cur.execute("INSERT INTO society VALUES (?,?,?,?,1)", (s, f"{s} Dairy Cooperative Society", f"Village {i:02d}", route))
        cur.execute("INSERT INTO app_user VALUES (?,?,?,?,?,1)", (f"U-OP{i:02d}", f"Society Operator {s}", "SocietyOperator", sha("demo|" + s), s))
        for kind, code in (("CollectionUnit", "CU"), ("CoolerSensor", "TS"), ("EdgeGateway", "EG")):
            cur.execute("INSERT INTO device VALUES (?,?,?,?,?,'Active',NULL)",
                        (f"{code}-{s}", s, kind, f"SN-{code}-{1000 + i}", sha(f"key|{code}|{s}")[:16]))
        cur.execute("INSERT INTO bulk_milk_cooler VALUES (?,?,?,?)", (f"BMC-{s}", s, 1000, f"TS-{s}"))
        for m in range(1, 21):
            cur.execute("INSERT INTO member VALUES (?,?,?,?,?,1)",
                        (f"{s}-{m:03d}", s, f"Member {s}-{m:03d}", f"90000{i:02d}{m:03d}", f"XXXXXX{rnd.randint(1000, 9999)}"))
    # two rate charts for mixed milk: the second supersedes the first on day 16 (+2%)
    for chart, day, factor in ((1, 0, 1.00), (2, 15, 1.02)):
        cur.execute("INSERT INTO rate_chart VALUES (?,?,?, 'Draft')", (chart, "Mixed", (START + timedelta(days=day)).strftime("%Y-%m-%d")))
        for f in range(10):
            for n in range(3):
                fat, snf = 3.0 + 0.5 * f, 8.0 + 0.5 * n
                cur.execute("INSERT INTO rate_chart_line VALUES (?,?,?,?,?,?)",
                            (chart, fat, fat + 0.5, snf, snf + 0.5, round((5.6 * (fat + 0.25) + 2.0 * (snf + 0.25)) * factor, 2)))
        cur.execute("UPDATE rate_chart SET status = 'Approved' WHERE chart_id = ?", (chart,))
    cur.execute("UPDATE rate_chart SET status = 'Superseded' WHERE chart_id = 1")
    return societies


class Society:
    """Simulates one society, its cooler and its exception cases, step by step."""

    def __init__(self, cur, rnd, code, route, dock_queue, trips):
        self.cur, self.rnd, self.code, self.route = cur, rnd, code, route
        self.p = {**DEFAULT, **PROFILE.get(code, {})}
        self.dock_queue, self.trips = dock_queue, trips
        self.offset = timedelta(minutes=5 * rnd.randint(-3, 3))
        self.pickup_hour = 11.0 + 0.5 * int(route[2]) + rnd.choice([0, 0.25, 0.5])
        self.temp, self.qty, self.power = 30.0, 0.0, True
        self.lot = self.mon = self.shift = self.case = None
        self.pending, self.outage_until, self.gap_until = [], None, None
        self.lot_shifts, self.last_reading_id = 0, None
        self.members = [f"{code}-{m:03d}" for m in range(1, 21)]
        self.member_base = {m: (rnd.lognormvariate(1.9, 0.35), rnd.gauss(4.6, 0.45), rnd.gauss(8.6, 0.18)) for m in self.members}

    # ---- helpers
    def lot_status(self, status):
        self.cur.execute("UPDATE tank_lot SET status = ? WHERE lot_id = ?", (status, self.lot))   # checked by trg_lot_transition

    def notify(self, case_id, user, purpose, now, entry=None):
        self.cur.execute("INSERT INTO notification (case_id, entry_id, channel, recipient, purpose, queued_at, status) VALUES (?,?,?,?,?,?,?)",
                         (case_id, entry, "App" if case_id else "SMS", user, purpose, ts(now), "Sent"))

    def audit(self, now, user, action, otype, oid):
        self.cur.execute("INSERT INTO audit_event (event_at, user_id, action, object_type, object_id) VALUES (?,?,?,?,?)",
                         (ts(now), user, action, otype, str(oid)))

    # ---- collection
    def open_shift(self, now, code):
        rnd, day = self.rnd, now.strftime("%Y-%m-%d")
        if self.lot is None:
            self.cur.execute("INSERT INTO tank_lot (bmc_code, opened_at) VALUES (?,?)", (f"BMC-{self.code}", ts(now)))
            self.lot, self.mon, self.lot_shifts, self.temp, self.qty = self.cur.lastrowid, LotMonitor(CFG), 0, 30.0, 0.0
        elif self.mon.shift_opened(now):
            self.lot_status("Chilling")                                                   # LT04
        self.lot_shifts += 1
        assert self.lot_shifts <= 2, "a lot pools at most two shifts"
        self.cur.execute("INSERT INTO collection_shift (society_code, lot_id, shift_date, shift_code, opened_at) VALUES (?,?,?,?,?)",
                         (self.code, self.lot, day, code, ts(now)))
        chart = 2 if now >= START + timedelta(days=15) else 1
        entries = []
        for m in self.members:
            if rnd.random() > 0.85:
                continue
            q0, f0, s0 = self.member_base[m]
            fat = min(7.9, max(3.0, round(rnd.gauss(f0, 0.25), 1)))
            snf = min(9.4, max(8.0, round(rnd.gauss(s0, 0.12), 1)))
            rate = self.cur.execute("SELECT rate_per_kg FROM rate_chart_line WHERE chart_id = ? AND ? >= fat_from AND ? < fat_to "
                                    "AND ? >= snf_from AND ? < snf_to", (chart, fat, fat, snf, snf)).fetchone()[0]   # FR-02
            qty = round(max(1.0, rnd.gauss(q0, 0.8)), 2)
            manual = rnd.random() < self.p["manual_rate"]
            amount = float((Decimal(str(qty)) * Decimal(str(rate))).quantize(Decimal("0.01"), ROUND_HALF_UP))
            entries.append(dict(member=m, qty=qty, fat=fat, snf=snf, rate=rate, amount=amount, chart=chart,
                                manual=manual, at=now + timedelta(seconds=rnd.randint(60, 85 * 60))))
        entries.sort(key=lambda e: e["at"])
        self.shift = dict(id=self.cur.lastrowid, code=code, day=day, entries=entries, close=now + timedelta(minutes=90), poured=0)

    def seal_shift(self, now):
        sh, rnd, cur = self.shift, self.rnd, self.cur
        prev = sha(f"{self.code}|{sh['day']}|{sh['code']}")                                 # genesis value of the chain
        delay = rnd.choice([2, 3, 5, 8]) if rnd.random() > 0.06 else rnd.randint(90, 600)   # occasional long outage of the link
        synced = now + timedelta(minutes=delay)
        for n, e in enumerate(sh["entries"]):
            e["entry_id"] = str(uuid.uuid5(uuid.NAMESPACE_URL, f"c2d|{self.code}|{sh['day']}|{sh['code']}|{n}"))
            h = entry_hash(prev, e)
            cur.execute("INSERT INTO collection_entry VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                        (e["entry_id"], sh["id"], e["member"], e["chart"], e["qty"], e["fat"], e["snf"], e["rate"], e["amount"],
                         "Manual" if e["manual"] else "Device",
                         rnd.choice(["Analyser fault", "Scale not responding", "Power failure at collection unit"]) if e["manual"] else None,
                         None if e["manual"] else f"CU-{self.code}", ts(e["at"]), None, prev, h))
            self.notify(None, e["member"], "CollectionSlip", e["at"], entry=e["entry_id"])
            prev = h
        if rnd.random() < 0.03:                                                             # a few messages fail (FR-04)
            cur.execute("UPDATE notification SET status = 'Failed' WHERE notification_id = ?", (cur.lastrowid,))
        cur.execute("UPDATE collection_shift SET status = 'Sealed', sealed_at = ?, ledger_hash = ? WHERE shift_id = ?", (ts(now), prev, sh["id"]))
        if synced < END:                                                                    # FR-06: synchronised later, capture time unchanged
            cur.execute("UPDATE collection_entry SET synced_at = ? WHERE shift_id = ?", (ts(synced), sh["id"]))
            cur.execute("UPDATE collection_shift SET status = 'Synced' WHERE shift_id = ?", (sh["id"],))
        cur.execute("UPDATE tank_lot SET sealed_at = ?, quantity_kg = (SELECT round(sum(quantity_kg), 2) FROM collection_entry e "
                    "JOIN collection_shift s ON s.shift_id = e.shift_id WHERE s.lot_id = ?) WHERE lot_id = ?", (ts(now), self.lot, self.lot))
        self.audit(now, f"U-OP{self.code[1:]}", "SealShift", "CollectionShift", sh["id"])
        if self.mon.shift_sealed(now):
            self.lot_status("Chilling")                                                   # LT02
        self.shift = None

    # ---- exception cases (FR-09 to FR-11)
    def raise_case(self, now, rule):
        cur = self.cur
        cur.execute("INSERT INTO exception_case (lot_id, case_type, raised_at, rule_code, reading_id, peak_temp_c, minutes_over_limit) "
                    "VALUES (?,?,?,?,?,?,0)", (self.lot, "Chilling", ts(now), rule, self.last_reading_id, round(self.temp, 1)))
        cid = cur.lastrowid
        self.lot_status("AtRisk")                                                         # LT05 / LT06
        sup = f"U-SUP{self.route[2]}"
        self.notify(cid, f"U-OP{self.code[1:]}", "ChillingAlert", now); self.notify(cid, sup, "ChillingAlert", now)
        ack = now + timedelta(minutes=max(1, round(self.rnd.lognormvariate(math.log(self.p["ack_median"]), 0.7))))
        self.case = dict(id=cid, rule=rule, raised=now, ack_at=ack, acked=False, escalated=False, peak=self.temp,
                         decide_after=ack + timedelta(minutes=self.rnd.randint(10, 60)), sup=sup)

    def step_case(self, now, sensor_ok):
        c, cur, op = self.case, self.cur, f"U-OP{self.code[1:]}"
        c["peak"] = max(c["peak"], self.temp)
        if not c["acked"] and not c["escalated"] and now >= c["raised"] + timedelta(minutes=ACK_LIMIT):
            c["escalated"] = True
            cur.execute("UPDATE exception_case SET status = 'Escalated' WHERE case_id = ?", (c["id"],))
            cur.execute("INSERT INTO case_action (case_id, action_at, action_type, remarks) VALUES (?,?, 'Escalate', 'No acknowledgement within the limit')", (c["id"], ts(now)))
            self.notify(c["id"], c["sup"], "Escalation", now)
        if not c["acked"] and now >= c["ack_at"]:
            c["acked"] = True
            cur.execute("UPDATE exception_case SET status = 'Acknowledged', acknowledged_at = ? WHERE case_id = ?", (ts(now), c["id"]))
            note = self.rnd.choice(["Generator started", "Technician called", "Compressor reset", "Lid closed and agitator checked"])
            cur.execute("INSERT INTO case_action (case_id, action_at, action_type, remarks, acted_by) VALUES (?,?, 'Acknowledge', ?, ?)", (c["id"], ts(now), note, op))
        if not c["acked"] or now < c["decide_after"]:
            return
        minutes = int((now - c["raised"]).total_seconds() // 60)
        to_pickup = (self.pickup_due(now) - now).total_seconds() / 60
        if c["peak"] >= 16 or minutes >= 300:
            disp = "Reject"
        elif self.temp <= 5 and sensor_ok:
            disp = "Release"
        elif c["rule"] != "R3_SensorSilence" and -30 <= to_pickup <= 90 and self.temp <= 9 and self.rnd.random() < 0.5:
            disp = "EarlyPickup"
        elif minutes >= 150 or c["peak"] >= 10 or now.hour >= 15:
            disp = "HoldForDockTest"
        else:
            return                                                                         # supervisor waits for the lot to recover
        cur.execute("UPDATE exception_case SET status = 'Decided', decided_at = ?, disposition = ?, peak_temp_c = ?, minutes_over_limit = ? "
                    "WHERE case_id = ?", (ts(now), disp, round(c["peak"], 1), minutes, c["id"]))
        cur.execute("INSERT INTO case_action (case_id, action_at, action_type, remarks, acted_by) VALUES (?,?, 'Decide', ?, ?)",
                    (c["id"], ts(now), f"{disp}; peak {c['peak']:.1f} C, {minutes} min", c["sup"]))
        self.audit(now, c["sup"], "Decide" + disp, "ExceptionCase", c["id"])
        if disp == "EarlyPickup":
            self.pickup(now, held_peak=c["peak"])                                         # LT10
        else:
            self.lot_status(self.mon.decided(disp))                                       # LT07, LT08 or LT09
        cur.execute("UPDATE exception_case SET status = 'Closed', closed_at = ? WHERE case_id = ?", (ts(now), c["id"]))
        cur.execute("INSERT INTO case_action (case_id, action_at, action_type, acted_by) VALUES (?,?, 'Close', ?)", (c["id"], ts(now), c["sup"]))
        self.held_peak = c["peak"] if disp == "HoldForDockTest" else None
        self.case = None
        if disp == "Reject":                                                               # milk discarded at the society
            self.lot = self.mon = None; self.qty = 0.0

    # ---- dispatch (FR-12)
    def pickup_due(self, now):
        return now.replace(hour=int(self.pickup_hour), minute=int(self.pickup_hour % 1 * 60), second=0)

    def pickup(self, now, held_peak=None):
        cur, rnd, key = self.cur, self.rnd, (self.route, now.strftime("%Y-%m-%d"))
        if key not in self.trips:
            cur.execute("INSERT INTO tanker_trip (trip_date, vehicle_no, driver_name) VALUES (?,?,?)",
                        (key[1], f"TANKER-{self.route[2]}", f"Driver {self.route[2]}{rnd.choice('AB')}"))
            self.trips[key] = cur.lastrowid
        ledger = cur.execute("SELECT quantity_kg FROM tank_lot WHERE lot_id = ?", (self.lot,)).fetchone()[0]
        qty = round(ledger * (1 + self.p["pickup_bias"] + rnd.gauss(0, 0.0012)), 1)
        cur.execute("INSERT INTO pickup_record (trip_id, lot_id, picked_at, quantity_kg, milk_temp_c, seal_no, driver_confirmed) VALUES (?,?,?,?,?,?,1)",
                    (self.trips[key], self.lot, ts(now), qty, round(self.temp, 1), f"SL{rnd.randint(100000, 999999)}"))
        self.lot_status("Dispatched")                                                     # LT10, LT11 or LT12
        self.dock_queue.append(dict(pickup=cur.lastrowid, lot=self.lot, soc=self.code, route=self.route, ledger=ledger, qty=qty,
                                    at=now + timedelta(minutes=rnd.randint(90, 180)), temp=self.temp,
                                    held_peak=held_peak if held_peak is not None else getattr(self, "held_peak", None),
                                    fat_bias=self.p["fat_bias"]))
        self.lot = self.mon = None; self.qty = 0.0; self.held_peak = None

    # ---- one 5-minute step
    def step(self, now):
        rnd, p, t = self.rnd, self.p, now - self.offset
        if now.hour == 0 and now.minute == 0:                                             # plan today's power cut and sensor gap
            self.outage = (now + timedelta(minutes=rnd.randint(0, 1380)), rnd.randint(*p["outage_minutes"])) if rnd.random() < p["outage_p"] else None
            self.gap = (now + timedelta(minutes=rnd.randint(480, 1380)), rnd.randint(25, 90)) if rnd.random() < p["gap_p"] else None
        self.power = not (self.outage and self.outage[0] <= now < self.outage[0] + timedelta(minutes=self.outage[1]))
        sensor_ok = not (self.gap and self.gap[0] <= now < self.gap[0] + timedelta(minutes=self.gap[1]))
        if self.shift is None and (t.hour, t.minute) in ((6, 0), (17, 0)):
            self.open_shift(now, "Morning" if t.hour == 6 else "Evening")
        if self.shift:                                                                     # warm milk (35 C) is poured into the tank
            due = [e for e in self.shift["entries"][self.shift["poured"]:] if e["at"] <= now]
            for e in due:
                self.temp = (self.temp * self.qty + 35.0 * e["qty"]) / (self.qty + e["qty"]); self.qty += e["qty"]
            self.shift["poured"] += len(due)
            if now >= self.shift["close"]:
                self.seal_shift(now)
        if self.lot is None:
            return
        day = (now - START).days + 1
        k = 0.55 if p["fault_days"] and p["fault_days"][0] <= day <= p["fault_days"][1] else 1.5
        self.temp = 3.2 + (self.temp - 3.2) * math.exp(-k / 12) if self.power else self.temp + WARM_RATE / 12
        if sensor_ok:                                                                      # FR-07
            self.cur.execute("INSERT INTO temperature_reading (bmc_code, read_at, milk_temp_c, power_on, synced_at) VALUES (?,?,?,?,?)",
                             (f"BMC-{self.code}", ts(now), round(self.temp + rnd.gauss(0, 0.05), 2), int(self.power), ts(now + timedelta(minutes=5))))
            self.last_reading_id = self.cur.lastrowid
            event = self.mon.reading(now, self.temp)
        else:
            event = None
        event = event or self.mon.tick(now)
        if event == "Chilled":
            self.lot_status("Chilled")                                                    # LT03
        elif event:
            self.raise_case(now, event)
        if self.case:
            self.step_case(now, sensor_ok)
        if self.lot and self.shift is None and now >= self.pickup_due(now) and now.hour < 16 and self.mon.status in ("Chilled", "Held"):
            self.pickup(now)


def dock_and_reconcile(cur, rnd, queue):
    """Dock receipt (FR-13), reconciliation (FR-14) and variance resolution (FR-15)."""
    for d in sorted(queue, key=lambda x: x["at"]):
        if d["at"] >= END:
            continue                                                                       # still on the road at the end of the period
        spill = rnd.uniform(0.01, 0.03) if rnd.random() < 0.02 else 0.0
        dock_qty = round(d["ledger"] * (1 - 0.0012 + rnd.gauss(0, 0.0012) - spill), 1)
        fat_l, snf_l = cur.execute("SELECT ledger_fat_pct, ledger_snf_pct FROM v_lot_ledger WHERE lot_id = ?", (d["lot"],)).fetchone()
        fat, snf = round(fat_l + rnd.gauss(d["fat_bias"], 0.03), 2), round(snf_l + rnd.gauss(-0.03, 0.05), 2)
        hp = d["held_peak"]
        decision = "Accepted"
        if hp is not None:
            decision = "Rejected" if hp >= 11 and rnd.random() < 0.5 else rnd.choice(["Accepted", "Downgraded"])
        elif rnd.random() < 0.005:
            decision = "Downgraded"
        cur.execute("INSERT INTO dock_receipt (pickup_id, received_at, quantity_kg, fat_pct, snf_pct, milk_temp_c, decision, remarks) VALUES (?,?,?,?,?,?,?,?)",
                    (d["pickup"], ts(d["at"]), dock_qty, fat, snf, round(d["temp"] + rnd.uniform(0.3, 1.2), 1), decision,
                     "Sour on COB test" if decision == "Rejected" else None))
        rid = cur.lastrowid
        cur.execute("INSERT INTO audit_event (event_at, user_id, action, object_type, object_id) VALUES (?, 'U-DOCK', 'RecordReceipt', 'DockReceipt', ?)", (ts(d["at"]), str(rid)))
        qv, fv, sv = cur.execute("SELECT quantity_variance_pct, fat_variance, snf_variance FROM v_reconciliation WHERE lot_id = ?", (d["lot"],)).fetchone()
        breach = abs(qv) > TOL_QTY or abs(fv) > TOL_FAT or abs(sv) > TOL_SNF
        if decision == "Rejected":
            cur.execute("UPDATE tank_lot SET status = 'Rejected' WHERE lot_id = ?", (d["lot"],))          # LT14
        else:
            cur.execute("UPDATE tank_lot SET status = 'Received' WHERE lot_id = ?", (d["lot"],))          # LT13
            cur.execute("UPDATE tank_lot SET status = ? WHERE lot_id = ?", ("UnderReview" if breach else "Reconciled", d["lot"]))  # LT16 / LT15
        if not (breach or decision == "Rejected"):
            continue
        cur.execute("INSERT INTO exception_case (lot_id, case_type, raised_at, receipt_id, quantity_variance_pct, fat_variance, snf_variance) "
                    "VALUES (?, 'Variance', ?, ?, ?, ?, ?)", (d["lot"], ts(d["at"]), rid, qv, fv, sv))
        cid, sup, op = cur.lastrowid, f"U-SUP{d['route'][2]}", f"U-OP{d['soc'][1:]}"
        for user in (op, sup):
            cur.execute("INSERT INTO notification (case_id, channel, recipient, purpose, queued_at, status) VALUES (?, 'App', ?, 'VarianceAlert', ?, 'Sent')", (cid, user, ts(d["at"])))
        ack = d["at"] + timedelta(minutes=rnd.randint(5, 240))
        done = ack + timedelta(hours=rnd.uniform(3, 70))
        if ack < END:
            cur.execute("UPDATE exception_case SET status = 'Acknowledged', acknowledged_at = ? WHERE case_id = ?", (ts(ack), cid))
            cur.execute("INSERT INTO case_action (case_id, action_at, action_type, remarks, acted_by) VALUES (?,?, 'Acknowledge', 'Society figures rechecked', ?)", (cid, ts(ack), op))
        if done < END:                                                                     # otherwise the case is still open at period end
            if decision == "Rejected":
                resp = "Society"
            elif abs(fv) > TOL_FAT or abs(sv) > TOL_SNF:
                resp = "Society"
            elif spill:
                resp = "Transporter"
            else:
                resp = "Society" if abs(qv) > 0.8 else "MeasurementTolerance"
            cur.execute("UPDATE exception_case SET status = 'Decided', decided_at = ?, disposition = 'ResponsibilityAllocated', responsibility = ? WHERE case_id = ?", (ts(done), resp, cid))
            cur.execute("INSERT INTO case_action (case_id, action_at, action_type, remarks, acted_by) VALUES (?,?, 'Decide', ?, ?)", (cid, ts(done), "Responsibility: " + resp, sup))
            cur.execute("UPDATE exception_case SET status = 'Closed', closed_at = ? WHERE case_id = ?", (ts(done), cid))
            cur.execute("INSERT INTO case_action (case_id, action_at, action_type, acted_by) VALUES (?,?, 'Close', ?)", (cid, ts(done), sup))
            cur.execute("INSERT INTO audit_event (event_at, user_id, action, object_type, object_id) VALUES (?,?, 'ResolveVariance', 'ExceptionCase', ?)", (ts(done), sup, str(cid)))
            if decision != "Rejected":
                cur.execute("UPDATE tank_lot SET status = 'Reconciled' WHERE lot_id = ?", (d["lot"],))    # LT17


def payment_cycles(cur):
    """FR-16: statements for the first two ten-day cycles; the third is still open."""
    for n, status in ((0, "Exported"), (1, "Approved"), (2, "Open")):
        a, b = (START + timedelta(days=10 * n)).strftime("%Y-%m-%d"), (START + timedelta(days=10 * n + 9)).strftime("%Y-%m-%d")
        cur.execute("INSERT INTO payment_cycle (from_date, to_date) VALUES (?,?)", (a, b))
        cid = cur.lastrowid
        if status == "Open":
            continue
        cur.execute("INSERT INTO payment_statement (cycle_id, member_code, total_quantity_kg, gross_amount, net_amount, status) "
                    "SELECT ?, e.member_code, round(sum(e.quantity_kg), 2), round(sum(e.amount), 2), round(sum(e.amount), 2), 'Approved' "
                    "FROM collection_entry e JOIN collection_shift s ON s.shift_id = e.shift_id "
                    "WHERE s.status <> 'Open' AND s.shift_date BETWEEN ? AND ? GROUP BY e.member_code", (cid, a, b))
        cur.execute("UPDATE payment_cycle SET status = 'Approved' WHERE cycle_id = ?", (cid,))            # checked by trg_cycle_needs_sealed_shifts
        if status == "Exported":
            cur.execute("UPDATE payment_cycle SET status = 'Exported' WHERE cycle_id = ?", (cid,))
        cur.execute("INSERT INTO audit_event (event_at, user_id, action, object_type, object_id) VALUES (?, 'U-ACC', 'ApproveCycle', 'PaymentCycle', ?)", (b + " 18:00:00", str(cid)))


def main(path):
    Path(path).unlink(missing_ok=True)
    con = sqlite3.connect(path)
    con.executescript((Path(__file__).parent / "schema.sql").read_text(encoding="utf-8"))
    con.execute("PRAGMA foreign_keys = ON")
    cur, rnd = con.cursor(), random.Random(SEED)
    societies = master_data(cur, rnd)
    queue, trips = [], {}
    for code, route in societies:
        sim, now = Society(cur, rnd, code, route, queue, trips), START
        while now < END:
            sim.step(now); now += STEP
    dock_and_reconcile(cur, rnd, queue)
    payment_cycles(cur)
    con.commit()
    assert not con.execute("PRAGMA foreign_key_check").fetchall(), "foreign key violation"
    for t in ("society", "member", "collection_shift", "collection_entry", "temperature_reading", "tank_lot", "pickup_record",
              "dock_receipt", "exception_case", "case_action", "notification", "payment_statement", "audit_event"):
        print(f"{t:22s}{con.execute(f'SELECT count(*) FROM {t}').fetchone()[0]:>8d}")
    con.execute("VACUUM"); con.close()


if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else "c2d_prototype.sqlite")
