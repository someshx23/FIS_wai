-- ============================================================================
-- C2D (Collection-to-Dock) system: relational schema for the SQLite prototype
-- ----------------------------------------------------------------------------
-- One table per persistent class of the UML domain model, with three
-- documented differences (see docs/class_to_table_mapping.md):
--   * ExceptionCase, ChillingException and VarianceException are stored in ONE
--     table (exception_case) with a discriminator column: single-table
--     inheritance. CHECK constraints keep each subtype's columns consistent.
--   * lot_transition holds the transitions of state machine STM-01 as data;
--     a trigger refuses any tank_lot status change that is not in it (FR-11).
--   * config holds thresholds and tolerances so that they can be changed
--     without a software change (NFR-10).
-- Dates and times are ISO-8601 text. SQLite REAL is used for quantities and
-- money in this prototype; a production RDBMS would use DECIMAL.
-- ============================================================================
PRAGMA foreign_keys = ON;

CREATE TABLE app_user (
    user_id        TEXT PRIMARY KEY,
    full_name      TEXT NOT NULL,
    role           TEXT NOT NULL CHECK (role IN ('SocietyOperator','RouteSupervisor','DockOfficer','AccountsOfficer','SystemAdministrator')),
    password_hash  TEXT NOT NULL,
    society_code   TEXT REFERENCES society(society_code),        -- set for society operators only
    active         INTEGER NOT NULL DEFAULT 1 CHECK (active IN (0,1)),
    CHECK ((role = 'SocietyOperator') = (society_code IS NOT NULL))
);

CREATE TABLE route (
    route_code          TEXT PRIMARY KEY,
    name                TEXT NOT NULL,
    supervisor_user_id  TEXT NOT NULL REFERENCES app_user(user_id)
);

CREATE TABLE society (
    society_code  TEXT PRIMARY KEY,
    name          TEXT NOT NULL,
    village       TEXT NOT NULL,
    route_code    TEXT NOT NULL REFERENCES route(route_code),
    active        INTEGER NOT NULL DEFAULT 1 CHECK (active IN (0,1))
);

CREATE TABLE member (
    member_code       TEXT PRIMARY KEY,
    society_code      TEXT NOT NULL REFERENCES society(society_code),
    name              TEXT NOT NULL,
    mobile            TEXT,                                       -- personal data (NFR-08)
    bank_account_ref  TEXT,                                       -- personal data (NFR-08)
    active            INTEGER NOT NULL DEFAULT 1 CHECK (active IN (0,1))
);

CREATE TABLE device (
    device_id        TEXT PRIMARY KEY,
    society_code     TEXT NOT NULL REFERENCES society(society_code),
    device_type      TEXT NOT NULL CHECK (device_type IN ('CollectionUnit','CoolerSensor','EdgeGateway')),
    serial_no        TEXT NOT NULL UNIQUE,
    key_fingerprint  TEXT NOT NULL,
    status           TEXT NOT NULL DEFAULT 'Active' CHECK (status IN ('Active','Inactive')),
    last_seen_at     TEXT
);

CREATE TABLE bulk_milk_cooler (
    bmc_code          TEXT PRIMARY KEY,
    society_code      TEXT NOT NULL REFERENCES society(society_code),
    capacity_litres   INTEGER NOT NULL CHECK (capacity_litres > 0),
    sensor_device_id  TEXT UNIQUE REFERENCES device(device_id)
);

CREATE TABLE rate_chart (
    chart_id        INTEGER PRIMARY KEY,
    milk_type       TEXT NOT NULL CHECK (milk_type IN ('Cow','Buffalo','Mixed')),
    effective_from  TEXT NOT NULL,
    status          TEXT NOT NULL DEFAULT 'Draft' CHECK (status IN ('Draft','Approved','Superseded')),
    UNIQUE (milk_type, effective_from)                            -- FR-17
);

CREATE TABLE rate_chart_line (
    chart_id     INTEGER NOT NULL REFERENCES rate_chart(chart_id),
    fat_from     REAL NOT NULL,
    fat_to       REAL NOT NULL,
    snf_from     REAL NOT NULL,
    snf_to       REAL NOT NULL,
    rate_per_kg  REAL NOT NULL CHECK (rate_per_kg > 0),
    PRIMARY KEY (chart_id, fat_from, snf_from),
    CHECK (fat_from < fat_to AND snf_from < snf_to)
);

CREATE TABLE tank_lot (
    lot_id       INTEGER PRIMARY KEY,
    bmc_code     TEXT NOT NULL REFERENCES bulk_milk_cooler(bmc_code),
    opened_at    TEXT NOT NULL,
    sealed_at    TEXT,                                            -- time the latest pooled shift was sealed
    status       TEXT NOT NULL DEFAULT 'Open'
                 CHECK (status IN ('Open','Chilling','Chilled','AtRisk','Held','Dispatched','Received','UnderReview','Reconciled','Rejected')),
    quantity_kg  REAL NOT NULL DEFAULT 0 CHECK (quantity_kg >= 0)
);

CREATE TABLE lot_transition (                                      -- state machine STM-01 as data
    from_status  TEXT NOT NULL,
    to_status    TEXT NOT NULL,
    transition   TEXT NOT NULL,                                   -- model key, e.g. LT05
    PRIMARY KEY (from_status, to_status)
);

CREATE TABLE collection_shift (
    shift_id      INTEGER PRIMARY KEY,
    society_code  TEXT NOT NULL REFERENCES society(society_code),
    lot_id        INTEGER REFERENCES tank_lot(lot_id),
    shift_date    TEXT NOT NULL,
    shift_code    TEXT NOT NULL CHECK (shift_code IN ('Morning','Evening')),
    status        TEXT NOT NULL DEFAULT 'Open' CHECK (status IN ('Open','Sealed','Synced')),
    opened_at     TEXT NOT NULL,
    sealed_at     TEXT,
    ledger_hash   TEXT,
    UNIQUE (society_code, shift_date, shift_code),
    CHECK ((status = 'Open') = (ledger_hash IS NULL))             -- a sealed shift always carries its seal (FR-05)
);

CREATE TABLE collection_entry (
    entry_id       TEXT PRIMARY KEY,                              -- UUID assigned at the edge: makes synchronisation idempotent (FR-06)
    shift_id       INTEGER NOT NULL REFERENCES collection_shift(shift_id),
    member_code    TEXT NOT NULL REFERENCES member(member_code),
    chart_id       INTEGER NOT NULL REFERENCES rate_chart(chart_id),
    quantity_kg    REAL NOT NULL CHECK (quantity_kg > 0),
    fat_pct        REAL NOT NULL CHECK (fat_pct BETWEEN 0 AND 15),
    snf_pct        REAL NOT NULL CHECK (snf_pct BETWEEN 0 AND 15),
    rate_per_kg    REAL NOT NULL CHECK (rate_per_kg > 0),
    amount         REAL NOT NULL,
    capture_mode   TEXT NOT NULL CHECK (capture_mode IN ('Device','Manual')),
    manual_reason  TEXT,
    device_id      TEXT REFERENCES device(device_id),
    captured_at    TEXT NOT NULL,
    synced_at      TEXT,
    prev_hash      TEXT NOT NULL,
    entry_hash     TEXT NOT NULL UNIQUE,
    CHECK (abs(amount - quantity_kg * rate_per_kg) < 0.0051),                             -- FR-02: amount is rate x quantity to the paisa
    CHECK ((capture_mode = 'Device' AND device_id IS NOT NULL AND manual_reason IS NULL)
        OR (capture_mode = 'Manual' AND length(trim(coalesce(manual_reason, ''))) > 0)),   -- FR-01, FR-03
    CHECK (synced_at IS NULL OR synced_at >= captured_at)                                  -- FR-06
);
CREATE INDEX ix_entry_shift ON collection_entry(shift_id);
CREATE INDEX ix_entry_member ON collection_entry(member_code);

CREATE TABLE temperature_reading (
    reading_id   INTEGER PRIMARY KEY,
    bmc_code     TEXT NOT NULL REFERENCES bulk_milk_cooler(bmc_code),
    read_at      TEXT NOT NULL,
    milk_temp_c  REAL NOT NULL CHECK (milk_temp_c BETWEEN -5 AND 60),
    power_on     INTEGER NOT NULL CHECK (power_on IN (0,1)),
    synced_at    TEXT,
    UNIQUE (bmc_code, read_at)
);

CREATE TABLE tanker_trip (
    trip_id      INTEGER PRIMARY KEY,
    trip_date    TEXT NOT NULL,
    vehicle_no   TEXT NOT NULL,
    driver_name  TEXT NOT NULL
);

CREATE TABLE pickup_record (
    pickup_id         INTEGER PRIMARY KEY,
    trip_id           INTEGER NOT NULL REFERENCES tanker_trip(trip_id),
    lot_id            INTEGER NOT NULL UNIQUE REFERENCES tank_lot(lot_id),
    picked_at         TEXT NOT NULL,
    quantity_kg       REAL NOT NULL CHECK (quantity_kg > 0),
    milk_temp_c       REAL NOT NULL,
    seal_no           TEXT NOT NULL,
    driver_confirmed  INTEGER NOT NULL CHECK (driver_confirmed = 1)                         -- FR-12
);

CREATE TABLE dock_receipt (
    receipt_id   INTEGER PRIMARY KEY,
    pickup_id    INTEGER NOT NULL UNIQUE REFERENCES pickup_record(pickup_id),               -- FR-13: one receipt per pickup
    received_at  TEXT NOT NULL,
    quantity_kg  REAL NOT NULL CHECK (quantity_kg >= 0),
    fat_pct      REAL NOT NULL CHECK (fat_pct BETWEEN 0 AND 15),
    snf_pct      REAL NOT NULL CHECK (snf_pct BETWEEN 0 AND 15),
    milk_temp_c  REAL NOT NULL,
    decision     TEXT NOT NULL CHECK (decision IN ('Accepted','Downgraded','Rejected')),
    remarks      TEXT
);

CREATE TABLE exception_case (                                      -- ExceptionCase + both subclasses
    case_id                INTEGER PRIMARY KEY,
    lot_id                 INTEGER NOT NULL REFERENCES tank_lot(lot_id),
    case_type              TEXT NOT NULL CHECK (case_type IN ('Chilling','Variance')),     -- discriminator
    status                 TEXT NOT NULL DEFAULT 'Raised' CHECK (status IN ('Raised','Acknowledged','Escalated','Decided','Closed')),
    raised_at              TEXT NOT NULL,
    acknowledged_at        TEXT,
    decided_at             TEXT,
    closed_at              TEXT,
    disposition            TEXT CHECK (disposition IN ('Release','EarlyPickup','HoldForDockTest','Reject','ResponsibilityAllocated')),
    -- ChillingException
    rule_code              TEXT CHECK (rule_code IN ('R1_SlowChilling','R2_WarmHolding','R3_SensorSilence')),
    reading_id             INTEGER REFERENCES temperature_reading(reading_id),
    peak_temp_c            REAL,
    minutes_over_limit     INTEGER,
    -- VarianceException
    receipt_id             INTEGER UNIQUE REFERENCES dock_receipt(receipt_id),
    quantity_variance_pct  REAL,
    fat_variance           REAL,
    snf_variance           REAL,
    responsibility         TEXT CHECK (responsibility IN ('Society','Transporter','Plant','MeasurementTolerance')),
    CHECK ((case_type = 'Chilling' AND rule_code IS NOT NULL AND reading_id IS NOT NULL AND receipt_id IS NULL)
        OR (case_type = 'Variance' AND receipt_id IS NOT NULL AND rule_code IS NULL AND reading_id IS NULL)),
    CHECK (NOT (case_type = 'Variance' AND status = 'Closed' AND responsibility IS NULL)),   -- FR-15
    CHECK (status NOT IN ('Decided','Closed') OR disposition IS NOT NULL)
);
CREATE INDEX ix_case_lot ON exception_case(lot_id);

CREATE TABLE case_action (
    action_id    INTEGER PRIMARY KEY,
    case_id      INTEGER NOT NULL REFERENCES exception_case(case_id),
    action_at    TEXT NOT NULL,
    action_type  TEXT NOT NULL CHECK (action_type IN ('Acknowledge','Note','Escalate','Decide','Close')),
    remarks      TEXT,
    acted_by     TEXT REFERENCES app_user(user_id)                -- NULL only for the system's own escalation
);

CREATE TABLE notification (
    notification_id  INTEGER PRIMARY KEY,
    case_id          INTEGER REFERENCES exception_case(case_id),
    entry_id         TEXT REFERENCES collection_entry(entry_id),
    channel          TEXT NOT NULL CHECK (channel IN ('SMS','App')),
    recipient        TEXT NOT NULL,
    purpose          TEXT NOT NULL,
    queued_at        TEXT NOT NULL,
    status           TEXT NOT NULL DEFAULT 'Queued' CHECK (status IN ('Queued','Sent','Failed'))
);
CREATE INDEX ix_notification_entry ON notification(entry_id);
CREATE INDEX ix_notification_case ON notification(case_id);

CREATE TABLE payment_cycle (
    cycle_id   INTEGER PRIMARY KEY,
    from_date  TEXT NOT NULL UNIQUE,
    to_date    TEXT NOT NULL,
    status     TEXT NOT NULL DEFAULT 'Open' CHECK (status IN ('Open','Approved','Exported')),
    CHECK (to_date >= from_date)
);

CREATE TABLE payment_statement (
    statement_id       INTEGER PRIMARY KEY,
    cycle_id           INTEGER NOT NULL REFERENCES payment_cycle(cycle_id),
    member_code        TEXT NOT NULL REFERENCES member(member_code),
    total_quantity_kg  REAL NOT NULL,
    gross_amount       REAL NOT NULL,
    net_amount         REAL NOT NULL,
    status             TEXT NOT NULL DEFAULT 'Draft' CHECK (status IN ('Draft','Approved')),
    UNIQUE (cycle_id, member_code)
);

CREATE TABLE audit_event (
    event_id     INTEGER PRIMARY KEY,
    event_at     TEXT NOT NULL,
    user_id      TEXT REFERENCES app_user(user_id),
    action       TEXT NOT NULL,
    object_type  TEXT NOT NULL,
    object_id    TEXT NOT NULL
);

CREATE TABLE config (
    key          TEXT PRIMARY KEY,
    value        REAL NOT NULL,
    description  TEXT NOT NULL
);

-- ----------------------------------------------------------------------------
-- Triggers: business rules that a column constraint cannot express
-- ----------------------------------------------------------------------------
CREATE TRIGGER trg_entry_only_in_open_shift BEFORE INSERT ON collection_entry
WHEN (SELECT status FROM collection_shift WHERE shift_id = NEW.shift_id) <> 'Open'
BEGIN SELECT RAISE(ABORT, 'FR-05: the shift is sealed; no entry can be added'); END;

CREATE TRIGGER trg_sealed_entry_no_update BEFORE UPDATE ON collection_entry
WHEN (SELECT status FROM collection_shift WHERE shift_id = OLD.shift_id) <> 'Open'
 AND (NEW.quantity_kg IS NOT OLD.quantity_kg OR NEW.fat_pct IS NOT OLD.fat_pct OR NEW.snf_pct IS NOT OLD.snf_pct
   OR NEW.rate_per_kg IS NOT OLD.rate_per_kg OR NEW.amount IS NOT OLD.amount OR NEW.member_code IS NOT OLD.member_code
   OR NEW.capture_mode IS NOT OLD.capture_mode OR NEW.manual_reason IS NOT OLD.manual_reason
   OR NEW.captured_at IS NOT OLD.captured_at OR NEW.prev_hash IS NOT OLD.prev_hash OR NEW.entry_hash IS NOT OLD.entry_hash
   OR NEW.shift_id IS NOT OLD.shift_id OR NEW.entry_id IS NOT OLD.entry_id)
BEGIN SELECT RAISE(ABORT, 'FR-05: a sealed entry cannot be changed'); END;   -- only synced_at may still be set

CREATE TRIGGER trg_sealed_entry_no_delete BEFORE DELETE ON collection_entry
WHEN (SELECT status FROM collection_shift WHERE shift_id = OLD.shift_id) <> 'Open'
BEGIN SELECT RAISE(ABORT, 'FR-05: a sealed entry cannot be deleted'); END;

CREATE TRIGGER trg_lot_transition BEFORE UPDATE OF status ON tank_lot
WHEN NEW.status <> OLD.status
 AND NOT EXISTS (SELECT 1 FROM lot_transition WHERE from_status = OLD.status AND to_status = NEW.status)
BEGIN SELECT RAISE(ABORT, 'FR-11: not a valid transition of the tank lot state machine'); END;

CREATE TRIGGER trg_case_action_no_update BEFORE UPDATE ON case_action
BEGIN SELECT RAISE(ABORT, 'FR-10: logged actions cannot be edited'); END;

CREATE TRIGGER trg_case_action_no_delete BEFORE DELETE ON case_action
BEGIN SELECT RAISE(ABORT, 'FR-10: logged actions cannot be deleted'); END;

CREATE TRIGGER trg_chart_line_frozen_update BEFORE UPDATE ON rate_chart_line
WHEN (SELECT status FROM rate_chart WHERE chart_id = OLD.chart_id) <> 'Draft'
BEGIN SELECT RAISE(ABORT, 'FR-17: an approved rate chart cannot be edited'); END;

CREATE TRIGGER trg_chart_line_frozen_insert BEFORE INSERT ON rate_chart_line
WHEN (SELECT status FROM rate_chart WHERE chart_id = NEW.chart_id) <> 'Draft'
BEGIN SELECT RAISE(ABORT, 'FR-17: an approved rate chart cannot be edited'); END;

CREATE TRIGGER trg_cycle_needs_sealed_shifts BEFORE UPDATE OF status ON payment_cycle
WHEN NEW.status = 'Approved' AND OLD.status = 'Open'
 AND EXISTS (SELECT 1 FROM collection_shift WHERE status = 'Open' AND shift_date BETWEEN NEW.from_date AND NEW.to_date)
BEGIN SELECT RAISE(ABORT, 'FR-16: the cycle contains an unsealed shift'); END;

CREATE TRIGGER trg_reading_from_active_sensor BEFORE INSERT ON temperature_reading
WHEN coalesce((SELECT d.status FROM bulk_milk_cooler b JOIN device d ON d.device_id = b.sensor_device_id
               WHERE b.bmc_code = NEW.bmc_code), 'Missing') <> 'Active'
BEGIN SELECT RAISE(ABORT, 'FR-18: reading from an unregistered or inactive device'); END;

-- ----------------------------------------------------------------------------
-- Views used by the reports
-- ----------------------------------------------------------------------------
CREATE VIEW v_shift_totals AS
SELECT s.shift_id, s.society_code, s.lot_id, s.shift_date, s.shift_code, s.status,
       count(e.entry_id)                                         AS entries,
       round(sum(e.quantity_kg), 2)                              AS quantity_kg,
       round(sum(e.quantity_kg * e.fat_pct) / sum(e.quantity_kg), 3) AS fat_pct,
       round(sum(e.quantity_kg * e.snf_pct) / sum(e.quantity_kg), 3) AS snf_pct,
       round(sum(e.amount), 2)                                   AS amount,
       sum(e.capture_mode = 'Manual')                            AS manual_entries
FROM collection_shift s LEFT JOIN collection_entry e ON e.shift_id = s.shift_id
GROUP BY s.shift_id;

CREATE VIEW v_lot_ledger AS                                        -- what the society ledger says is in each lot
SELECT l.lot_id, l.bmc_code, b.society_code, so.route_code, l.status, l.opened_at, l.sealed_at,
       round(sum(e.quantity_kg), 2)                              AS ledger_kg,
       round(sum(e.quantity_kg * e.fat_pct) / sum(e.quantity_kg), 3) AS ledger_fat_pct,
       round(sum(e.quantity_kg * e.snf_pct) / sum(e.quantity_kg), 3) AS ledger_snf_pct
FROM tank_lot l
JOIN bulk_milk_cooler b ON b.bmc_code = l.bmc_code
JOIN society so ON so.society_code = b.society_code
JOIN collection_shift s ON s.lot_id = l.lot_id
JOIN collection_entry e ON e.shift_id = s.shift_id
GROUP BY l.lot_id;

CREATE VIEW v_reconciliation AS                                    -- FR-14
SELECT v.lot_id, v.society_code, v.route_code, date(p.picked_at) AS pickup_date,
       v.ledger_kg, p.quantity_kg AS pickup_kg, d.quantity_kg AS dock_kg, d.decision,
       round((d.quantity_kg - p.quantity_kg) * 100.0 / p.quantity_kg, 3) AS quantity_variance_pct,
       round(d.fat_pct - v.ledger_fat_pct, 3)                    AS fat_variance,
       round(d.snf_pct - v.ledger_snf_pct, 3)                    AS snf_variance
FROM v_lot_ledger v
JOIN pickup_record p ON p.lot_id = v.lot_id
JOIN dock_receipt d ON d.pickup_id = p.pickup_id;
