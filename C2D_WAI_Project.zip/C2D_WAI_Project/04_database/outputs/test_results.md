# Acceptance tests executed on the SQLite prototype (synthetic data)

| Test | Requirement | What is tested | Result | Evidence |
|---|---|---|---|---|
| T-02a | FR-02 | Amount equals rate x quantity for every entry | PASS | 12232 entries checked, 0 differ |
| T-02b | FR-02 | Rate comes from the band of the chart in force on the shift date | PASS | 12232 entries checked, 0 on a wrong chart or band |
| T-03a | FR-03 | Manual entry without a reason code is refused (in an open shift) | PASS | CHECK constraint failed: (capture_mode = 'Device' AND device_id IS NOT NULL AND manual_reason IS NULL)
        OR (capture_mode = 'Manual' AND length(trim(coalesce(manual_reason, ''))) > 0) |
| T-03b | FR-03 | Control: the same manual entry with a reason code is accepted | PASS | statement was accepted |
| T-04 | FR-04 | One notification record per saved entry | PASS | 12232 entries, 0 without a notification |
| T-05a | FR-05 | Update of a sealed entry is refused | PASS | FR-05: a sealed entry cannot be changed |
| T-05b | FR-05 | Delete of a sealed entry is refused | PASS | FR-05: a sealed entry cannot be deleted |
| T-05c | FR-05 | Insert into a sealed shift is refused | PASS | FR-05: the shift is sealed; no entry can be added |
| T-05d | FR-05, FR-19, NFR-03 | Hash chain of every sealed shift verifies | PASS | 720 shifts verified, 0 failed |
| T-05e | FR-19, NFR-03 | Out-of-band change to a sealed entry is detected and located | PASS | 200 of 200 single-field changes detected at the altered entry (on a copy) |
| T-06 | FR-06 | Synchronised entries keep capture time, sync later, no duplicate identifier (simulated link delays) | PASS | 12232 entries, 0 synced before capture, 0 duplicates |
| T-08 | FR-08 | Rule engine: one breach per episode, none when compliant (5 simulated series) | PASS | compliant chilling: ok; slow chilling: ok; warm holding: ok; short warm blip: ok; sensor silent 25 min: ok |
| T-09 | FR-09 | Every case has two alert notifications (operator and supervisor) | PASS | 102 cases, 0 without exactly two alerts |
| T-10a | FR-10 | Logged action cannot be edited | PASS | FR-10: logged actions cannot be edited |
| T-10b | FR-10 | Logged action cannot be deleted | PASS | FR-10: logged actions cannot be deleted |
| T-10c | FR-10 | Chilling cases unacknowledged at 15 minutes were escalated, and none earlier | PASS | 7 escalations, 0 early, 0 late acknowledgements not escalated |
| T-11a | FR-11 | Lot status change outside the state machine is refused (Reconciled to Open) | PASS | FR-11: not a valid transition of the tank lot state machine |
| T-11b | FR-11 | Lot status change outside the state machine is refused (Chilled to Received) | PASS | FR-11: not a valid transition of the tank lot state machine |
| T-11c | FR-11 | All simulated lots followed the state machine | PASS | 372 lots created and moved only through trigger-checked transitions; the generator would have aborted otherwise |
| T-12 | FR-12 | Pickup without driver confirmation is refused | PASS | CHECK constraint failed: driver_confirmed = 1 |
| T-13a | FR-13 | Second dock receipt for the same pickup is refused | PASS | UNIQUE constraint failed: dock_receipt.pickup_id |
| T-13b | FR-13 | Dock receipt without a decision is refused | PASS | NOT NULL constraint failed: dock_receipt.decision |
| T-14a | FR-14 | Quantity variance in the view equals an independent calculation | PASS | 357 lots compared, 0 differ |
| T-14b | FR-14 | A variance case exists if and only if a tolerance is exceeded or the lot is rejected | PASS | 357 received lots, 0 inconsistent |
| T-15 | FR-15 | Variance case cannot be closed without a responsibility | PASS | CHECK constraint failed: NOT (case_type = 'Variance' AND status = 'Closed' AND responsibility IS NULL) |
| T-16a | FR-16 | Each statement total equals the member's sealed entries in the cycle | PASS | 480 statements, 0 differ |
| T-16b | FR-16 | A cycle containing an unsealed shift cannot be approved | PASS | FR-16: the cycle contains an unsealed shift |
| T-17a | FR-17 | Line of an approved rate chart cannot be edited | PASS | FR-17: an approved rate chart cannot be edited |
| T-17b | FR-17 | Two charts for one milk type cannot share an effective date | PASS | UNIQUE constraint failed: rate_chart.milk_type, rate_chart.effective_from |
| T-18a | FR-18, NFR-02 | Reading from a deactivated sensor is refused | PASS | FR-18: reading from an unregistered or inactive device |
| T-18b | FR-18, NFR-01 | A user cannot be created with an unknown role | PASS | CHECK constraint failed: role IN ('SocietyOperator','RouteSupervisor','DockOfficer','AccountsOfficer','SystemAdministrator') |
| T-N9a | NFR-09 | Entry for an unknown member is refused (referential integrity) | PASS | FOREIGN KEY constraint failed |
| T-N9b | NFR-09 | Fat outside 0 to 15% is refused (range check) | PASS | CHECK constraint failed: fat_pct BETWEEN 0 AND 15 |
| T-N9c | NFR-09 | Temperature outside -5 to 60 C is refused (range check) | PASS | CHECK constraint failed: milk_temp_c BETWEEN -5 AND 60 |
