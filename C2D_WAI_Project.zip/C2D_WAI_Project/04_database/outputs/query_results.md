# Query results (synthetic data)

## Q1 Procurement by route and payment cycle

| route | cycle | from_date | to_date | cycle_status | members_pouring | quantity_kg | avg_fat_pct | avg_snf_pct | amount_rs | rs_per_kg |
|---|---|---|---|---|---|---|---|---|---|---|
| RT1 | 1 | 2026-09-01 | 2026-09-10 | Exported | 80 | 8896.0 | 4.61 | 8.6 | 386073.0 | 43.4 |
| RT1 | 2 | 2026-09-11 | 2026-09-20 | Approved | 80 | 8993.0 | 4.61 | 8.6 | 394564.0 | 43.87 |
| RT1 | 3 | 2026-09-21 | 2026-09-30 | Open | 80 | 8923.0 | 4.62 | 8.6 | 395535.0 | 44.33 |
| RT2 | 1 | 2026-09-01 | 2026-09-10 | Exported | 80 | 10080.0 | 4.57 | 8.63 | 436538.0 | 43.31 |
| RT2 | 2 | 2026-09-11 | 2026-09-20 | Approved | 80 | 9839.0 | 4.56 | 8.64 | 429878.0 | 43.69 |
| RT2 | 3 | 2026-09-21 | 2026-09-30 | Open | 80 | 10027.0 | 4.57 | 8.64 | 442928.0 | 44.18 |
| RT3 | 1 | 2026-09-01 | 2026-09-10 | Exported | 80 | 8968.0 | 4.6 | 8.59 | 388387.0 | 43.31 |
| RT3 | 2 | 2026-09-11 | 2026-09-20 | Approved | 80 | 9174.0 | 4.6 | 8.6 | 401132.0 | 43.73 |
| RT3 | 3 | 2026-09-21 | 2026-09-30 | Open | 80 | 9073.0 | 4.59 | 8.6 | 400818.0 | 44.18 |

## Q2 Chilling compliance by society

| society | route | lots | lots_with_chilling_case | pct_lots_compliant | r1_slow_chilling | r2_warm_holding | r3_sensor_silence |
|---|---|---|---|---|---|---|---|
| S05 | RT2 | 31 | 8 | 74.2 | 14 | 0 | 0 |
| S08 | RT2 | 31 | 6 | 80.6 | 5 | 1 | 0 |
| S02 | RT1 | 31 | 5 | 83.9 | 3 | 2 | 0 |
| S10 | RT3 | 31 | 2 | 93.5 | 0 | 0 | 2 |
| S03 | RT1 | 31 | 1 | 96.8 | 0 | 0 | 1 |
| S07 | RT2 | 31 | 1 | 96.8 | 0 | 0 | 1 |
| S12 | RT3 | 31 | 1 | 96.8 | 0 | 0 | 1 |
| S01 | RT1 | 31 | 0 | 100.0 | 0 | 0 | 0 |
| S04 | RT1 | 31 | 0 | 100.0 | 0 | 0 | 0 |
| S06 | RT2 | 31 | 0 | 100.0 | 0 | 0 | 0 |
| S09 | RT3 | 31 | 0 | 100.0 | 0 | 0 | 0 |
| S11 | RT3 | 31 | 0 | 100.0 | 0 | 0 | 0 |

## Q3 Pickup-to-dock variance by society

| society | route | lots_received | avg_quantity_variance_pct | net_kg_difference | lots_beyond_quantity_tolerance | avg_fat_variance | lots_beyond_fat_tolerance | lots_rejected_at_dock |
|---|---|---|---|---|---|---|---|---|
| S04 | RT1 | 30 | -1.28 | -81.0 | 30 | -0.016 | 0 | 0 |
| S07 | RT2 | 30 | -0.27 | -20.0 | 2 | -0.147 | 26 | 0 |
| S01 | RT1 | 30 | -0.26 | -16.0 | 3 | -0.029 | 1 | 0 |
| S02 | RT1 | 30 | -0.23 | -16.0 | 2 | -0.02 | 0 | 1 |
| S09 | RT3 | 30 | -0.2 | -12.0 | 1 | -0.014 | 0 | 0 |
| S03 | RT1 | 30 | -0.19 | -13.0 | 2 | -0.015 | 0 | 1 |
| S12 | RT3 | 30 | -0.18 | -12.0 | 3 | -0.023 | 0 | 0 |
| S06 | RT2 | 30 | -0.14 | -10.0 | 1 | -0.022 | 1 | 0 |
| S08 | RT2 | 27 | -0.1 | -8.0 | 0 | -0.019 | 0 | 0 |
| S10 | RT3 | 30 | -0.1 | -7.0 | 0 | -0.022 | 0 | 0 |
| S11 | RT3 | 30 | -0.1 | -7.0 | 0 | -0.022 | 0 | 0 |
| S05 | RT2 | 30 | -0.07 | -5.0 | 0 | -0.021 | 0 | 0 |

## Q4 Exception handling times by case type

| case_type | cases | still_open | escalated | avg_minutes_to_acknowledge | max_minutes_to_acknowledge | avg_hours_to_close |
|---|---|---|---|---|---|---|
| Chilling | 30 | 0 | 7 | 10.2 | 30.0 | 0.8 |
| Variance | 72 | 2 | 0 | 126.7 | 239.0 | 38.6 |

## Q5 Manual entries and quality variance by society

| society | entries | manual_entries | manual_pct | avg_fat_variance | lots_beyond_fat_tolerance |
|---|---|---|---|---|---|
| S07 | 1017 | 99 | 9.7 | -0.147 | 26 |
| S11 | 1023 | 62 | 6.1 | -0.022 | 0 |
| S06 | 1016 | 20 | 2.0 | -0.022 | 1 |
| S01 | 1029 | 19 | 1.8 | -0.029 | 1 |
| S05 | 1014 | 18 | 1.8 | -0.021 | 0 |
| S12 | 1021 | 17 | 1.7 | -0.023 | 0 |
| S03 | 1021 | 16 | 1.6 | -0.015 | 0 |
| S09 | 999 | 16 | 1.6 | -0.014 | 0 |
| S08 | 1037 | 16 | 1.5 | -0.019 | 0 |
| S02 | 998 | 14 | 1.4 | -0.02 | 0 |
| S10 | 1029 | 13 | 1.3 | -0.022 | 0 |
| S04 | 1028 | 12 | 1.2 | -0.016 | 0 |

## Q6 Payment statement check for cycle 2 (statement total against the sealed ledger)

| member_code | statement_kg | statement_rs | ledger_kg | ledger_rs | result |
|---|---|---|---|---|---|
| S08-001 | 420.21 | 18338.77 | 420.21 | 18338.77 | match |
| S11-001 | 308.81 | 13154.2 | 308.81 | 13154.2 | match |
| S05-011 | 244.22 | 11747.1 | 244.22 | 11747.1 | match |
| S07-010 | 254.09 | 11543.16 | 254.09 | 11543.16 | match |
| S04-006 | 232.23 | 10098.89 | 232.23 | 10098.89 | match |
| S09-008 | 227.49 | 9945.51 | 227.49 | 9945.51 | match |
| S03-015 | 235.19 | 9799.24 | 235.19 | 9799.24 | match |
| S08-003 | 215.81 | 9455.65 | 215.81 | 9455.65 | match |

## Q7 Time taken to reach 4 C after a shift is sealed, by society

| society | shifts | avg_hours_to_target | max_hours_to_target | shifts_over_limit | shifts_never_reached |
|---|---|---|---|---|---|
| S05 | 60 | 2.26 | 6.08 | 9 | 5 |
| S02 | 60 | 1.75 | 6.5 | 3 | 0 |
| S08 | 60 | 1.73 | 5.58 | 1 | 4 |
| S12 | 60 | 1.61 | 3.33 | 0 | 0 |
| S06 | 60 | 1.6 | 2.33 | 0 | 0 |
| S01 | 60 | 1.58 | 2.0 | 0 | 0 |
| S11 | 60 | 1.58 | 2.42 | 0 | 0 |
| S04 | 60 | 1.57 | 3.0 | 0 | 0 |
| S10 | 60 | 1.57 | 2.0 | 0 | 0 |
| S03 | 60 | 1.54 | 1.92 | 0 | 0 |
| S07 | 60 | 1.54 | 2.08 | 0 | 0 |
| S09 | 60 | 1.52 | 1.92 | 0 | 0 |

## Q8 Lots by final status

| status | lots | quantity_kg | pct_of_lots |
|---|---|---|---|
| Reconciled | 353 | 80908.0 | 94.9 |
| Chilled | 12 | 1348.0 | 3.2 |
| Rejected | 5 | 1308.0 | 1.3 |
| UnderReview | 2 | 408.0 | 0.5 |

## Q9 Synchronisation lag by society (offline tolerance, FR-06)

| society | entries | avg_minutes_seal_to_sync | max_minutes_seal_to_sync | entries_not_yet_synced | sync_before_capture |
|---|---|---|---|---|---|
| S09 | 999 | 40.7 | 600.0 | 0 | 0 |
| S01 | 1029 | 58.0 | 589.0 | 0 | 0 |
| S02 | 998 | 54.5 | 580.0 | 0 | 0 |
| S11 | 1023 | 30.2 | 558.0 | 0 | 0 |
| S05 | 1014 | 31.9 | 511.0 | 0 | 0 |
| S12 | 1021 | 26.9 | 467.0 | 0 | 0 |

## Q10 Responsibility recorded for closed variance cases, by route

| route | responsibility | cases | net_kg_difference |
|---|---|---|---|
| RT1 | Society | 32 | -79.0 |
| RT1 | Transporter | 5 | -22.0 |
| RT1 | MeasurementTolerance | 2 | -3.0 |
| RT2 | Society | 26 | -18.0 |
| RT2 | MeasurementTolerance | 1 | -1.0 |
| RT3 | Transporter | 2 | -8.0 |
| RT3 | MeasurementTolerance | 2 | -2.0 |
