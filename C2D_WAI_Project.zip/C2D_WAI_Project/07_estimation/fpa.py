"""
Function Point Analysis of the C2D design (IFPUG method: five component types,
three complexity levels, 14 general system characteristics).

Every count below is read off the design: an ILF is a logical group of the
class model, and EI / EO / EQ are elementary processes taken from the use
cases. Complexity follows the IFPUG matrices on the number of data element
types (DET), record element types (RET) and file types referenced (FTR).

The effort figure at the end is INDICATIVE. It rests on two stated
assumptions (source lines per function point, and the Basic COCOMO mode)
and is shown as a range, not as a forecast.

Usage: python3 fpa.py   (prints the count and writes fpa_result.json / fpa_items.csv)
"""
import csv
import json
import math
from pathlib import Path

WEIGHT = {"ILF": (7, 10, 15), "EIF": (5, 7, 10), "EI": (3, 4, 6), "EO": (4, 5, 7), "EQ": (3, 4, 6)}


def ilf_level(ret, det):                 # IFPUG matrix for ILF and EIF
    col = 0 if det <= 19 else 1 if det <= 50 else 2
    row = 0 if ret == 1 else 1 if ret <= 5 else 2
    return [[0, 0, 1], [0, 1, 2], [1, 2, 2]][row][col]


def ei_level(ftr, det):                  # IFPUG matrix for EI
    col = 0 if det <= 4 else 1 if det <= 15 else 2
    row = 0 if ftr <= 1 else 1 if ftr == 2 else 2
    return [[0, 0, 1], [0, 1, 2], [1, 2, 2]][row][col]


def eo_level(ftr, det):                  # IFPUG matrix for EO (EQ uses the same bands)
    col = 0 if det <= 5 else 1 if det <= 19 else 2
    row = 0 if ftr <= 1 else 1 if ftr <= 3 else 2
    return [[0, 0, 1], [0, 1, 2], [1, 2, 2]][row][col]


# (type, name, source in the design, RET or FTR, DET)
ITEMS = [
 ("ILF", "Organisation master", "Route, Society, BulkMilkCooler", 3, 10),
 ("ILF", "Member register", "Member", 1, 6),
 ("ILF", "Users and roles", "User", 1, 6),
 ("ILF", "Device register", "Device", 1, 7),
 ("ILF", "Rate charts", "RateChart, RateChartLine", 2, 9),
 ("ILF", "Collection ledger", "CollectionShift, CollectionEntry", 2, 22),
 ("ILF", "Tank lots and readings", "TankLot, TemperatureReading", 2, 11),
 ("ILF", "Exception cases", "ExceptionCase and subclasses, CaseAction", 4, 22),
 ("ILF", "Dispatch and receipt", "TankerTrip, PickupRecord, DockReceipt", 3, 20),
 ("ILF", "Payment cycles and statements", "PaymentCycle, PaymentStatement", 2, 10),
 ("ILF", "Notification log", "Notification", 1, 8),
 ("ILF", "Audit trail", "AuditEvent", 1, 6),
 ("ILF", "Configuration", "config table (NFR-10)", 1, 3),
 ("EI", "Open shift", "UC-01", 2, 4),
 ("EI", "Record device-captured entry", "UC-01", 4, 10),
 ("EI", "Record manual entry", "UC-02", 4, 11),
 ("EI", "Close shift and seal ledger", "UC-03", 2, 5),
 ("EI", "Submit sensor reading", "UC-04", 2, 5),
 ("EI", "Acknowledge case or add action", "UC-06", 2, 4),
 ("EI", "Decide disposition", "UC-07", 3, 6),
 ("EI", "Resolve variance", "UC-07", 3, 5),
 ("EI", "Record tanker pickup", "UC-08", 2, 7),
 ("EI", "Record dock receipt", "UC-09", 3, 8),
 ("EI", "Generate payment statements", "UC-10", 3, 6),
 ("EI", "Approve payment cycle", "UC-10", 2, 3),
 ("EI", "Create rate chart", "UC-11", 1, 8),
 ("EI", "Approve or supersede rate chart", "UC-11", 1, 3),
 ("EI", "Add member", "UC-12", 1, 6),
 ("EI", "Change member", "UC-12", 1, 6),
 ("EI", "Deactivate member", "UC-12", 1, 2),
 ("EI", "Add user", "UC-12", 1, 6),
 ("EI", "Change or deactivate user", "UC-12", 1, 4),
 ("EI", "Register device", "UC-12", 1, 6),
 ("EI", "Deactivate device", "UC-12", 1, 2),
 ("EI", "Add society, route or cooler", "UC-12", 1, 8),
 ("EI", "Change society, route or cooler", "UC-12", 1, 8),
 ("EI", "Change a threshold or tolerance", "NFR-10", 2, 3),
 ("EO", "Collection message to member", "UC-13", 2, 7),
 ("EO", "Exception alert", "UC-05, UC-13", 3, 6),
 ("EO", "Escalation alert", "UC-06", 2, 4),
 ("EO", "Statement export to accounting", "UC-10", 2, 8),
 ("EO", "Shift summary with manual entries", "UC-03", 2, 8),
 ("EO", "Report: procurement by route", "UC-15", 2, 9),
 ("EO", "Report: chilling compliance", "UC-15", 3, 8),
 ("EO", "Report: pickup-to-dock variance", "UC-15", 4, 9),
 ("EO", "Report: exception ageing", "UC-15", 2, 7),
 ("EO", "Ledger integrity verification", "UC-14", 2, 5),
 ("EQ", "Member passbook", "UC-01", 2, 8),
 ("EQ", "Open cases list", "UC-06, UC-07", 2, 7),
 ("EQ", "Case detail with evidence", "UC-07", 3, 12),
 ("EQ", "Cooler temperature trace", "UC-04", 1, 6),
 ("EQ", "Audit trail", "UC-14", 2, 6),
 ("EQ", "Rate chart lookup", "UC-11", 1, 7),
 ("EQ", "Pickups of a trip", "UC-09", 2, 6),
 ("EQ", "Device register and status", "UC-12", 1, 7),
]
# 14 general system characteristics, each rated 0 (no influence) to 5 (strong influence)
GSC = [("Data communications", 5, "edge units, staff clients and two external interfaces"),
       ("Distributed data processing", 4, "rules and ledger at the edge, services at the Union"),
       ("Performance", 3, "alert within 60 seconds (NFR-05)"),
       ("Heavily used configuration", 2, "low-cost edge hardware"),
       ("Transaction rate", 3, "peaks in the two collection windows"),
       ("Online data entry", 5, "all entry is interactive or from devices"),
       ("End-user efficiency", 3, "bilingual screens, three-action entry (NFR-07)"),
       ("Online update", 4, "ledgers and cases updated online, with offline queueing"),
       ("Complex processing", 3, "hash chain, rule engine, reconciliation"),
       ("Reusability", 1, "no reuse requirement"),
       ("Installation ease", 3, "many village sites"),
       ("Operational ease", 3, "unattended synchronisation and recovery"),
       ("Multiple sites", 4, "one installation per society"),
       ("Facilitate change", 3, "configurable thresholds and rate charts")]
LOC_PER_FP = (40, 50, 60)          # ASSUMPTION: modern high-level language mix; shown as low / central / high
COCOMO = {"organic": (2.4, 1.05, 2.5, 0.38), "semi-detached": (3.0, 1.12, 2.5, 0.35)}   # Boehm (1981), Basic COCOMO


def count():
    rows, summary = [], {t: [0, 0, 0] for t in WEIGHT}
    for typ, name, src, a, det in ITEMS:
        lvl = ilf_level(a, det) if typ in ("ILF", "EIF") else ei_level(a, det) if typ == "EI" else eo_level(a, det)
        summary[typ][lvl] += 1
        rows.append([typ, name, src, a, det, ("Low", "Average", "High")[lvl], WEIGHT[typ][lvl]])
    ufp = sum(r[6] for r in rows)
    tdi = sum(g[1] for g in GSC)
    vaf = 0.65 + 0.01 * tdi
    afp = ufp * vaf
    effort = {}
    for mode, (a, b, c, d) in COCOMO.items():
        for loc in LOC_PER_FP:
            kloc = afp * loc / 1000
            pm = a * kloc ** b
            effort[f"{mode}@{loc}"] = dict(kloc=round(kloc, 1), person_months=round(pm, 1), months=round(c * pm ** d, 1))
    return rows, dict(summary=summary, ufp=ufp, tdi=tdi, vaf=round(vaf, 2), afp=round(afp), effort=effort,
                      by_type={t: sum(r[6] for r in rows if r[0] == t) for t in WEIGHT})


if __name__ == "__main__":
    rows, res = count()
    here = Path(__file__).parent
    with open(here / "fpa_items.csv", "w", newline="", encoding="utf-8") as f:
        csv.writer(f).writerows([["Type", "Function", "Source in the design", "RET or FTR", "DET", "Complexity", "Points"]] + rows)
    (here / "fpa_result.json").write_text(json.dumps(dict(result=res, gsc=GSC, items=rows), indent=1), encoding="utf-8")
    print("counts (low, average, high):", res["summary"])
    print("points by type:", res["by_type"], "| UFP", res["ufp"], "| TDI", res["tdi"], "| VAF", res["vaf"], "| AFP", res["afp"])
    for k, v in res["effort"].items():
        print(f"  {k:20s} {v}")
