# Collection to Dock (C2D)

**An edge-enabled information system for milk collection integrity, chilling exceptions and dock reconciliation in village dairy cooperatives.**

Working with AI (WAI) project, Fundamentals of Information Systems, Term V, Integrated Programme in Management, IIM Ranchi, AY 2026-27.

This repository holds the report, the UML model for Sparx Enterprise Architect, the SQLite prototype with its tests, the dashboard, the function point count and the prompt logbook. Everything except the report text is generated from one model definition (`03_model_source/c2d_model.py` and `c2d_requirements.py`).

## Read this first

- **AI assistance.** The model, the code and the draft text were produced in one agentic session with Claude (Anthropic), started from a master prompt that was drafted with ChatGPT. The prompt and the log are in `06_logbook/`.
- **Synthetic data.** All data in `04_database/` and `data/` are simulated. They show that the design behaves as specified. They say nothing about any real dairy union.
- **Not deployed.** This is a specification and a prototype. Thresholds and tolerances are design values.
- **Enterprise Architect.** `02_ea_model/C2D_Model.qea` was written by a program and checked structurally, but it has not yet been opened in Enterprise Architect. `docs/EA_GUIDE.md` gives the check to run and a fallback.

## What to open

| File | What it is |
|---|---|
| `01_report/WAI_Report_C2D.docx` / `.pdf` | The report: main text and references on pages 1 to 12, then annexures A to L |
| `02_ea_model/C2D_Model.qea` | Enterprise Architect project (EA 16 or later): 5 packages, 161 elements, 12 diagrams |
| `02_ea_model/diagrams/` | The 12 diagrams as PNG and SVG, drawn from the same definition |
| `05_dashboard/dashboard.html` | Dashboard with seven views; open in any browser, no server needed |
| `04_database/c2d_prototype.sqlite` | The prototype database (23 tables, 10 triggers, 3 views) |
| `04_database/outputs/` | Results of the 10 reporting queries and the 34 acceptance tests |
| `06_logbook/prompt_logbook.md` | Prompt logbook |

## Folders

| Folder | Contents |
|---|---|
| `01_report` | Report and the programs that build it (`build_all.sh`) |
| `02_ea_model` | EA project, fallback build script, diagram images |
| `03_model_source` | `c2d_requirements.py`, `c2d_model.py`, `build_qea.py`, `render_diagrams.py`, `check_model.py`, `build_ea_script.py`, `test_ea_script.js` |
| `04_database` | `schema.sql`, `chilling_rules.py`, `generate_data.py`, `queries.sql`, `run_checks.py`, `export_csv.py`, database, outputs |
| `05_dashboard` | `build_dashboard.py`, `dashboard.html`, chart images |
| `06_logbook` | Prompt logbook and the full master prompt |
| `07_estimation` | `fpa.py` and its results |
| `data` | The synthetic data set as CSV, with `DATA_DICTIONARY.md` |
| `docs` | `EA_GUIDE.md`, `SOURCES.md`, `REQUIREMENT_TO_DELIVERABLE.md`, `model_checks.md`, CSV exports of the model |

## What has been verified, and what has not

Executed in the AI workspace (results are in the files named):

| Check | Result | Where |
|---|---|---|
| Structural checks on the EA repository (types, references, geometry, GUIDs) | 17 of 17 pass | printed by `build_qea.py`; report Annexure G |
| Consistency across requirements, UML model, repository and database | 12 of 12 pass | `docs/model_checks.md` |
| Test of those checks with seven planted defects | 7 of 7 detected | report Annexure G |
| Acceptance tests on the SQLite prototype | 34 of 34 pass | `04_database/outputs/test_results.md` |
| Fallback EA script against a mock of the Automation Interface | passes | `node 03_model_source/test_ea_script.js` |
| References | each checked against Crossref, OpenAlex or the publisher's page | `docs/SOURCES.md` |

Not verified, and still to be done by the student:

1. Open `C2D_Model.qea` in Enterprise Architect, run the Project Integrity Check and record the result (report Annexure K).
2. Open the DOCX in Word, fill in the highlighted placeholders, update the contents page, and export the PDF from Word so that it embeds Times New Roman.
3. Upload the repository and add its link to Annexure L.

## Rebuild everything

Requirements: Python 3.10 or later with Pillow; Node.js with the `docx` package; `rsvg-convert` and the Carlito font for the diagram images; LibreOffice for the PDF. The generated files are included, so nothing has to be rebuilt to read or mark the project.

```bash
cd 03_model_source
python3 build_qea.py build base_empty.qea ../02_ea_model/C2D_Model.qea   # EA repository + 17 structural checks
python3 render_diagrams.py ../02_ea_model/diagrams                       # 12 diagrams, SVG and PNG
python3 build_ea_script.py && node test_ea_script.js                     # fallback EA script + mock run
cd ../04_database
python3 generate_data.py          # rebuilds c2d_prototype.sqlite from schema.sql (fixed seed)
python3 run_checks.py             # 10 queries, 34 acceptance tests
python3 export_csv.py             # ../data/*.csv
cd ../03_model_source && python3 check_model.py     # 12 consistency checks, CSV exports to ../docs/exports
cd ../07_estimation && python3 fpa.py               # function point count
cd ../05_dashboard && python3 build_dashboard.py    # dashboard.html
cd ../01_report && ./build_all.sh                   # report DOCX and PDF
```

`base_empty.qea` is an Enterprise Architect repository with the schema and reference tables only. It was made from the classroom file with `python3 build_qea.py make-base <classroom file>.qea base_empty.qea`, which removes every model row and assigns a new project identifier.

## How the pieces fit

```
c2d_requirements.py + c2d_model.py          (single definition: requirements, elements, connectors, diagrams)
        |-- build_qea.py        -> C2D_Model.qea            (Enterprise Architect repository)
        |-- render_diagrams.py  -> diagrams/*.svg, *.png    (figures in the report)
        |-- build_ea_script.py  -> C2D_build_script.js      (fallback build inside EA)
        |-- generate_data.py    -> lot_transition table     (the database enforces state machine STM-01)
        '-- check_model.py      -> model_checks.md, exports (requirements = use cases = classes = tables = repository)
```

A change to a class, a transition or a requirement is made once in the definition and flows to the repository, the figures, the database rules and the traceability matrix.
