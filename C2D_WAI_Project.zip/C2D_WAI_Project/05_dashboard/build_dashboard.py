"""
Builds the C2D procurement dashboard (FR-20) as one self-contained HTML file.

The script reads the SQLite prototype, embeds seven small data sets as JSON in
the page and writes dashboard.html. The page draws the charts itself (inline
JavaScript, no external library, works offline). All data are SYNTHETIC.

Usage:  python3 build_dashboard.py ../04_database/c2d_prototype.sqlite dashboard.html
"""
import json
import sqlite3
import sys
from pathlib import Path


def collect(db):
    con = sqlite3.connect(f"file:{db}?mode=ro", uri=True)
    q = lambda sql, p=(): con.execute(sql, p).fetchall()
    cfg = dict(q("SELECT key, value FROM config"))
    d = {"config": cfg}
    d["societies"] = [dict(code=c, route=r) for c, r in q("SELECT society_code, route_code FROM society ORDER BY 1")]
    d["daily"] = [dict(date=a, route=b, kg=c) for a, b, c in q(
        "SELECT s.shift_date, so.route_code, round(sum(e.quantity_kg)) FROM collection_entry e JOIN collection_shift s USING (shift_id) "
        "JOIN society so USING (society_code) GROUP BY 1, 2 ORDER BY 1, 2")]
    d["chill"] = [dict(society=a, hours=round(b, 2), shift=c) for a, b, c in q(
        "SELECT s.society_code, (julianday((SELECT min(t.read_at) FROM temperature_reading t WHERE t.bmc_code = 'BMC-' || s.society_code "
        "AND t.read_at >= s.sealed_at AND t.read_at <= datetime(s.sealed_at, '+12 hours') AND t.milk_temp_c <= ?)) - julianday(s.sealed_at)) * 24 AS h, "
        "s.shift_date || ' ' || s.shift_code FROM collection_shift s WHERE s.status <> 'Open'", (cfg["chill_target_c"],)) if b is not None]
    d["variance"] = [dict(society=a, pct=b, date=c) for a, b, c in q("SELECT society_code, quantity_variance_pct, pickup_date FROM v_reconciliation")]
    d["integrity"] = [dict(society=a, manual=b, fat=c) for a, b, c in q(
        "SELECT m.society_code, m.pct, v.fat FROM (SELECT s.society_code, round(100.0 * sum(e.capture_mode = 'Manual') / count(*), 1) AS pct "
        "FROM collection_entry e JOIN collection_shift s USING (shift_id) GROUP BY 1) m JOIN (SELECT society_code, round(avg(fat_variance), 3) AS fat "
        "FROM v_reconciliation GROUP BY 1) v USING (society_code)")]
    d["cases"] = [dict(society=a, chilling=b, variance=c) for a, b, c in q(
        "SELECT so.society_code, coalesce(sum(c.case_type = 'Chilling'), 0), coalesce(sum(c.case_type = 'Variance'), 0) FROM society so "
        "JOIN bulk_milk_cooler b USING (society_code) JOIN tank_lot l USING (bmc_code) LEFT JOIN exception_case c USING (lot_id) GROUP BY 1 ORDER BY 1")]
    d["ack"] = [dict(society=a, minutes=round(b, 1), rule=c[:2], escalated=e) for a, b, c, e in q(
        "SELECT b.society_code, (julianday(c.acknowledged_at) - julianday(c.raised_at)) * 1440, c.rule_code, "
        "EXISTS (SELECT 1 FROM case_action a WHERE a.case_id = c.case_id AND a.action_type = 'Escalate') "
        "FROM exception_case c JOIN tank_lot l USING (lot_id) JOIN bulk_milk_cooler b USING (bmc_code) WHERE c.case_type = 'Chilling'")]
    # one warm-holding incident, start to finish
    cid, bmc, raised, ack, decided, disp, peak = q(
        "SELECT c.case_id, l.bmc_code, c.raised_at, c.acknowledged_at, c.decided_at, c.disposition, c.peak_temp_c FROM exception_case c "
        "JOIN tank_lot l USING (lot_id) WHERE c.rule_code = 'R2_WarmHolding' ORDER BY c.peak_temp_c DESC LIMIT 1")[0]
    d["incident"] = dict(case=cid, bmc=bmc, raised=raised, acknowledged=ack, decided=decided, disposition=disp, peak=peak,
                         readings=[dict(t=t, temp=v, power=p) for t, v, p in q(
                             "SELECT read_at, milk_temp_c, power_on FROM temperature_reading WHERE bmc_code = ? AND read_at BETWEEN datetime(?, '-7 hours') "
                             "AND datetime(?, '+2 hours') ORDER BY read_at", (bmc, raised, decided))])
    kg, amount, members = q("SELECT round(sum(quantity_kg)), round(sum(amount)), count(DISTINCT member_code) FROM collection_entry")[0]
    lots, clean = q("SELECT count(*), sum(NOT EXISTS (SELECT 1 FROM exception_case c WHERE c.lot_id = l.lot_id AND c.case_type = 'Chilling')) FROM tank_lot l")[0]
    rec, within = q("SELECT count(*), sum(abs(quantity_variance_pct) <= ? AND abs(fat_variance) <= ? AND abs(snf_variance) <= ? AND decision <> 'Rejected') "
                    "FROM v_reconciliation", (cfg["tol_quantity_pct"], cfg["tol_fat"], cfg["tol_snf"]))[0]
    open_cases = q("SELECT count(*) FROM exception_case WHERE status <> 'Closed'")[0][0]
    d["kpi"] = [["Milk collected", f"{kg / 1000:,.1f} t", "30 days, 12 societies"], ["Amount payable", f"Rs {amount / 100000:,.1f} lakh", f"{members} members"],
                ["Tank lots", f"{lots}", "one per society per day"], ["Lots with no chilling case", f"{100 * clean / lots:.1f}%", f"{lots - clean} lots had a case"],
                ["Received lots within tolerance", f"{100 * within / rec:.1f}%", f"{rec - within} of {rec} raised a variance case"],
                ["Cases still open", f"{open_cases}", "at period end"]]
    con.close()
    return d


TEMPLATE = r"""<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>C2D procurement dashboard (synthetic data)</title>
<style>
.viz-root{color-scheme:light;--plane:#f9f9f7;--surface:#fcfcfb;--ink:#0b0b0b;--ink2:#52514e;--muted:#898781;--grid:#e1e0d9;--axis:#c3c2b7;
 --s1:#2a78d6;--s2:#eb6834;--s3:#1baf7a;--context:#b9b7ae;--ring:rgba(11,11,11,.10);--wash:rgba(42,120,214,.10)}
@media (prefers-color-scheme:dark){:root:where(:not([data-theme="light"])) .viz-root{color-scheme:dark;--plane:#0d0d0d;--surface:#1a1a19;--ink:#f0efec;
 --ink2:#c3c2b7;--muted:#898781;--grid:#2c2c2a;--axis:#383835;--s1:#3987e5;--s2:#d95926;--s3:#199e70;--context:#5d5c57;--ring:rgba(255,255,255,.10);--wash:rgba(57,135,229,.14)}}
*{box-sizing:border-box} body{margin:0}
.viz-root{background:var(--plane);color:var(--ink);font:14px/1.45 system-ui,-apple-system,"Segoe UI",sans-serif;padding:20px 24px 40px;min-height:100vh}
h1{font-size:20px;margin:0 0 2px;font-weight:650} .sub{color:var(--ink2);margin:0 0 14px}
.note{border:1px solid var(--ring);background:var(--surface);border-radius:8px;padding:8px 12px;color:var(--ink2);font-size:13px;margin-bottom:14px}
.filters{display:flex;gap:10px;align-items:center;margin-bottom:14px;color:var(--ink2);font-size:13px}
select{font:inherit;color:var(--ink);background:var(--surface);border:1px solid var(--axis);border-radius:6px;padding:4px 8px}
.kpis{display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:12px;margin-bottom:14px}
.tile,.card{background:var(--surface);border:1px solid var(--ring);border-radius:10px}
.tile{padding:12px 14px}.tile .l{color:var(--ink2);font-size:12.5px}.tile .v{font-size:24px;font-weight:650;margin:2px 0}.tile .d{color:var(--muted);font-size:12px}
.grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px}
@media (max-width:820px){.grid{grid-template-columns:1fr}}
.card{padding:14px 16px 10px}.card h2{font-size:14.5px;margin:0;font-weight:650}.card p.c{margin:2px 0 6px;color:var(--ink2);font-size:12.5px}
svg{width:100%;height:auto;display:block;overflow:visible}
svg text{font:12px system-ui,-apple-system,"Segoe UI",sans-serif;fill:var(--ink2)} svg text.t{fill:var(--muted);font-size:11.5px} svg text.b{fill:var(--ink);font-weight:600}
.legend{display:flex;gap:14px;flex-wrap:wrap;font-size:12.5px;color:var(--ink2);margin:0 0 2px}.legend i{display:inline-block;width:10px;height:10px;border-radius:2px;margin-right:5px}
.legend i.line{height:2px;width:14px;vertical-align:middle;border-radius:1px}.legend i.dot{border-radius:50%}
details{margin-top:6px;font-size:12.5px;color:var(--ink2)} summary{cursor:pointer} table{border-collapse:collapse;margin-top:6px;width:100%}
th,td{text-align:right;padding:2px 8px;border-bottom:1px solid var(--grid);font-variant-numeric:tabular-nums}th:first-child,td:first-child{text-align:left}
#tip{position:fixed;pointer-events:none;background:var(--surface);border:1px solid var(--axis);border-radius:6px;padding:6px 9px;font-size:12.5px;
 box-shadow:0 2px 8px rgba(0,0,0,.12);display:none;z-index:9;max-width:260px}#tip b{display:block;font-size:13.5px;color:var(--ink)}#tip span{color:var(--ink2)}
body.compact .viz-root{padding:0;background:var(--surface)} body.compact h1,body.compact .sub,body.compact .note,body.compact .filters,body.compact .kpis,body.compact details,
body.report .card:not(.r),body.annex .card:not(.a){display:none} body.compact .grid{gap:8px;grid-template-columns:repeat(2,minmax(0,1fr))} body.compact .card{border-radius:6px;padding:9px 11px 5px}
body.compact .card h2{font-size:13.5px} body.compact .card p.c{font-size:11.8px;margin:1px 0 4px} body.compact .legend{font-size:11.8px}
</style></head>
<body><div class="viz-root">
<h1>C2D procurement dashboard</h1>
<p class="sub">Collection, chilling, reconciliation and exception handling: 1 to 30 September 2026</p>
<div class="note"><b>Synthetic data.</b> Every figure on this page comes from the simulation in <code>04_database/generate_data.py</code>, which plants known problems at
six societies. The page shows what the reporting layer of the design can answer; it says nothing about any real union.</div>
<div class="filters"><label for="route">Route</label><select id="route"><option value="">All routes</option><option>RT1</option><option>RT2</option><option>RT3</option></select>
<span>The filter applies to every chart except the daily trend (already split by route) and the single incident.</span></div>
<div class="kpis" id="kpis"></div>
<div class="grid">
 <div class="card a" id="c1"><h2>Daily milk collected, by route</h2><p class="c">kg per day</p><div class="legend" id="l1"></div><div class="plot"></div><details><summary>Table view</summary><div class="tbl"></div></details></div>
 <div class="card r" id="c2"><h2>Time to reach 4 &deg;C after a shift is sealed</h2><p class="c">hours, one dot per shift; rule R1 limit is 4 hours</p><div class="legend" id="l2"></div><div class="plot"></div><details><summary>Table view</summary><div class="tbl"></div></details></div>
 <div class="card r" id="c4"><h2>Pickup-to-dock quantity variance</h2><p class="c">% of pickup quantity, one dot per lot; tolerance band is &plusmn;0.5%</p><div class="legend" id="l4"></div><div class="plot"></div><details><summary>Table view</summary><div class="tbl"></div></details></div>
 <div class="card r" id="c5"><h2>Manual entries against fat variance</h2><p class="c">one dot per society; fat variance = dock test minus ledger, percentage points</p><div class="plot"></div><details><summary>Table view</summary><div class="tbl"></div></details></div>
 <div class="card r" id="c7"><h2>Time to acknowledge a chilling case</h2><p class="c">minutes, one dot per case (five-minute simulation steps); escalation limit is 15 minutes</p><div class="legend" id="l7"></div><div class="plot"></div><details><summary>Table view</summary><div class="tbl"></div></details></div>
 <div class="card a" id="c6"><h2>Exception cases by society</h2><p class="c">number of cases in the period</p><div class="legend" id="l6"></div><div class="plot"></div><details><summary>Table view</summary><div class="tbl"></div></details></div>
 <div class="card a" id="c3" style="grid-column:1/-1"><h2 id="h3"></h2><p class="c" id="p3"></p><div class="plot"></div><details><summary>Table view</summary><div class="tbl"></div></details></div>
</div></div><div id="tip"></div>
<script>
const D = __DATA__;
const COMPACT = location.hash === "#report" || location.hash === "#annex";      // static layouts used for the figures in the report
if (COMPACT) document.body.classList.add("compact", location.hash.slice(1));
const CW = COMPACT ? 360 : 520, CH = COMPACT ? 178 : 250;
const NS = "http://www.w3.org/2000/svg", css = v => `var(--${v})`;
const el = (tag, attrs, parent, text) => { const e = document.createElementNS(NS, tag); for (const k in attrs) e.setAttribute(k, attrs[k]); if (text != null) e.textContent = text; if (parent) parent.appendChild(e); return e; };
const tip = document.getElementById("tip");
function hover(node, head, lines) {          // per-mark tooltip; text is inserted with textContent only
  node.setAttribute("tabindex", "0");
  const show = ev => { tip.replaceChildren(); const b = document.createElement("b"); b.textContent = head; tip.appendChild(b);
    for (const l of lines) { const s = document.createElement("span"); s.textContent = l; tip.appendChild(s); tip.appendChild(document.createElement("br")); }
    tip.style.display = "block"; const r = node.getBoundingClientRect(); const x = (ev.clientX ?? r.right) + 14, y = (ev.clientY ?? r.top) + 12;
    tip.style.left = Math.min(x, innerWidth - 270) + "px"; tip.style.top = Math.min(y, innerHeight - 80) + "px"; node.setAttribute("opacity", ".7"); };
  const hide = () => { tip.style.display = "none"; node.removeAttribute("opacity"); };
  node.addEventListener("pointermove", show); node.addEventListener("focus", show); node.addEventListener("pointerleave", hide); node.addEventListener("blur", hide);
}
function frame(card, W, H, m) {              // svg with margins; returns helpers
  const host = card.querySelector(".plot"); host.replaceChildren();
  const svg = el("svg", { viewBox: `0 0 ${W} ${H}`, role: "img", "aria-label": card.querySelector("h2").textContent }, host);
  return { svg, x0: m.l, x1: W - m.r, y0: H - m.b, y1: m.t };
}
function yAxis(f, lo, hi, ticks, fmt) {
  const y = v => f.y0 - (v - lo) / (hi - lo) * (f.y0 - f.y1);
  for (const t of ticks) { el("line", { x1: f.x0, x2: f.x1, y1: y(t), y2: y(t), stroke: css(t === 0 ? "axis" : "grid"), "stroke-width": 1 }, f.svg);
    el("text", { x: f.x0 - 6, y: y(t) + 4, "text-anchor": "end", class: "t" }, f.svg, fmt ? fmt(t) : t); }
  return y;
}
function band(f, names) {                    // categorical x axis
  const w = (f.x1 - f.x0) / names.length, x = i => f.x0 + w * (i + .5);
  names.forEach((n, i) => el("text", { x: x(i), y: f.y0 + 16, "text-anchor": "middle", class: "t" }, f.svg, n));
  el("line", { x1: f.x0, x2: f.x1, y1: f.y0, y2: f.y0, stroke: css("axis") }, f.svg);
  return { x, w };
}
function limit(f, y, label, side) {          // threshold line: dashed on purpose, it is a limit and not a gridline
  el("line", { x1: f.x0, x2: f.x1, y1: y, y2: y, stroke: css("ink2"), "stroke-width": 1, "stroke-dasharray": "4 3" }, f.svg);
  el("text", { x: f.x1, y: y + (side === "below" ? 13 : -5), "text-anchor": "end", class: "b" }, f.svg, label);
}
function table(card, head, rows) {
  const t = document.createElement("table"), tr = t.insertRow(); head.forEach(h => { const th = document.createElement("th"); th.textContent = h; tr.appendChild(th); });
  rows.forEach(r => { const row = t.insertRow(); r.forEach(c => row.insertCell().textContent = c); }); card.querySelector(".tbl").replaceChildren(t);
}
function legend(id, items) {
  const box = document.getElementById(id); box.replaceChildren();
  for (const [kind, color, label] of items) { const s = document.createElement("span"), i = document.createElement("i"); i.className = kind; i.style.background = css(color); s.appendChild(i); s.append(label); box.appendChild(s); }
}
const jitter = (i, w) => ((i * 0.618034) % 1 - .5) * w * .6;      // deterministic spread inside a band
const fmt1 = v => (+v).toFixed(1), fmt2 = v => (+v).toFixed(2);

// strip plot: one column per society, dots outside the limit carry the accent, the rest are context
function strip(id, rows, key, o) {
  const card = document.getElementById(id), soc = societies(), f = frame(card, CW, CH, { l: 36, r: 8, t: 12, b: 24 });
  const y = yAxis(f, o.lo, o.hi, o.ticks, o.fmt), b = band(f, soc);
  if (o.band) el("rect", { x: f.x0, width: f.x1 - f.x0, y: y(o.band[1]), height: y(o.band[0]) - y(o.band[1]), fill: css("wash") }, f.svg);
  for (const [v, label, side] of o.limits) limit(f, y(v), label, side);
  const count = {};
  rows.filter(r => soc.includes(r.society)).forEach(r => { const i = soc.indexOf(r.society); count[r.society] = (count[r.society] || 0) + 1;
    const out = (o.outRow || (q => o.out(q[key])))(r), v = Math.max(o.lo, Math.min(o.hi, r[key]));
    const c = el("circle", { cx: b.x(i) + jitter(count[r.society], b.w), cy: y(v), r: out ? (COMPACT ? 3.6 : 4.2) : (COMPACT ? 2.4 : 3), fill: css(out ? "s1" : "context"), stroke: css("surface"), "stroke-width": out ? 1.5 : .8 }, f.svg);
    hover(c, `${o.fmt ? o.fmt(r[key]) : r[key]} ${o.unit}`, o.tip(r)); });
  table(card, ["Society", "Count", "Mean", "Outside limit"], soc.map(s => { const v = rows.filter(r => r.society === s).map(r => r[key]);
    return [s, v.length, v.length ? fmt2(v.reduce((a, c) => a + c, 0) / v.length) : "", rows.filter(r => r.society === s).filter(o.outRow || (q => o.out(q[key]))).length]; }));
}
const societies = () => { const r = document.getElementById("route").value; return D.societies.filter(s => !r || s.route === r).map(s => s.code); };

function draw() {
  // KPI tiles
  const k = document.getElementById("kpis"); k.replaceChildren();
  for (const [l, v, d] of D.kpi) { const t = document.createElement("div"); t.className = "tile"; for (const [c, s] of [["l", l], ["v", v], ["d", d]]) { const e = document.createElement("div"); e.className = c; e.textContent = s; t.appendChild(e); } k.appendChild(t); }

  // 1 daily collection by route: three lines, fixed colour per route
  { const card = document.getElementById("c1"), f = frame(card, CW, CH, { l: 44, r: 40, t: 12, b: 24 }), routes = ["RT1", "RT2", "RT3"], col = { RT1: "s1", RT2: "s2", RT3: "s3" };
    const days = [...new Set(D.daily.map(r => r.date))], y = yAxis(f, 600, 1200, [600, 800, 1000, 1200], v => v.toLocaleString()), x = i => f.x0 + (f.x1 - f.x0) * i / (days.length - 1);
    days.forEach((d, i) => { if (i % 7 === 0) el("text", { x: x(i), y: f.y0 + 16, "text-anchor": "middle", class: "t" }, f.svg, d.slice(8) + " Sep"); });
    el("line", { x1: f.x0, x2: f.x1, y1: f.y0, y2: f.y0, stroke: css("axis") }, f.svg);
    const val = (r, d) => (D.daily.find(q => q.route === r && q.date === d) || {}).kg;
    for (const r of routes) { el("polyline", { points: days.map((d, i) => `${x(i)},${y(val(r, d))}`).join(" "), fill: "none", stroke: css(col[r]), "stroke-width": 2, "stroke-linejoin": "round" }, f.svg);
      el("circle", { cx: x(days.length - 1), cy: y(val(r, days.at(-1))), r: 4, fill: css(col[r]), stroke: css("surface"), "stroke-width": 2 }, f.svg);
      const ends = routes.map(q => y(val(q, days.at(-1)))), me = y(val(r, days.at(-1)));
      if (ends.filter(v => Math.abs(v - me) < 14).length === 1) el("text", { x: f.x1 + 8, y: me + 4 }, f.svg, r); }
    const cross = el("line", { y1: f.y1, y2: f.y0, stroke: css("ink2"), "stroke-width": 1, visibility: "hidden" }, f.svg);
    const hit = el("rect", { x: f.x0, y: f.y1, width: f.x1 - f.x0, height: f.y0 - f.y1, fill: "transparent" }, f.svg);
    hit.addEventListener("pointermove", ev => { const bb = hit.getBoundingClientRect(), i = Math.round((ev.clientX - bb.left) / bb.width * (days.length - 1));
      cross.setAttribute("x1", x(i)); cross.setAttribute("x2", x(i)); cross.setAttribute("visibility", "visible"); tip.replaceChildren();
      const b = document.createElement("b"); b.textContent = days[i]; tip.appendChild(b);
      for (const r of routes) { const s = document.createElement("span"); s.textContent = `${val(r, days[i]).toLocaleString()} kg  ${r}`; tip.appendChild(s); tip.appendChild(document.createElement("br")); }
      tip.style.display = "block"; tip.style.left = Math.min(ev.clientX + 14, innerWidth - 200) + "px"; tip.style.top = ev.clientY + 12 + "px"; });
    hit.addEventListener("pointerleave", () => { tip.style.display = "none"; cross.setAttribute("visibility", "hidden"); });
    legend("l1", routes.map(r => ["line", col[r], r]));
    table(card, ["Date", ...routes], days.map(d => [d, ...routes.map(r => val(r, d).toLocaleString())])); }

  // 2 time to reach the chilling target
  strip("c2", D.chill, "hours", { lo: 0, hi: 7, ticks: [0, 2, 4, 6], unit: "hours", fmt: fmt1, out: v => v > D.config.r1_hours,
    limits: [[D.config.r1_hours, "R1 limit: 4 h", "above"]], tip: r => [r.society, r.shift] });
  legend("l2", [["dot", "s1", "over the limit"], ["dot", "context", "within the limit"]]);

  // 4 quantity variance
  const tol = D.config.tol_quantity_pct;
  strip("c4", D.variance, "pct", { lo: -3.5, hi: 1, ticks: [-3, -2, -1, 0, 1], unit: "%", fmt: fmt2, out: v => Math.abs(v) > tol, band: [-tol, tol],
    limits: [], tip: r => [r.society, "picked up " + r.date] });
  legend("l4", [["dot", "s1", "outside tolerance"], ["dot", "context", "within tolerance"]]);

  // 5 manual entries against fat variance (one series; outliers are labelled directly)
  { const card = document.getElementById("c5"), soc = societies(), f = frame(card, CW, CH + 8, { l: 44, r: 12, t: 12, b: 38 });
    const y = yAxis(f, -0.2, 0.05, [-0.2, -0.15, -0.1, -0.05, 0, 0.05], fmt2), x = v => f.x0 + (f.x1 - f.x0) * v / 12;
    [0, 3, 6, 9, 12].forEach(t => el("text", { x: x(t), y: f.y0 + 16, "text-anchor": "middle", class: "t" }, f.svg, t + "%"));
    el("line", { x1: f.x0, x2: f.x1, y1: f.y0, y2: f.y0, stroke: css("axis") }, f.svg);
    el("text", { x: (f.x0 + f.x1) / 2, y: f.y0 + 33, "text-anchor": "middle" }, f.svg, "share of entries made manually");
    limit(f, y(-D.config.tol_fat), "fat tolerance: -0.10", "below");
    const rows = D.integrity.filter(r => soc.includes(r.society));
    for (const r of rows) { const out = r.manual > 4 || r.fat < -D.config.tol_fat;
      const c = el("circle", { cx: x(r.manual), cy: y(r.fat), r: out ? 5 : 4, fill: css(out ? "s1" : "context"), stroke: css("surface"), "stroke-width": 2 }, f.svg);
      hover(c, r.society, [`${r.manual}% manual entries`, `${r.fat} fat variance`]);
      if (out) el("text", { x: x(r.manual) - 9, y: y(r.fat) + 4, "text-anchor": "end", class: "b" }, f.svg, r.society); }
    table(card, ["Society", "Manual entries %", "Avg fat variance"], rows.map(r => [r.society, r.manual, r.fat])); }

  // 6 cases by society: two series stacked, 2px surface gap between segments
  { const card = document.getElementById("c6"), soc = societies(), f = frame(card, CW, CH, { l: 36, r: 8, t: 16, b: 24 });
    const y = yAxis(f, 0, 32, [0, 10, 20, 30]), b = band(f, soc), bw = Math.min(22, b.w * .6);
    soc.forEach((s, i) => { const r = D.cases.find(q => q.society === s); let base = 0;
      for (const [key, color, label] of [["chilling", "s1", "chilling"], ["variance", "s2", "variance"]]) { const v = r[key]; if (!v) continue;
        const top = y(base + v), h = y(base) - top - (base ? 2 : 0);
        const bar = el("rect", { x: b.x(i) - bw / 2, y: top, width: bw, height: Math.max(h, 1), rx: 3, fill: css(color) }, f.svg); hover(bar, `${v} ${label} cases`, [s]); base += v; }
      if (base) el("text", { x: b.x(i), y: y(base) - 5, "text-anchor": "middle", class: "b" }, f.svg, base); });
    legend("l6", [["", "s1", "chilling"], ["", "s2", "variance"]]);
    table(card, ["Society", "Chilling", "Variance"], soc.map(s => { const r = D.cases.find(q => q.society === s); return [s, r.chilling, r.variance]; })); }

  // 7 acknowledgement time
  strip("c7", D.ack, "minutes", { lo: 0, hi: 32, ticks: [0, 10, 20, 30], unit: "minutes", fmt: fmt1, out: v => v >= D.config.ack_minutes, outRow: r => !!r.escalated,
    limits: [[D.config.ack_minutes, "escalation limit: 15 min", "above"]], tip: r => [r.society, "rule " + r.rule + (r.escalated ? ", escalated" : "")] });
  legend("l7", [["dot", "s1", "escalated at 15 min"], ["dot", "context", "acknowledged in time"]]);

  // 3 one incident: temperature trace with the two thresholds and the case timeline
  { const I = D.incident, card = document.getElementById("c3"), f = frame(card, COMPACT ? 740 : 1060, COMPACT ? 200 : 250, { l: 36, r: 12, t: 14, b: 24 });
    document.getElementById("h3").textContent = `One warm-holding case from alert to decision (${I.bmc.slice(4)}, case ${I.case})`;
    document.getElementById("p3").textContent = `milk temperature in the cooler, degrees C, five-minute readings; decision: ${I.disposition}, peak ${I.peak} C`;
    const T = s => Date.parse(s.replace(" ", "T")), t0 = T(I.readings[0].t), t1 = T(I.readings.at(-1).t), x = t => f.x0 + (f.x1 - f.x0) * (T(t) - t0) / (t1 - t0);
    const hi = Math.ceil(Math.max(...I.readings.map(r => r.temp)) / 5) * 5, y = yAxis(f, 0, hi, [...Array(hi / 5 + 1).keys()].map(i => i * 5));
    el("line", { x1: f.x0, x2: f.x1, y1: f.y0, y2: f.y0, stroke: css("axis") }, f.svg);
    const off = I.readings.filter(r => !r.power);
    if (off.length) { el("rect", { x: x(off[0].t), width: x(off.at(-1).t) - x(off[0].t), y: f.y1, height: f.y0 - f.y1, fill: css("wash") }, f.svg);
      el("text", { x: x(off[0].t) + 6, y: f.y1 + 13 }, f.svg, "power off"); }
    limit(f, y(D.config.r2_temp_c), "R2 limit: 7 \u00b0C", "above"); limit(f, y(D.config.chill_target_c), "target: 4 \u00b0C", "below");
    I.readings.filter((r, i) => i % (COMPACT ? 24 : 12) === 0).forEach(r => el("text", { x: x(r.t), y: f.y0 + 16, "text-anchor": "middle", class: "t" }, f.svg, r.t.slice(11, 16)));
    el("polyline", { points: I.readings.map(r => `${x(r.t)},${y(r.temp)}`).join(" "), fill: "none", stroke: css("s1"), "stroke-width": 2, "stroke-linejoin": "round" }, f.svg);
    [["raised", I.raised], ["acknowledged", I.acknowledged], ["decided", I.decided]].forEach(([label, t], i) => { el("line", { x1: x(t), x2: x(t), y1: f.y1 + 18 + i * 14, y2: f.y0, stroke: css("ink2"), "stroke-width": 1 }, f.svg);
      el("text", { x: x(t) + 4, y: f.y1 + 28 + i * 14, class: "b" }, f.svg, `${label} ${t.slice(11, 16)}`); });
    const hit = el("rect", { x: f.x0, y: f.y1, width: f.x1 - f.x0, height: f.y0 - f.y1, fill: "transparent" }, f.svg);
    hit.addEventListener("pointermove", ev => { const bb = hit.getBoundingClientRect(), r = I.readings[Math.round((ev.clientX - bb.left) / bb.width * (I.readings.length - 1))]; tip.replaceChildren();
      const b = document.createElement("b"); b.textContent = `${r.temp} C`; tip.appendChild(b); const s = document.createElement("span"); s.textContent = `${r.t}, power ${r.power ? "on" : "off"}`; tip.appendChild(s);
      tip.style.display = "block"; tip.style.left = Math.min(ev.clientX + 14, innerWidth - 220) + "px"; tip.style.top = ev.clientY + 12 + "px"; });
    hit.addEventListener("pointerleave", () => tip.style.display = "none");
    table(card, ["Time", "Milk temp C", "Power"], I.readings.filter((r, i) => i % 6 === 0).map(r => [r.t, r.temp, r.power ? "on" : "off"])); }
}
document.getElementById("route").addEventListener("change", draw); draw();
</script></body></html>
"""


def main(db, out):
    data = collect(db)
    Path(out).write_text(TEMPLATE.replace("__DATA__", json.dumps(data, separators=(",", ":"))), encoding="utf-8")
    Path(out).with_suffix(".data.json").write_text(json.dumps(data, indent=1), encoding="utf-8")
    print("written", out, f"({Path(out).stat().st_size // 1024} KB)", "| kpis:", [k[1] for k in data["kpi"]])


if __name__ == "__main__":
    here = Path(__file__).parent
    main(sys.argv[1] if len(sys.argv) > 1 else here.parent / "04_database" / "c2d_prototype.sqlite",
         sys.argv[2] if len(sys.argv) > 2 else here / "dashboard.html")
