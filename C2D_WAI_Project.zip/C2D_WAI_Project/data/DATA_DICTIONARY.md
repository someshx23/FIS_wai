# Data dictionary

All files in this folder are exports of `04_database/c2d_prototype.sqlite`. **The data are synthetic.** They were produced by
`04_database/generate_data.py` from a fixed random seed, with problems planted at seven societies so that every exception
path of the design is exercised. They describe no real person, society, route or organisation, and nothing about the
performance of any real dairy union can be concluded from them.

Column constraints (value lists, ranges, foreign keys) are defined in `04_database/schema.sql`.

## app_user.csv

Staff users and their single role (User class). Password hashes are of made-up strings. Rows: 18.

| Column | Type | Key | Required | Refers to |
|---|---|---|---|---|
| user_id | TEXT | PK | yes |  |
| full_name | TEXT |  | yes |  |
| role | TEXT |  | yes |  |
| password_hash | TEXT |  | yes |  |
| society_code | TEXT |  |  | society.society_code |
| active | INTEGER |  | yes |  |

## route.csv

Tanker routes (Route). Rows: 3.

| Column | Type | Key | Required | Refers to |
|---|---|---|---|---|
| route_code | TEXT | PK | yes |  |
| name | TEXT |  | yes |  |
| supervisor_user_id | TEXT |  | yes | app_user.user_id |

## society.csv

Village dairy cooperative societies (Society). Rows: 12.

| Column | Type | Key | Required | Refers to |
|---|---|---|---|---|
| society_code | TEXT | PK | yes |  |
| name | TEXT |  | yes |  |
| village | TEXT |  | yes |  |
| route_code | TEXT |  | yes | route.route_code |
| active | INTEGER |  | yes |  |

## member.csv

Members who pour milk (Member). Names, mobile numbers and bank references are placeholders. Rows: 240.

| Column | Type | Key | Required | Refers to |
|---|---|---|---|---|
| member_code | TEXT | PK | yes |  |
| society_code | TEXT |  | yes | society.society_code |
| name | TEXT |  | yes |  |
| mobile | TEXT |  |  |  |
| bank_account_ref | TEXT |  |  |  |
| active | INTEGER |  | yes |  |

## device.csv

Registered collection units, cooler sensors and edge units (Device). Rows: 36.

| Column | Type | Key | Required | Refers to |
|---|---|---|---|---|
| device_id | TEXT | PK | yes |  |
| society_code | TEXT |  | yes | society.society_code |
| device_type | TEXT |  | yes |  |
| serial_no | TEXT |  | yes |  |
| key_fingerprint | TEXT |  | yes |  |
| status | TEXT |  | yes |  |
| last_seen_at | TEXT |  |  |  |

## bulk_milk_cooler.csv

One bulk milk cooler per society (BulkMilkCooler). Rows: 12.

| Column | Type | Key | Required | Refers to |
|---|---|---|---|---|
| bmc_code | TEXT | PK | yes |  |
| society_code | TEXT |  | yes | society.society_code |
| capacity_litres | INTEGER |  | yes |  |
| sensor_device_id | TEXT |  |  | device.device_id |

## rate_chart.csv

Versioned price charts (RateChart). Rows: 2.

| Column | Type | Key | Required | Refers to |
|---|---|---|---|---|
| chart_id | INTEGER | PK | yes |  |
| milk_type | TEXT |  | yes |  |
| effective_from | TEXT |  | yes |  |
| status | TEXT |  | yes |  |

## rate_chart_line.csv

Fat and SNF bands with a rate per kg (RateChartLine). Rows: 60.

| Column | Type | Key | Required | Refers to |
|---|---|---|---|---|
| chart_id | INTEGER | PK | yes | rate_chart.chart_id |
| fat_from | REAL | PK | yes |  |
| fat_to | REAL |  | yes |  |
| snf_from | REAL | PK | yes |  |
| snf_to | REAL |  | yes |  |
| rate_per_kg | REAL |  | yes |  |

## tank_lot.csv

Milk held in one cooler between two pickups (TankLot); status follows state machine STM-01. Rows: 372.

| Column | Type | Key | Required | Refers to |
|---|---|---|---|---|
| lot_id | INTEGER | PK | yes |  |
| bmc_code | TEXT |  | yes | bulk_milk_cooler.bmc_code |
| opened_at | TEXT |  | yes |  |
| sealed_at | TEXT |  |  |  |
| status | TEXT |  | yes |  |
| quantity_kg | REAL |  | yes |  |

## lot_transition.csv

The allowed lot status changes, loaded from the UML model. No class: reference data used by a trigger. Rows: 16.

| Column | Type | Key | Required | Refers to |
|---|---|---|---|---|
| from_status | TEXT | PK | yes |  |
| to_status | TEXT | PK | yes |  |
| transition | TEXT |  | yes |  |

## collection_shift.csv

Morning and evening shifts with the sealed ledger hash (CollectionShift). Rows: 720.

| Column | Type | Key | Required | Refers to |
|---|---|---|---|---|
| shift_id | INTEGER | PK | yes |  |
| society_code | TEXT |  | yes | society.society_code |
| lot_id | INTEGER |  |  | tank_lot.lot_id |
| shift_date | TEXT |  | yes |  |
| shift_code | TEXT |  | yes |  |
| status | TEXT |  | yes |  |
| opened_at | TEXT |  | yes |  |
| sealed_at | TEXT |  |  |  |
| ledger_hash | TEXT |  |  |  |

## collection_entry.csv

One pour by one member, priced and hash-chained (CollectionEntry). Rows: 12,232.

| Column | Type | Key | Required | Refers to |
|---|---|---|---|---|
| entry_id | TEXT | PK | yes |  |
| shift_id | INTEGER |  | yes | collection_shift.shift_id |
| member_code | TEXT |  | yes | member.member_code |
| chart_id | INTEGER |  | yes | rate_chart.chart_id |
| quantity_kg | REAL |  | yes |  |
| fat_pct | REAL |  | yes |  |
| snf_pct | REAL |  | yes |  |
| rate_per_kg | REAL |  | yes |  |
| amount | REAL |  | yes |  |
| capture_mode | TEXT |  | yes |  |
| manual_reason | TEXT |  |  |  |
| device_id | TEXT |  |  | device.device_id |
| captured_at | TEXT |  | yes |  |
| synced_at | TEXT |  |  |  |
| prev_hash | TEXT |  | yes |  |
| entry_hash | TEXT |  | yes |  |

## temperature_reading.csv

Cooler readings at five-minute intervals while a lot is in the cooler (TemperatureReading). Rows: 82,474.

| Column | Type | Key | Required | Refers to |
|---|---|---|---|---|
| reading_id | INTEGER | PK | yes |  |
| bmc_code | TEXT |  | yes | bulk_milk_cooler.bmc_code |
| read_at | TEXT |  | yes |  |
| milk_temp_c | REAL |  | yes |  |
| power_on | INTEGER |  | yes |  |
| synced_at | TEXT |  |  |  |

## tanker_trip.csv

One tanker run on one day (TankerTrip). Rows: 90.

| Column | Type | Key | Required | Refers to |
|---|---|---|---|---|
| trip_id | INTEGER | PK | yes |  |
| trip_date | TEXT |  | yes |  |
| vehicle_no | TEXT |  | yes |  |
| driver_name | TEXT |  | yes |  |

## pickup_record.csv

Transfer of one lot to a tanker, confirmed by the driver (PickupRecord). Rows: 357.

| Column | Type | Key | Required | Refers to |
|---|---|---|---|---|
| pickup_id | INTEGER | PK | yes |  |
| trip_id | INTEGER |  | yes | tanker_trip.trip_id |
| lot_id | INTEGER |  | yes | tank_lot.lot_id |
| picked_at | TEXT |  | yes |  |
| quantity_kg | REAL |  | yes |  |
| milk_temp_c | REAL |  | yes |  |
| seal_no | TEXT |  | yes |  |
| driver_confirmed | INTEGER |  | yes |  |

## dock_receipt.csv

Measurement and acceptance decision at the plant dock (DockReceipt). Rows: 357.

| Column | Type | Key | Required | Refers to |
|---|---|---|---|---|
| receipt_id | INTEGER | PK | yes |  |
| pickup_id | INTEGER |  | yes | pickup_record.pickup_id |
| received_at | TEXT |  | yes |  |
| quantity_kg | REAL |  | yes |  |
| fat_pct | REAL |  | yes |  |
| snf_pct | REAL |  | yes |  |
| milk_temp_c | REAL |  | yes |  |
| decision | TEXT |  | yes |  |
| remarks | TEXT |  |  |  |

## exception_case.csv

Chilling and variance cases in one table, told apart by case_type (ExceptionCase and its two subclasses). Rows: 102.

| Column | Type | Key | Required | Refers to |
|---|---|---|---|---|
| case_id | INTEGER | PK | yes |  |
| lot_id | INTEGER |  | yes | tank_lot.lot_id |
| case_type | TEXT |  | yes |  |
| status | TEXT |  | yes |  |
| raised_at | TEXT |  | yes |  |
| acknowledged_at | TEXT |  |  |  |
| decided_at | TEXT |  |  |  |
| closed_at | TEXT |  |  |  |
| disposition | TEXT |  |  |  |
| rule_code | TEXT |  |  |  |
| reading_id | INTEGER |  |  | temperature_reading.reading_id |
| peak_temp_c | REAL |  |  |  |
| minutes_over_limit | INTEGER |  |  |  |
| receipt_id | INTEGER |  |  | dock_receipt.receipt_id |
| quantity_variance_pct | REAL |  |  |  |
| fat_variance | REAL |  |  |  |
| snf_variance | REAL |  |  |  |
| responsibility | TEXT |  |  |  |

## case_action.csv

Append-only log of what was done on a case (CaseAction). Rows: 309.

| Column | Type | Key | Required | Refers to |
|---|---|---|---|---|
| action_id | INTEGER | PK | yes |  |
| case_id | INTEGER |  | yes | exception_case.case_id |
| action_at | TEXT |  | yes |  |
| action_type | TEXT |  | yes |  |
| remarks | TEXT |  |  |  |
| acted_by | TEXT |  |  | app_user.user_id |

## notification.csv

Messages queued for members and staff (Notification). Rows: 12,443.

| Column | Type | Key | Required | Refers to |
|---|---|---|---|---|
| notification_id | INTEGER | PK | yes |  |
| case_id | INTEGER |  |  | exception_case.case_id |
| entry_id | TEXT |  |  | collection_entry.entry_id |
| channel | TEXT |  | yes |  |
| recipient | TEXT |  | yes |  |
| purpose | TEXT |  | yes |  |
| queued_at | TEXT |  | yes |  |
| status | TEXT |  | yes |  |

## payment_cycle.csv

Ten-day payment cycles (PaymentCycle). Rows: 3.

| Column | Type | Key | Required | Refers to |
|---|---|---|---|---|
| cycle_id | INTEGER | PK | yes |  |
| from_date | TEXT |  | yes |  |
| to_date | TEXT |  | yes |  |
| status | TEXT |  | yes |  |

## payment_statement.csv

One member's total for one cycle (PaymentStatement). Rows: 480.

| Column | Type | Key | Required | Refers to |
|---|---|---|---|---|
| statement_id | INTEGER | PK | yes |  |
| cycle_id | INTEGER |  | yes | payment_cycle.cycle_id |
| member_code | TEXT |  | yes | member.member_code |
| total_quantity_kg | REAL |  | yes |  |
| gross_amount | REAL |  | yes |  |
| net_amount | REAL |  | yes |  |
| status | TEXT |  | yes |  |

## audit_event.csv

Record of creations, decisions and administrative changes (AuditEvent). Rows: 1,179.

| Column | Type | Key | Required | Refers to |
|---|---|---|---|---|
| event_id | INTEGER | PK | yes |  |
| event_at | TEXT |  | yes |  |
| user_id | TEXT |  |  | app_user.user_id |
| action | TEXT |  | yes |  |
| object_type | TEXT |  | yes |  |
| object_id | TEXT |  | yes |  |

## config.csv

Thresholds and tolerances used by the rules. No class: configuration (NFR-10). Rows: 9.

| Column | Type | Key | Required | Refers to |
|---|---|---|---|---|
| key | TEXT | PK | yes |  |
| value | REAL |  | yes |  |
| description | TEXT |  | yes |  |
